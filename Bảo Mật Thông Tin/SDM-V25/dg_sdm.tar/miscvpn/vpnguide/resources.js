/*
 * Copyright (c) 2002, 2003, 2004 2005 by cisco Systems, Inc.
 * All rights reserved.
 */
 
/* Welcome page */ 
var welcome_page = "1 - Welcome Page";
var welcome_who_Aer_You = "2 - Who Are You?";
var welcome_VPN_EndPoints = "3 - VPN Endpoints";
var welcome_Equipment = "4 - Equipment";
var welcome_Traffic = "5 - Traffic";
var welcome_Features = "6 - Features";
var welcome_Summary = "7 - Summary";
var welcome_Recommendation = "8 - Recommendations";
var welcome_desc1="Welcome to the VPN Design Guide";
var welcome_desc_help = "This guide helps you to design your VPN network."
var welcome_desc_infor="You must supply the following information:"
var welcome_type_user="Type of user you are, administrator or end-user trying to connect to the network";
var welcome_type_eqipmet="Type of equipment that terminates the VPN";
var welcome_general_type="General  type of traffic that the VPN will carry";
var welcome_features="Whether you need features such as dynamic routing, QoS, and multicast capability";
var welcome_vpn_technologies="This guide supports the following VPN technologies:";
var welcome_sitetosite="IPsec VPN (Site-to-Site VPN)";
var welcome_dynamic_vpn="Dynamic Multipoint VPN";
var welcome_gre="GRE over IPsec";
var welcome_easy_vpn="Easy VPN";
var welcome_web_vpn="Cisco SSL VPN";
var who_are_you = "Who Are You?";
var who_are_you_iam ="I am";
var who_are_you_admin ="A Corporate network administrator designing a VPN network";
var who_are_you_branch="A branch office or small office administrator connecting to the main office�s VPN network";
var who_are_you_reseller="A reseller or partner office administrator connecting to a corporate VPN network";
var who_are_you_remote="A remote access user connecting to the corporate VPN network";
var who_are_you_remote_user="*Remote access user";
var who_are_you_remote_desc="A remote access user is anyone who needs to connect the corporate network from a laptop, PDA, or Internet kiosk.";
var endpoint_whatsites = "What sites does the VPN connect?"
var endpoint_setting= "I am setting up a VPN to connect:"
var endpoint_corporate = "The corporate office to a branch office";
var endpoint_reseller = "The corporate office to extranet reseller or partner office";
var endpoint_remote = "The corporate office to a remote access user";
var endpoint_remote_desc = "A remote access user is anyone who needs to connect the corporate network from a laptop, PDA, or Internet kiosk."
var eqipment_vpn = "VPN Equipment";
var eqipment_cisco="Are you using non-Cisco equipment at the other end of this VPN connection?";
var eqipment_no="No";
var eqipment_yes="Yes";
var traffic_traffic="Traffic";
var traffic_ip="Will nonIP traffic such as IPX or AppleTalk flow through the VPN tunnel?";

var features_features="Features";
var features_check="Check any additional features you intend to use in the VPN you are designing.";
var features_dynamic="Dynamic routing";
var features_dynamic_desc="Allows the VPN to respond to changing conditions on the network and to route traffic appropriately.";
var features_multicast="Multicast";
var features_multicast_desc="Allows traffic from one host to be sent to multiple recipients simultaneously.";
var features_qos="Quality of Service (QoS)";
var features_qos_desc="Allows you to reserve bandwidth for critical applications (such as  video and voice).";

   
var general_back = "Back";
var general_next = "Next";
var general_cancel = "Cancel";
var client_install_Install = "4 - Client Installation"
var client_install_summary = "5 - Summary";
var client_install_recommendation = "6 - Recommendations";
var client_install_install="Client Software Installation";
var client_install_is_it_ok="Is it OK to installing VPN client software on the remote client, or use a Cisco router at the remote site? Installing VPN client software or Cisco hardware might not be possible if the remote user is connecting to the corporate network from a public shared PC, such as a PC in a library, or a PC in an Internet kiosk."
var summary_summary ="Summary";


var recommend_title = "Recommendation";
var rec_sitetosite="Based on your requirements, we recommend configuring a Site to Site VPN on the router.";
var rec_sitetosite_lean="Click to learn about Site to Site VPN technology";
var rec_sitetosite_worksheet="Click to generate a worksheet for VPN wizard";
var rec_sitetosite_peer="Click to generate instructions to configure the peer devices";
var rec_sitetosite_configure="To configure a Site to Site VPN on this router using Cisco SDM, click the button below.";
var rec_sitetosite_unsupp_image="The IOS image in your router does not support the requested feature. To configure this feature, you need to go to the Software Center on Cisco.com and upgrade your IOS image to one that supports this feature set.";
var rec_sitetosite_launch="Launch Site to Site VPN Wizard...";


var rec_dmvpn="Based on your requirements, we recommend configuring a DMVPN Hub and spoke on the router.";
var rec_dmvpn_learn="Click to learn about DMVPN technology";
var rec_dmvpn_worksheet="Click to generate a worksheet for DMVPN wizard";
var rec_dmvpn_peer="Click to generate instructions to configure the peer devices";
var rec_dmvpn_configure="To configure a DMVPN hub on this router using Cisco SDM, click the button below.";
var rec_dmvpn_unsup_image="The IOS image in your router does not support the requested feature. To configure this feature, you need to go to the Software Center on Cisco.com and upgrade your IOS image to one that supports this feature set.";
var rec_dmvpn_launch="Launch DMVPN Wizard...";


var rec_easy_vpn = "Click to learn about Easy VPN Server technology";
var rec_easyvpn_worksheet="Click to generate a worksheet for Easy VPN server wizard";
var rec_easyvpn_peer="Click to generate instructions to configure the peer devices";
var rec_easyvpn_configure="To configure an Easy VPN server on this router using Cisco SDM, click the button below.";
var rec_easyvpn_unsup_image="The IOS image in your router does not support the requested feature. To configure this feature, you need to go to the Software Center on Cisco.com and upgrade your IOS image to one that supports this feature set.";
var rec_easyvpn_launch ="Launch Easy VPN Server Wizard...";
var rec_easyvpn_rec="Based on your requirements, we recommend configuring an Easy VPN server on the router.";


var rec_gre_rec = "Based on your requirements, we recommend configuring a GRE over IPsec VPN on the router.";
var rec_gre_learn="Click to learn about GRE over IPsec technology";
var rec_gre_worksheet="Click to generate a worksheet for GRE over IPsec wizard";
var rec_gre_peer = "Click to generate instructions to configure the peer devices";
var rec_gre_configure="To configure a GRE over IPsec VPN on this router using Cisco SDM, click the button below.";
var rec_gre_unsup_image = "The IOS image in your router does not support the requested feature. To configure this feature, you need to go to the Software Center on Cisco.com and upgrade your IOS image to one that supports this feature set.";
var rec_gre_launch = "Launch GRE over IPsec Wizard...";
 
var rec_webvpn_rec="Based on your requirements, we recommend configuring a SSL VPN on the router.";
var rec_webvpn_learn="Click to learn about SSL VPN technology.";
var rec_webvpn_worksheet="Click to generate a worksheet for SSL VPN wizard.";
var rec_webvpn_configure="To configure a SSL VPN on this router using Cisco SDM, click the button below.";
var rec_webvpn_unsup_image="The IOS image in your router does not support the requested feature. To configure this feature, you need to go to the Software Center on Cisco.com and upgrade your IOS image to one that supports this feature set.";
var rec_webvpn_launch="Launch SSL VPN Wizard...";

var javascript_contact_admin=" You should contact network administrator of the central site.";
var javascript_corporate_admin="You are a corporate administrator designing the VPN.";
var javascript_branch_office="You are a branch office or small office administrator connecting to the main office�s VPN network.";
var javascript_reseller="You are a reseller or partner office�s administrator connecting to the main office�s VPN network.";
var javascript_remote="You are a remote access user connecting to the main office�s VPN network.";

var javascript_corpto_branch = "You are designing a VPN to connect the corporate to branch office.";
var javascript_central_reseller = "You are designing a VPN to connect your central site and a extranet reseller or partner�s office.";
var javascript_central_remote = "You are setting up a VPN between your central site and a remote access user.";

var javascript_cisco_only = "You are using only Cisco equipment.";
var javascript_nocisco="You are using non-Cisco equipments.";

var javascript_ip="This VPN will not carry nonIP traffic.";
var javascript_nonip="There is a need of nonIP traffic on this VPN connection.";

var javascript_features="You chose the following additional features:";
var javascript_dyanamicrouting= "Dynamic Routing";
var javascript_multicast = "Multicast";
var jvaascript_qos ="QoS";

var javascript_install_accept = "It is acceptable to installing VPN client software or use a cisco router at the remote user end.";
var jvaascript_install_notaccept = "It is not acceptable to installing VPN client software or use a cisco router at the remote user end";
var javascript_oncancel ="Do you really want to exit VPN Design Guide?";

var javascript_summary_selections = "You have made the following selections:";
var vpn_guide_title = "VPN Design Guide";

var main_vpn_guide_blocker_msg = "A popup blocker is enabled in your browser. Disable it, or allow popups from 127.0.0.1 for the VPN design guide to function.";


/* VPN Design Guide Help Links - Strings */
var links_worksheet_common_1="PREREQUISITES";
var links_worksheet_common_2="Question";
var links_worksheet_common_3="Answer";
var links_worksheet_common_4="CONFIGURATION INFORMATION";
var links_worksheet_common_5="Item";
var links_worksheet_common_6="SDM Default";
var links_worksheet_common_7="Your choice";
var links_worksheets_helplinks_1="Worksheet for Hub and Spoke DMVPN Spoke";
var links_worksheets_helplinks_2="Instructions to Configure a Peer Device for a Fully Meshed Server";
var links_worksheets_helplinks_3="Worksheet for Fully Meshed DMVPN Hub";
var links_worksheets_helplinks_4="Worksheet for Fully Meshed DMVPN Spoke";

var links_title_1="Worksheet for Hub";
var links_title_2="Instructions to Configure a Peer Device for DMVPN Hub";
var links_title_3="Instructions to Configure a Peer Device for Easy VPN Server";
var links_title_4="Worksheet for Easy VPN Server";
var links_title_5="Worksheet for Fully Meshed DMVPN Spoke";
var links_title_6="Instructions to Configure a Peer Device for a Fully Meshed Server";
var links_title_7="Worksheet for Fully Meshed DMVPN Hub";
var links_title_8="Worksheet for Hub and Spoke Fully Meshed DMVPN Spoke";
var links_title_9="Instructions to Configure a Peer Device for GRE over IPsec VPN";
var links_title_10="Worksheet for GRE over IPsec VPN";
var links_title_11="Instructions to Configure A Peer Device for Site to Site VPN";
var links_title_12="Worksheet for Site to Site VPN";
var links_title_13="Worksheet for SSL VPN";

var links_dmvpn_worksheet_1="Worksheet for Hub-and-Spoke DMVPN Hub";
var links_dmvpn_worksheet_2="Complete this worksheet before you creating your DMVPN connections. You can use SDM to configure DMVPN.";
var links_dmvpn_worksheet_3="Does your router have a crypto image?";
var links_dmvpn_worksheet_4="Is your IOS image later that 12.3(8)T1 or 12.3(9)?";
var links_dmvpn_worksheet_5="Is the VPN peer device accessible from this router?";
var links_dmvpn_worksheet_6="IP address pool for your DMVPN network. An IP address from this pool will be given to each of the spokes. One IP address will also be configured on the mGRE tunnel on this router. These are private IP addresses that are unique in your network";
var links_dmvpn_worksheet_7="IP address of this router�s (hub) mGRE physical interface";
var links_dmvpn_worksheet_8="Note: This is an IP address from the pool you defined in step 1";
var links_dmvpn_worksheet_9="Interface on this router (hub) that connects to the Internet";
var links_dmvpn_worksheet_10="Advanced Options";
var links_dmvpn_worksheet_11="a. NHRP Authentication String";
var links_dmvpn_worksheet_12="Note: This must be same on all the routers in the network";
var links_dmvpn_worksheet_13="DMVPN_NW";
var links_dmvpn_worksheet_14="b. NHRP network ID";
var links_dmvpn_worksheet_15="c. NHRP hold time";
var links_dmvpn_worksheet_16="d. Tunnel Key";
var links_dmvpn_worksheet_17="e. Bandwidth";
var links_dmvpn_worksheet_18="f. MTU";
var links_dmvpn_worksheet_19="g. Tunnel Throughput delay";
var links_dmvpn_worksheet_20="Authentication Mechanism - Pre-Shared Keys or Digital Certificates ?";
var links_dmvpn_worksheet_21="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_dmvpn_worksheet_22="Pre-Shared Key(if Pre-Shared Key chosen in step6)";
var links_dmvpn_worksheet_23="IKE Policy";
var links_dmvpn_worksheet_24="Encryption";
var links_dmvpn_worksheet_25="Hash";
var links_dmvpn_worksheet_26="Authentication";
var links_dmvpn_worksheet_27="DH Group";
var links_dmvpn_worksheet_28="3DES";
var links_dmvpn_worksheet_29="SHA";
var links_dmvpn_worksheet_30="Group 2";
var links_dmvpn_worksheet_31="Transform Set";
var links_dmvpn_worksheet_32="Integrity Algorithm";
var links_dmvpn_worksheet_33="Encryption Algorithm";
var links_dmvpn_worksheet_34="AH";
var links_dmvpn_worksheet_35="Mode";
var links_dmvpn_worksheet_36="IP Compression";
var links_dmvpn_worksheet_37="ESP_SHA_HMAC";
var links_dmvpn_worksheet_38="ESP_3DES";
var links_dmvpn_worksheet_39="Tunnel";
var links_dmvpn_worksheet_40="Routing Protocol";
var links_dmvpn_worksheet_41="Note: RIP is not recommended for hub and spoke configuration";
var links_dmvpn_worksheet_42="Routing Information";
var links_dmvpn_worksheet_43="Private Networks";
var links_dmvpn_worksheet_44="If you choose EIGRP, AS number";
var links_dmvpn_worksheet_45="If you choose OSPF, OSPF Process ID and OSPF Area ID";


var links_dmvpn_instructions_1="Instructions to Configure a Peer Device for DMVPN Hub-and-Spoke";
var links_dmvpn_instructions_2="Step1: Launch SDM and navigate to Configure->VPN-DMVPN->Create a spoke in DMVPN then click the �Launch the selected Task� button";
var links_dmvpn_instructions_3="Step2: Welcome Screen - Click Next";
var links_dmvpn_instructions_4="Step3: DMVPN network topology - Select hub and spoke";
var links_dmvpn_instructions_5="Step4: Hub Information - Enter the IP address of physical interface and the mGRE tunnel on the hub";
var links_dmvpn_instructions_6="Step5: GRE Tunnel Interface configuration - Select the interface in the spoke that connects to the hub. Enter an IP address and mask for the mGRE tunnel on the spoke. This must be in the same subnet as the hub�s mGRE tunnel. Click on the advanced button and verify the advanced information";
var links_dmvpn_instructions_7="Step6: Authentication - Select pre-shared key or digital certificate. If preshared key is selected, enter pre-shared key";
var links_dmvpn_instructions_8="Step 7: IKE proposals";
var links_dmvpn_instructions_9="Check that the existing IKE policies match the IKE policies of the peer router. If not, add new IKE policies that match the IKE policies configured on the peer router.";
var links_dmvpn_instructions_10="Step 8: Transform Set";
var links_dmvpn_instructions_11="Select a transform set that matches the transform set configured on the peer router. If a matching transform set is not available, create one.";
var links_dmvpn_instructions_12="Step 9: Select the routing protocol to match the routing protocol selected on the peer router";
var links_dmvpn_instructions_13="Step 10: Routing Information.";
var links_dmvpn_instructions_14="Enter routing protocol specific information.";
var links_dmvpn_instructions_15="Add private networks, where asked. These networks will be advertised to the peer device using the selected routing protocol.";
var links_dmvpn_instructions_16="Step 11: Summary of Configuration";
var links_dmvpn_instructions_17="Review the summary. Navigate back to make any changes, if necessary.";
var links_dmvpn_instructions_18="If not, click the Finish button";


var links_easyvpn_instructions_1="Instructions to Configure a Peer Device for Easy VPN Server";
var links_easyvpn_instructions_2="Step1: Launch SDM and navigate to Configure->VPN-> Easy VPN Remote";
var links_easyvpn_instructions_3="Click Launch Easy VPN Remote Wizard.";
var links_easyvpn_instructions_4="Step2: Click next on welcome screen";
var links_easyvpn_instructions_5="Step3: In Server Information screen,";
var links_easyvpn_instructions_6="a. Enter a name for this Easy VPN Remote connection.";
var links_easyvpn_instructions_7="b. Enter the IP address or hostname of the Easy VPN Server that you configured now. If you have any backup Easy VPN Server, enter the IP address or hostname of the backup Easy VPN Server in the optional 'Easy VPN Server 2' text box.";
var links_easyvpn_instructions_8="c. Select the mode of operation (Client or Network Extension)";
var links_easyvpn_instructions_9="Step4: In Authentication screen,";
var links_easyvpn_instructions_10="a. Select the authentication to be used. It should be the same as the one you configured in the Easy VPN Server. If you select pre-shared keys, then you need to specify the VPN group name to which this client belongs to and the corresponding key.";
var links_easyvpn_instructions_11="b. If you select digital certificate authentication enter the group name in the OU field of certificate to authenticate this client with the server.";
var links_easyvpn_instructions_12="c. If you have enabled XAuth is enabled in your Easy VPN Server, you can select how you want to enter the XAuth credentials each time when client is connecting to the server. Note that you can use the 'Save XAuth credentials in the router' option only if you have enabled 'Save Password' in the group, which might be configured on VPN server or the external AAA server, to which this client belongs to.";
var links_easyvpn_instructions_13="Step5: In Interface and Connection Settings screen,";
var links_easyvpn_instructions_14="a. Select the LAN interfaces and the WAN interface that is connected to the server.";
var links_easyvpn_instructions_15="b. Select the method to be used for triggering the tunnel.";
var links_easyvpn_instructions_16="Step6: Summary of Configuration";
var links_easyvpn_instructions_17="Review the summary. Navigate back to make any changes, if necessary. ";
var links_easyvpn_instructions_18="If not, click the Finish Button";

var links_easyvpn_worksheet_1="Worksheet for Easy VPN Server";
var links_easyvpn_worksheet_2="Complete this worksheet before you create your Easy VPN Server connections.";
var links_easyvpn_worksheet_3="You can use SDM to configure Easy VPN Server.";
var links_easyvpn_worksheet_4="Does your router have a crypto image?";
var links_easyvpn_worksheet_5="Is the VPN peer device accessible from this router?";
var links_easyvpn_worksheet_6="Interface for the Easy VPN Server";
var links_easyvpn_worksheet_7="Authentication Mechanism - Pre-Shared Keys or Digital Certificates or both?";
var links_easyvpn_worksheet_8="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_easyvpn_worksheet_9="IKE Policy";
var links_easyvpn_worksheet_10="Encryption";
var links_easyvpn_worksheet_11="Hash";
var links_easyvpn_worksheet_12="Authentication";
var links_easyvpn_worksheet_13="DH Group";
var links_easyvpn_worksheet_14="3DES";
var links_easyvpn_worksheet_15="SHA";
var links_easyvpn_worksheet_16="Group 2";
var links_easyvpn_worksheet_17="Transform Set";
var links_easyvpn_worksheet_18="Integrity Algorithm";
var links_easyvpn_worksheet_19="Encryption Algorithm";
var links_easyvpn_worksheet_20="AH";
var links_easyvpn_worksheet_21="Mode";
var links_easyvpn_worksheet_22="IP Compression";
var links_easyvpn_worksheet_23="ESP_SHA_HMAC";
var links_easyvpn_worksheet_24="ESP_3DES";
var links_easyvpn_worksheet_25="Tunnel";
var links_easyvpn_worksheet_26="Group Authorization and Group Policy Lookup - Local or RADIUS or both.";
var links_easyvpn_worksheet_27="Note: If you select RADIUS add at least one RADIUS server";
var links_easyvpn_worksheet_28="Local";
var links_easyvpn_worksheet_29="User Authentication (XAuth) - Local RADIUS and Local.";
var links_easyvpn_worksheet_30="Note: If you select RADIUS add at least one RADIUS server";
var links_easyvpn_worksheet_31="Group Authorization and User Group Policies.";
var links_easyvpn_worksheet_32="Note: Add at least one local group in the step 5 if you select 'local' or 'RADIUS and local'  as group authorization";


var links_fullymeshed_dmvpnspoke_worksheet_1="Worksheet for Fully Meshed DMVPN Spoke";
var links_fullymeshed_dmvpnspoke_worksheet_2="Complete this worksheet before you create your DMVPN connections. You can use SDM to configure DMVPN.";
var links_fullymeshed_dmvpnspoke_worksheet_3="Does your router have a crypto image?";
var links_fullymeshed_dmvpnspoke_worksheet_4="Is your IOS image later that 12.3(8)T1 or 12.3(9)?";
var links_fullymeshed_dmvpnspoke_worksheet_5="Is the VPN peer device accessible from this router?";
var links_fullymeshed_dmvpnspoke_worksheet_6="Primary Hub�s Information:";
var links_fullymeshed_dmvpnspoke_worksheet_7="a. IP address of Primary hub�s physical Interface that this spoke router is connecting to";
var links_fullymeshed_dmvpnspoke_worksheet_8="b. IP address of Primary hub�s mGRE Interface that this spoke router is connecting to";
var links_fullymeshed_dmvpnspoke_worksheet_9="(Optional)";
var links_fullymeshed_dmvpnspoke_worksheet_10="Backup Hub�s Information:";
var links_fullymeshed_dmvpnspoke_worksheet_11="a. IP address of Backup hub�s physical Interface that this spoke router is connecting to";
var links_fullymeshed_dmvpnspoke_worksheet_12="b. IP address of Backup hub�s mGRE Interface that this spoke router is connecting to";
var links_fullymeshed_dmvpnspoke_worksheet_13="Interface on this router (spoke) that connects to the Internet";
var links_fullymeshed_dmvpnspoke_worksheet_14="IP address of this router�s ( spoke ) mGRE tunnel interface";
var links_fullymeshed_dmvpnspoke_worksheet_15="Note: This is an IP address from the pool you defined in step 1";
var links_fullymeshed_dmvpnspoke_worksheet_16="Advanced Options";
var links_fullymeshed_dmvpnspoke_worksheet_17="a. NHRP Authentication String";
var links_fullymeshed_dmvpnspoke_worksheet_18="Note: This must be same on all the routers in the network";
var links_fullymeshed_dmvpnspoke_worksheet_19="b. NHRP network ID";
var links_fullymeshed_dmvpnspoke_worksheet_20="c. NHRP hold time";
var links_fullymeshed_dmvpnspoke_worksheet_21="d. Tunnel Key";
var links_fullymeshed_dmvpnspoke_worksheet_22="e. Bandwidth";
var links_fullymeshed_dmvpnspoke_worksheet_23="f. MTU";
var links_fullymeshed_dmvpnspoke_worksheet_24="g. Tunnel Throughput delay";
var links_fullymeshed_dmvpnspoke_worksheet_25="Authentication Mechanism - Pre-Shared Keys or Digital Certificates ?";
var links_fullymeshed_dmvpnspoke_worksheet_26="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_fullymeshed_dmvpnspoke_worksheet_27="Pre-Shared Key(if Pre-Shared Key chosen in step6)";
var links_fullymeshed_dmvpnspoke_worksheet_28="IKE Policy";
var links_fullymeshed_dmvpnspoke_worksheet_29="Encryption";
var links_fullymeshed_dmvpnspoke_worksheet_30="Hash";
var links_fullymeshed_dmvpnspoke_worksheet_31="Authentication";
var links_fullymeshed_dmvpnspoke_worksheet_32="DH Group";
var links_fullymeshed_dmvpnspoke_worksheet_33="3DES";
var links_fullymeshed_dmvpnspoke_worksheet_34="SHA";
var links_fullymeshed_dmvpnspoke_worksheet_35="Group 2";
var links_fullymeshed_dmvpnspoke_worksheet_36="Transform Set";
var links_fullymeshed_dmvpnspoke_worksheet_37="Integrity Algorithm";
var links_fullymeshed_dmvpnspoke_worksheet_38="Encryption Algorithm";
var links_fullymeshed_dmvpnspoke_worksheet_39="AH";
var links_fullymeshed_dmvpnspoke_worksheet_40="Mode";
var links_fullymeshed_dmvpnspoke_worksheet_41="IP Compression";
var links_fullymeshed_dmvpnspoke_worksheet_42="ESP_SHA_HMAC";
var links_fullymeshed_dmvpnspoke_worksheet_43="ESP_3DES";
var links_fullymeshed_dmvpnspoke_worksheet_44="Tunnel";
var links_fullymeshed_dmvpnspoke_worksheet_45="Routing Protocol";
var links_fullymeshed_dmvpnspoke_worksheet_46="Note: Use the same routing protocol that is configured on the hub";
var links_fullymeshed_dmvpnspoke_worksheet_47="Routing Information";
var links_fullymeshed_dmvpnspoke_worksheet_48="Private Networks";
var links_fullymeshed_dmvpnspoke_worksheet_49="If you choose EIGRP, AS Number:";
var links_fullymeshed_dmvpnspoke_worksheet_50="If you choose OSPF, OSPF Process ID and OSPF Area ID:";
var links_fullymeshed_dmvpnspoke_worksheet_51="If you choose RIP, Rip Version:";


var links_fullymeshed_server_instructions_1="Instructions to Configure a Peer Device for a Fully Meshed Server";
var links_fullymeshed_server_instructions_2="Step1: Launch SDM and navigate to Configure->VPN-DMVPN->Create a spoke in DMVPN and click the �Launch the selected Task� button";
var links_fullymeshed_server_instructions_3="Step2: Welcome Screen - Click next";
var links_fullymeshed_server_instructions_4="Step3: DMVPN network topology - Fully Meshed Topology";
var links_fullymeshed_server_instructions_5="Step4: Hub Information - Enter the IP address of physical interface and the mGRE tunnel on the hub. If a backup hub is configured enter the backup hub�s information.";
var links_fullymeshed_server_instructions_6="Step5: GRE Tunnel Interface configuration - Select the interface in the spoke that connects to the hub. Enter an IP address and mask for the mGRE tunnel on the spoke. This must be in the same subnet as the hub�s mGRE tunnel. Click on the advanced button and verify the advanced information";
var links_fullymeshed_server_instructions_7="Step6: Authentication - Select pre-shared key or digital certificate. If preshared key is selected enter pre-shared keys";
var links_fullymeshed_server_instructions_8="Step 7: IKE proposals";
var links_fullymeshed_server_instructions_9="Check that the existing IKE policies match the IKE policies of the peer router. If not, add new IKE policies that match the IKE policies configured on the peer router";
var links_fullymeshed_server_instructions_10="Step 8: Transform Set";
var links_fullymeshed_server_instructions_11="Select a transform set that matches the transform set configured on the peer router. If a matching transform set is not available, create one.";
var links_fullymeshed_server_instructions_12="Step 9: Select the routing protocol, that match the routing protocol selected on the peer router";
var links_fullymeshed_server_instructions_13="Step 10: Routing Information.";
var links_fullymeshed_server_instructions_14="Enter routing protocol specific information.";
var links_fullymeshed_server_instructions_15="Add private networks, where asked. These networks will be advertised to the peer device using the selected routing protocol.";
var links_fullymeshed_server_instructions_16="Step 11: Summary of Configuration";
var links_fullymeshed_server_instructions_17="Review the summary. Navigate back to make any changes, if necessary.";
var links_fullymeshed_server_instructions_18="If not, click the Finish button";


var links_fullymeshed_dmvpnhub_worksheet_1="Worksheet for Fully Meshed DMVPN Hub";
var links_fullymeshed_dmvpnhub_worksheet_2="Complete this worksheet before you create your DMVPN connections. You can use SDM to configure DMVPN.";
var links_fullymeshed_dmvpnhub_worksheet_3="Does your router have a crypto image?";
var links_fullymeshed_dmvpnhub_worksheet_4="Is your IOS image later that 12.3(8)T1 or 12.3(9)";
var links_fullymeshed_dmvpnhub_worksheet_5="Is the VPN peer device accessible from this router?";
var links_fullymeshed_dmvpnhub_worksheet_6="IP address pool for your DMVPN network. An IP address from this pool will be given to each of the spokes. One IP address will also be configured on the mGRE tunnel on this router. These are private IP addresses that are unique in your network";
var links_fullymeshed_dmvpnhub_worksheet_7="Type of Hub";
var links_fullymeshed_dmvpnhub_worksheet_8="Primary or Backup";
var links_fullymeshed_dmvpnhub_worksheet_9="If you choose Backup in Step2";
var links_fullymeshed_dmvpnhub_worksheet_10="IP address of primary hub�s physical";
var links_fullymeshed_dmvpnhub_worksheet_11="Interface";
var links_fullymeshed_dmvpnhub_worksheet_12="IP address of primary hub�s mGRE";
var links_fullymeshed_dmvpnhub_worksheet_13="IP address of this router�s ( hub) mGRE physical interface";
var links_fullymeshed_dmvpnhub_worksheet_14="Note: This is an IP address from the pool you defined in step 1";
var links_fullymeshed_dmvpnhub_worksheet_15="Interface on this router (hub) that connects to the Internet";
var links_fullymeshed_dmvpnhub_worksheet_16="Advanced Options";
var links_fullymeshed_dmvpnhub_worksheet_17="a. NHRP Authentication String";
var links_fullymeshed_dmvpnhub_worksheet_18="Note: This must be same on all the routers in the network";
var links_fullymeshed_dmvpnhub_worksheet_19="b. NHRP network ID";
var links_fullymeshed_dmvpnhub_worksheet_20="c. NHRP hold time";
var links_fullymeshed_dmvpnhub_worksheet_21="d. Tunnel Key";
var links_fullymeshed_dmvpnhub_worksheet_22="e. Bandwidth";
var links_fullymeshed_dmvpnhub_worksheet_23="f. MTU";
var links_fullymeshed_dmvpnhub_worksheet_24="g. Tunnel Throughput delay";
var links_fullymeshed_dmvpnhub_worksheet_25="DMVPN_NW";
var links_fullymeshed_dmvpnhub_worksheet_26="10000 (* 900 for backup hub)";
var links_fullymeshed_dmvpnhub_worksheet_27="Authentication Mechanism - Pre-Shared Keys or Digital Certificates ?";
var links_fullymeshed_dmvpnhub_worksheet_28="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_fullymeshed_dmvpnhub_worksheet_29="Pre-Shared Key(if Pre-Shared Key chosen in step6)";
var links_fullymeshed_dmvpnhub_worksheet_30="IKE Policy";
var links_fullymeshed_dmvpnhub_worksheet_31="Encryption";
var links_fullymeshed_dmvpnhub_worksheet_32="Hash";
var links_fullymeshed_dmvpnhub_worksheet_33="Authentication";
var links_fullymeshed_dmvpnhub_worksheet_34="DH Group";
var links_fullymeshed_dmvpnhub_worksheet_35="3DES";
var links_fullymeshed_dmvpnhub_worksheet_36="SHA";
var links_fullymeshed_dmvpnhub_worksheet_37="Group 2";
var links_fullymeshed_dmvpnhub_worksheet_38="Transform Set";
var links_fullymeshed_dmvpnhub_worksheet_39="Integrity Algorithm";
var links_fullymeshed_dmvpnhub_worksheet_40="Encryption Algorithm";
var links_fullymeshed_dmvpnhub_worksheet_41="AH";
var links_fullymeshed_dmvpnhub_worksheet_42="Mode";
var links_fullymeshed_dmvpnhub_worksheet_43="IP Compression";
var links_fullymeshed_dmvpnhub_worksheet_44="ESP_SHA_HMAC";
var links_fullymeshed_dmvpnhub_worksheet_45="ESP_3DES";
var links_fullymeshed_dmvpnhub_worksheet_46="Tunnel";
var links_fullymeshed_dmvpnhub_worksheet_47="Routing Protocol";
var links_fullymeshed_dmvpnhub_worksheet_48="Routing Information";
var links_fullymeshed_dmvpnhub_worksheet_49="Private Networks";
var links_fullymeshed_dmvpnhub_worksheet_50="If you choose EIGRP, AS Number";
var links_fullymeshed_dmvpnhub_worksheet_51="If you choose OSPF, OSPF Process ID and OSPF Area ID";
var links_fullymeshed_dmvpnhub_worksheet_52="If you choose RIP, Rip Version";


var links_dmvpnhubspoke_worksheet_1="Worksheet for Hub and Spoke DMVPN Spoke";
var links_dmvpnhubspoke_worksheet_2="Complete this worksheet before you creating your DMVPN connections. You can use SDM to configure DMVPN.";
var links_dmvpnhubspoke_worksheet_3="Does your router have a crypto image?";
var links_dmvpnhubspoke_worksheet_4="Is your IOS image later that 12.3(8)T1 or 12.3(9)";
var links_dmvpnhubspoke_worksheet_5="Is the VPN peer device accessible from this router?";
var links_dmvpnhubspoke_worksheet_6="Primary Hub�s Information:";
var links_dmvpnhubspoke_worksheet_7="a. IP address of Primary hub�s physical Interface that this spoke router is connecting to";
var links_dmvpnhubspoke_worksheet_8="b. IP address of Primary hub�s mGRE Interface that this spoke router is connecting to";
var links_dmvpnhubspoke_worksheet_9="Interface on this router (spoke) that connects to the Internet";
var links_dmvpnhubspoke_worksheet_10="IP address of this router�s (spoke ) mGRE tunnel interface";
var links_dmvpnhubspoke_worksheet_11="Note: This is an IP address from the pool you defined in step 1";
var links_dmvpnhubspoke_worksheet_12="Advanced Options";
var links_dmvpnhubspoke_worksheet_13="a. NHRP Authentication String";
var links_dmvpnhubspoke_worksheet_14="Note: This must be same on all the routers in the network";
var links_dmvpnhubspoke_worksheet_15="b. NHRP network ID";
var links_dmvpnhubspoke_worksheet_16="c. NHRP hold time";
var links_dmvpnhubspoke_worksheet_17="d. Tunnel Key";
var links_dmvpnhubspoke_worksheet_18="e. Bandwidth";
var links_dmvpnhubspoke_worksheet_19="f. MTU";
var links_dmvpnhubspoke_worksheet_20="g. Tunnel Throughput delay";
var links_dmvpnhubspoke_worksheet_21="Authentication Mechanism - Pre-Shared Keys or Digital Certificates ?";
var links_dmvpnhubspoke_worksheet_22="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_dmvpnhubspoke_worksheet_23="Pre-Shared Key(if Pre-Shared Key chosen in step6)";
var links_dmvpnhubspoke_worksheet_24="Note: Use the same routing protocol that is configured on the hub";


var links_greoveripsec_instructions_1="Instructions to Configure a Peer Device for GRE over IPsec VPN";
var links_greoveripsec_instructions_2="Step1: Launch SDM and navigate to Configure->VPN->Create a secure GRE tunnel";
var links_greoveripsec_instructions_3="Click Launch Selected Task";
var links_greoveripsec_instructions_4="Step 2: Click Next on welcome screen";
var links_greoveripsec_instructions_5="Step 3: In the GRE tunnel Information Screen.";
var links_greoveripsec_instructions_6="a. Select the interface that connects to the peer router or IP address of that interface";
var links_greoveripsec_instructions_7="b. IP address of the tunnel destination - Enter the IP address of the peer router�s WAN interface";
var links_greoveripsec_instructions_8="c. IP address of the GRE tunnel - Enter an IP address for the GRE tunnel interface (this will be a private IP address)";
var links_greoveripsec_instructions_9="Step 4: Backup GRE Tunnel Information";
var links_greoveripsec_instructions_10="If the central site (peer site) has a backup router for resilience, you can check the option to create a backup tunnel and configure the following attributes";
var links_greoveripsec_instructions_11="a. IP address of the backup router's WAN interface at the central site";
var links_greoveripsec_instructions_12="b. Tunnel";
var links_greoveripsec_instructions_13="Step 5: VPN Authentication Information";
var links_greoveripsec_instructions_14="a. Select Pre-shared Keys or Digital Certificate. If Pre-Shared Keys is selected enter the pre-shared key value.";
var links_greoveripsec_instructions_15="Step 5: IKE proposals";
var links_greoveripsec_instructions_16="Check that the existing IKE policies match the IKE policies of the peer router. If not, add new IKE policies that match the IKE policies configured on the peer router.";
var links_greoveripsec_instructions_17="Step 6: Transform Set";
var links_greoveripsec_instructions_18="Select a transform set that matches the transform set configured on the peer router. If a matching transform set is not available, create one.";
var links_greoveripsec_instructions_19="Step 7: Select the routing protocol to match the routing protocol selected on the peer router";
var links_greoveripsec_instructions_20="Step 8: Routing Information.";
var links_greoveripsec_instructions_21="Enter routing protocol specific information.";
var links_greoveripsec_instructions_22="Add private networks, where asked. These networks will be advertised to the peer device using the selected routing protocol.";
var links_greoveripsec_instructions_23="Step 9: Summary of Configuration";


var links_greoveripsec_worksheet_1="Worksheet for GRE over IPsec VPN";
var links_greoveripsec_worksheet_2="Complete this worksheet before you creating your GRE over IPsec VPN connections.";
var links_greoveripsec_worksheet_3="You can use SDM to configure GRE over IPsec VPN.";
var links_greoveripsec_worksheet_4="Does your router have a crypto image?";
var links_greoveripsec_worksheet_5="Is the VPN peer device accessible from this router?";
var links_greoveripsec_worksheet_6="IP address of peer device";
var links_greoveripsec_worksheet_7="Note: This is the Tunnel destination";
var links_greoveripsec_worksheet_8="GRE Tunnel source interface OR";
var links_greoveripsec_worksheet_9="GRE Tunnel source IP address";
var links_greoveripsec_worksheet_10="Note: This is usually the WAN Interface or IP address of WAN interface";
var links_greoveripsec_worksheet_11="IP address of the GRE tunnel interface on this router";
var links_greoveripsec_worksheet_12="Note: This will be a private IP address";
var links_greoveripsec_worksheet_13="Enable path MTU discovery";
var links_greoveripsec_worksheet_14="Checked";
var links_greoveripsec_worksheet_15="Backup GRE Tunnel";	
var links_greoveripsec_worksheet_16="Note: If the central site (peer site) has a backup router for resilience, you can check this option.";
var links_greoveripsec_worksheet_17="If you check this option enter the IP address of the backup router�s WAN interface at the central site and Tunnel information.";
var links_greoveripsec_worksheet_18="Authentication Mechanism - Pre-Shared Keys or Digital Certificates?";
var links_greoveripsec_worksheet_19="Note: If you use digital certificates make sure a digital certificate is configured on the router";
var links_greoveripsec_worksheet_20="Pre-Shared Key(if Pre-Shared Key chosen in step6)";
var links_greoveripsec_worksheet_21="If you chose Static Routing,";
var links_greoveripsec_worksheet_22="Tunnel All Traffic and Split Tunnel network";


var links_site2site_instructions_1="Instructions to Configure A Peer Device for Site-to-Site VPN";
var links_site2site_instructions_2="Step1: Launch SDM and navigate to Configure->VPN->Create a Site-to-Site VPN";
var links_site2site_instructions_3="Click Launch Selected Task.";
var links_site2site_instructions_4="Step2: Select Quick setup or step-by-step wizard on Site-to-Site VPN Screen.";
var links_site2site_instructions_5="Step3: If you select Quick setup, enter the details in VPN Connection Information";
var links_site2site_instructions_6="a.      Select the interface for the VPN connection";
var links_site2site_instructions_7="b.      Select the Type of peer(s) used for the VPN connection";
var links_site2site_instructions_8="c.      If you select the peer with static IP address enter the IP address of the remote peer.";
var links_site2site_instructions_9="d.      Authentication - Select pre-shared key or digital certificate. If preshared key is selected enter pre-shared keys";
var links_site2site_instructions_10="e.      Enter Traffic information between source and destination.";
var links_site2site_instructions_11="Step 4: Summary of Configuration";
var links_site2site_instructions_12="Step5: If you select the step-by-step wizard from the Site-to-Site VPN Screen enter the details in VPN Connection information screen.";
var links_site2site_instructions_13="a.      Select the interface for the VPN connection";
var links_site2site_instructions_14="b.      Select the Type of the peer(s) used for the VPN connection.";
var links_site2site_instructions_15="c.      If you select the peer with static IP address enter IP address of the remote peer.";
var links_site2site_instructions_16="d.      Authentication - Select pre-shared key or digital certificate. If preshared key is selected enter pre-shared keys";
var links_site2site_instructions_17="Step 6: IKE proposals";
var links_site2site_instructions_18="Check that the existing IKE policies match the IKE policies of the peer router. If not, add new IKE policies that match the IKE policies configured on the peer router.";
var links_site2site_instructions_19="Step 7: Transform Set";
var links_site2site_instructions_20="Select a transform set that matches the transform set configured on the peer router. If a matching transform set is not available, create one.";
var links_site2site_instructions_21="Step8: Traffic Information";
var links_site2site_instructions_22="Enter the IP address and subnet mask of the network where IPsec traffic originates, Enter the IP address and subnet mask of the destination network or Select an IPsec rule that defines the traffic types to be protected.";


var links_site2site_worksheet_1="Worksheet for Site-to-Site VPN";
var links_site2site_worksheet_2="Complete this worksheet before you creating your site-to-site VPN connections.";
var links_site2site_worksheet_3="You can use SDM to configure site-to-site VPN.";
var links_site2site_worksheet_4="Does your router have a crypto image?";
var links_site2site_worksheet_5="Is the VPN peer device accessible from this router?";
var links_site2site_worksheet_6="Interface for the VPN Connection.";
var links_site2site_worksheet_7="IP address of the peer device";
var links_site2site_worksheet_8="Authentication Mechanism - Pre-Shared Keys or Digital Certificates?";
var links_site2site_worksheet_9="Note:- If you use digital certificates make sure a digital certificate is configured on the router";
var links_site2site_worksheet_10="Pre-Shared Key(if Pre-Shared Key chosen in step 3)";
var links_site2site_worksheet_11="Traffic to Protect - You can protect all the traffic between a particular source and destination subnet, or specify an IPsec rule that defines the traffic types to be protected.";


var links_webvpn_worksheet_1="Worksheet for SSL VPN";
var links_webvpn_worksheet_2="Complete this worksheet before you create your SSL VPN connections. You can use SDM to configure SSL VPN.";
var links_webvpn_worksheet_3="Does your router have a crypto image?";
var links_webvpn_worksheet_4="Is your IOS image later that 12.4(6)T1 or later?";
var links_webvpn_worksheet_5="Do you have an AAA server accessible from your router?";
var links_webvpn_worksheet_6="Creating a SSL VPN Gateway";
var links_webvpn_worksheet_7="a. SSL VPN gateway IP address";
var links_webvpn_worksheet_8="b. Name for your SSL VPN";
var links_webvpn_worksheet_9="c. Digital certificate to use for the gateway.";
var links_webvpn_worksheet_10="User Authentication";
var links_webvpn_worksheet_11="a. Select the authentication method";
var links_webvpn_worksheet_12="b. Add users or radius servers accordingly based on the authentication type you chose.";
var links_webvpn_worksheet_13="Configure the Intranet Websites for the SSL VPN Context.";
var links_webvpn_worksheet_14="Enable the Full Tunnel configuration and provide the parameters";
var links_webvpn_worksheet_15="a. IP Address Pool name";
var links_webvpn_worksheet_16="b. If you choose to install the SVC client in your router, then provide the install package location.";
var links_webvpn_worksheet_17="Choose a pre-defined theme to customize the SSL VPN portal page.";
