var msg_launch_title =
    "Launch Page";
var msg_unsupported_ie =
    "Unsupported browser version (need at least version 5.5).";
var msg_unsupported_ns =
    "Unsupported browser version (need at least version 7.1).";
var msg_unsupported_ff =
    "Unsupported browser version (need at least version 1.0.2).";
var msg_unsupported_unk =
    "Unsupported browser.";
var msg_app_info1 =
    "for";
var msg_app_info2 =
    "will open in another window.  Do";
var msg_app_info3 =
    "not close this window until you";
var msg_app_info4 =
    "exit";
var msg_continue_warning1 =
    "You can continue, but proper functioning of";
var msg_continue_warning2 =
    "is not guaranteed.";
var msg_App_Information = "<BR><BR> {0} for <B> {1} </B> will open in another window.  Do<BR> not close this window until you <BR> exit {2} .";
    
