var msg_checking_files = 
    "Checking local files, please wait ...";
var msg_popup_warning =
    "If nothing appears, you may have a popup blocker which should be" +
    " deactivated for this application.";
