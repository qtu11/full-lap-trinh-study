/*
*------------------------------------------------------------------
* appsui.js --  Applications User Interface Utilities
*
* March 2002,
*
* Copyright (c) 2003 by cisco Systems, Inc.
* All rights reserved.
*------------------------------------------------------------------
*/

var sdmFsName = getFsName(unescape(parent.location.search), "sdm");
var homeFsName = getFsName(unescape(parent.location.search), "home");
var commonFsName = getFsName(unescape(parent.location.search), "common");

var sdmExists = " ";
var ipsExist = " ";
var validIPSExist = " ";
function imageFailed(arg) {
   if(ipsExist.indexOf("yes") != -1) {
	validIPSExist = "no";
   } else {
	sdmExists = "no";
   }
  return;
}
function imageSucceeded(arg) {
if(ipsExist.indexOf("yes") != -1) {
   validIPSExist = "yes";
 } else {
   sdmExists = "yes";
 }
  return;
}
var theSdmLoc = null;
var theSdmArgs = null;
var existCheck = null;
function checkWhetherExists(sdmloc, sdmargs) {
    // workaround for Netscape 7.x regression (doesn't simultaneously
    // attempt to load files, transform to URL)
    if (sdmloc.indexOf("http") != 0) {
        var i = sdmloc.indexOf(":"); // drive prefix
        sdmloc = "file:///" + sdmloc.substring(0,i+1) + "/" + 
            sdmloc.substring(i+2,sdmloc.length);
    }
    if(ipsExist.indexOf("yes") != -1) {
	existCheck = new Image();
	existCheck.onerror = imageFailed;
	existCheck.onload = imageSucceeded;
	var url = sdmloc + "/ipsloading.gif";
	existCheck.src = url;
    } else {
	    existCheck = new Image();
	    existCheck.onerror = imageFailed;
	    existCheck.onload = imageSucceeded;
	    var url = sdmloc + "/rsdm_splash.gif";
	    existCheck.src = url;
    }
    theSdmLoc = sdmloc;
    theSdmArgs = sdmargs;
    setTimeout(existTest, 200);
}
function existTest() {
    if((ipsExist.indexOf("yes") != -1) && (validIPSExist.indexOf("yes") != -1)) {
	 launchLocalIPS(theSdmLoc, theSdmArgs);
    }else
    if (sdmExists.indexOf("yes") != -1) {
        launchLocal(theSdmLoc, theSdmArgs);
    } else 
    if (sdmExists.indexOf("no") != -1) {
        // location cookie invalid
        url = 'locator.shtml'+ parent.location.search;
        launchWindow = window.open(url, 'SDM_Locator', calcWindowArgs(480, 240));
    }else 
    if (validIPSExist.indexOf("no") != -1) {
       alert('IPS is not found in the PC');
    return;
    } 
    else {
        // continue checking
        setTimeout(existTest, 200);  
    }
}
function getFsName(args, fname) {
    var fs = "";
    var index = args.indexOf(fname + "FS=");
    if (index != -1) {
        var endIndex = args.indexOf("&", index);
        if (endIndex == -1) {
            fs = args.substring(index + fname.length + 3);
        } else {
            fs = args.substring(index + fname.length + 3, endIndex);
        }
    }
    return fs;
}

var args = unescape(parent.location.search);
function removeBadCharsFromHostname (s)
{
var BAD_CHARS = '-.';
for (var ii = 0; ii < BAD_CHARS.length; ii++)
{
var c = BAD_CHARS.charAt(ii);
while (s.indexOf(c)>= 0) 
{
s = s.substring(0, s.indexOf(c)) + s.substr(s.indexOf(c)+1);
}
}
return s;
}
var protocolStr = parent.location.protocol;

function calcWindowArgs(w, h) {
    var x = (screen.width - w)/2;
    var y = (screen.height - h)/2;
    return "width="+w+",height="+h+",top="+y+",left="+x+",resizable=no,scrollbars=no,status=yes";
}

function launchIPSApplet() { 

var port1 = '';
if (parent.location.port != '')
{
if ((protocolStr == 'http:'  && parent.location.port != 80)
|| (protocolStr == 'https:' && parent.location.port != 443))
{
port1 = ':'+parent.location.port;
}
}

var args1 = unescape(location.search);
var url1 = '';
var fsArgs1 = '';
if (args1 && (args1.length > 1)) {
    if (args1.indexOf("sdmFS=") == -1) {
        fsArgs1 = '&sdmFS=' + sdmFsName + '&homeFS=' + homeFsName;
    }
} else {
    fsArgs1 = '?sdmFS=' + sdmFsName + '&homeFS=' + homeFsName;
}

if (!sdmFsName || (sdmFsName.length == 0)) {
    // no sdm on router, try "remote SDM"
    //var localSDM1 = "D:\\Documents and Settings\\vnarayap\\Desktop\\sdm\\ips";//getcookie("SDMHOME");
    var localSDM1 = getcookie("SDM_Locator")+"\\ips";
    ipsExist ="yes";
    checkWhetherExists(localSDM1, parent.location.search + fsArgs1);
     
    return;
}
if (args1 && args1.length> 1){
 url1 = protocolStr+'//'+parent.location.hostname+port+'/archive/'+sdmFsName+'sdm/sdm/runSDM.shtml'+parent.location.search+fsArgs+'#';
} else {
 url1 = protocolStr+'//'+parent.location.hostname+port+'/archive/'+sdmFsName+'sdm/sdm/runSDM.shtml'+fsArgs+'#';
}
if (launchWindow1 == null || launchWindow1.closed) {
launchWindow1 = window.open(url1,'sdm'+removeBadCharsFromHostname(parent.location.hostname), calcWindowArgs(600,480));
}
}
var launchWindow = null;
function launchLocalIPS(loc1, allArgs1) {
     var url2 = 'launcher1.shtml' + allArgs1;// + '&locator=' + loc1;
    //launchWindow = window.open(url2,'sdm'+removeBadCharsFromHostname(parent.location.hostname), calcWindowArgs(600,480));
    //launchWindow1 = window.open(url2,'IPSFrame', calcWindowArgs(600,480));
    document.location = url2;
}
