var msg_app_launch_title =
    "Cisco Router Home Page - Launching";
var msg_app_descriptor =
    "Cisco Router and Security Device Manager (SDM)";
var msg_browser_label =
    "Browser:";
var msg_browser_ie =
    "Internet Explorer";
var msg_browser_netscape =
    "Netscape";
var msg_browser_firefox =
    "Firefox";
var msg_browser_unknown =
    "Unknown";
var msg_javastate_label =
    "Java:";
var msg_javastate_enabled = 
    "Enabled";
var msg_javastate_disabled =
    "Not enabled";
var msg_info_closewindow =
    "Application will open in another window. If you wish, you can close this window.";
var msg_info_copyright =
    "Copyright &#169; 2002-2007 Cisco Systems, Inc. All rights reserved.";

