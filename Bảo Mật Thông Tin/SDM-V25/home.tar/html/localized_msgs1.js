var msg_startup_err = 
    "Startup Error";
var msg_startup_err_ext = 
    " has not been granted with the necessary privileges in order to startup successfully, " +
    "or another unknown error occurred during startup." +
    "Please close all involved browser windows and try again by granting all requested privileges.";
var msg_ips_notfound = 
    "IPS is not found in the PC";
var msg_close_window =
    "Close Window";
    