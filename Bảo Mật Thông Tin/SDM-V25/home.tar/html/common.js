// Copyright (c) 1999, 2000, 2001, 2002 by cisco Systems, Inc.

//this returns the value needed to modify the html page
function getcookie(cookiename) {
var cookiestring=""+document.cookie;
var index1=cookiestring.indexOf(cookiename)
if (index1==-1 || cookiename=="") return ""; 
var index2=cookiestring.indexOf(';',index1);
if (index2==-1) index2=cookiestring.length; 
var c = unescape(cookiestring.substring(index1+cookiename.length+1,index2));
return c;
}

function cookieLifeTime()
{
var UTCstring;
Today = new Date();
nomilli=Date.parse(Today);
Today.setTime(nomilli+365*24*60*60*1000);
UTCstring = Today.toUTCString();
return UTCstring;
}

function setcookie(name, value)
{
cookiestring=name+"="+value+";EXPIRES="+cookieLifeTime();
document.cookie=cookiestring;
if(!getcookie(name))
{
return false;
}
else
{
return true;
}
}
