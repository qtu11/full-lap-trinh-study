var msg_browser_unsupported1 =
    "SDM requires at least Internet Explorer 5.5, Netscape Navigator 7.1, or Firefox 1.0.2.\n" +
    "Your browser does not seem to meet these requirements.";
var msg_browser_unsupported2 = 
    "You can continue, but proper functioning is not guaranteed.";
var msg_java_required =
    "SDM is a Java-based application. It appears that Java is either not supported " +
    "or not enabled on your browser. Please use a different browser, or enable Java in your " +
    "current browser to run SDM.";
var msg_ie_version =
    "Internet Explorer version";
var msg_netscape_version =
    "Netscape version";
var msg_firefox_version =
    "Firefox version";
var msg_popup_warning1 =
    "You have an active popup blocker.  Please disable it for";
var msg_popup_warning2 =
    "to function";
var msg_https_warning1 =
    "You are using HTTP to connect to the router.";
var msg_https_warning2 =
    "A more secure protocol (HTTPS) is available.";
var msg_https_warning3 =
    "Click OK to use HTTPS, or Cancel to continue with HTTP."; 
