var msg_locator_title = 
  "SDM Application Locator";
var msg_default_locator_path = 
  "C:\\Program Files\\Cisco Systems\\Cisco SDM";
var msg_locator_dialog_heading = 
  "SDM Application Locator";
var msg_app_notfound = 
  "Cisco SDM was not found on this router.  Please enter the location where Cisco SDM has been installed.";
var msg_bad_location = 
  "The program does not appear to be accessible at this location:";
var msg_save_location = 
  "Save this location";
var msg_btn_continue = 
  "Continue";
var msg_user_without = 
  "If you do not have SDM, please use the following link to download SDM:";
var msg_download_sdm = 
  "Download SDM";
var msg_no_cookies = 
  "Cookies are not enabled, location will not be saved.";
var msg_bad_location_change = 
  "The program does not appear to be accessible at this location.  Change location?";
var msg_btn_cancel = 
  "Cancel";
