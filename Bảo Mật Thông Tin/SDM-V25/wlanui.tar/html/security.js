/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */
/*
 ####################################################################
 ### Author : Ramya
 ### Version :1.0
 ### Used the split logic to check the get the radio interface
 ####################################################################
*/

document.write('<script language="javascript" src="resources.js"></script>');

//Must src cookies.js before srcing this file!
var ssidCookie = new Cookie(document, "ssidRadioData")
var vlanCookie = new Cookie(document, "vlanSetting")

function setSSIDPage(radio)
{
  var radio_value=radio;
   
  ssidCookie.radio = radio_value;
 
  ssidCookie.store()
}

function setVLANPage(radio)
{
  vlanCookie.radio = radio
  vlanCookie.store()
}

//showInt is output of show interfaces
function AddSSIDMenuLink(showInt, product, path)
{
  var radioArray = getRadioInterfaces(showInt,product);
  var menuCode = "";
 if (radioArray.length > 0) {
    menuCode += '                <tr> ';
    if(path)
    {
        menuCode += '                  <td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>';
    }
    else
    {
        menuCode += '                  <td bgcolor="#cccccc" background="../../images/apps_leftnav_yellow.gif">&nbsp;</td>';
    }
    menuCode += '                  <td bgcolor="#cccccc">&nbsp;</td>';
    
    if (atg_ret_value == 1)
        {
	if (path)
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink">'+ssidBold;
	}
	else
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink">'+ssidBold;
	}
    }
    else if (atg_ret_value == 2)
    {
        var temp_number= radioArray[0].number.split("/");
        var first_split= temp_number[0];
        var second_split= temp_number[1];
        var third_split= temp_number[2];
  
	if (path)
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+third_split+')" class="apphinavchild"><span class="apphinavchildlink">'+ssidBold;
	}
	else
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+third_split+')" class="apphinavchild"><span class="apphinavchildlink"> '+ssidBold;
	}
    }
    else
    {
	if (path)
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> '+ssidBold;
	}
	else
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-client-security.shtml" onClick="setSSIDPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> '+ssidBold;
	}
    }
    menuCode += managerVal+'                   </span></a></td>';
    menuCode += '                  <td bgcolor="#cccccc">&nbsp;</td>';
    menuCode += '                </tr>';
    menuCode += '                <tr> ';
    if (path)
    {
        menuCode += '                  <td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    else
    {
        menuCode += '                  <td colspan="4" bgcolor="003333"><img src="../../images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    menuCode += '                </tr>';
  }
  document.writeln(menuCode)
}

//showInt is output of show interfaces
function AddKeyMenuLink(showInt, product, path)
{

  var radioArray = getRadioInterfaces(showInt,product);
  var menuCode = "";
  if (radioArray.length > 0) {
    menuCode += '                <tr> ';
    if (path)
    {
        menuCode += '                  <td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>';
    }
    else
    {
        menuCode += '                  <td bgcolor="#cccccc" background="../../images/apps_leftnav_yellow.gif">&nbsp;</td>';
    }
    menuCode += '                  <td bgcolor="#cccccc">&nbsp;</td>';
    if (atg_ret_value == 1)
    {
	if (path)
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-key-security.shtml" onClick="setVLANPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
	else 
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-key-security.shtml" onClick="setVLANPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
    }
    else if (atg_ret_value == 2)
    {
        var temp_number= radioArray[0].number.split("/");
       var first_split= temp_number[0];
       var second_split= temp_number[1];
        var third_split= temp_number[2];
       
	if (path)
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-key-security.shtml" onClick="setVLANPage('+third_split+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
	else
	{
            menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-key-security.shtml" onClick="setVLANPage('+third_split+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
        
    }
    else
    {
	if (path)
	{
         menuCode += '                  <td bgcolor="#cccccc"><a href="'+path+'atg_sec_ap-key-security.shtml" onClick="setVLANPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
	else
	{
         menuCode += '                  <td bgcolor="#cccccc"><a href="atg_sec_ap-key-security.shtml" onClick="setVLANPage('+radioArray[0].number+')" class="apphinavchild"><span class="apphinavchildlink"> ';
	}
    }
    
    menuCode += encryptionManager+'                    </span></a></td>';
    menuCode += '                  <td bgcolor="#cccccc">&nbsp;</td>';
    menuCode += '                </tr>';
    menuCode += '                <tr> ';
    if (path)
    {
        menuCode += '                  <td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    else
    {
        menuCode += '                  <td colspan="4" bgcolor="003333"><img src="../../images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    menuCode += '                </tr>';
  }
  document.writeln(menuCode)
}

/*
function TurnOnAAA()
{
    var cmd = "aaa new-model[configure]\n"
    
    cmd += "radius-server attribute 32 include-in-access-req format %h[configure]\n"  
    cmd += "radius-server vsa send accounting[configure]\n"  
    cmd += "ip radius source-interface BVI1[configure]\n"    

    cmd += "aaa group server radius rad_eap[configure]\n"                     
    cmd += "aaa authentication login eap_methods group rad_eap[configure]\n"  

    cmd += "aaa group server radius rad_mac[configure]\n"               
    cmd += "aaa authentication login mac_methods local[configure]\n"    

    cmd += "aaa group server radius rad_acct[configure]\n"                                
    cmd += "aaa accounting network acct_methods start-stop group rad_acct[configure]\n"   

    cmd += "aaa group server radius rad_admin[configure]\n"                

    cmd += "aaa group server tacacs+ tac_admin[configure]\n"                

    cmd += "aaa group server radius rad_pmip[configure]\n"                       
    cmd += "aaa authorization ipmobile default group rad_pmip[configure]\n"      
    cmd += "aaa group server radius dummy[configure]\n"
    //need this to perform authorization on users once aaa is enabled
    cmd += "aaa authorization exec default local[configure]\n"
    return cmd
}

*/

function TurnOnAAA()
{
   var cmd = "aaa new-model[configure]\n"
                
        cmd += "radius-server vsa send accounting[configure]\n"
        
          
           cmd += "aaa group server radius rad_eap[configure]\n"                     
           cmd += "aaa authentication login eap_methods group rad_eap[configure]\n"  
       
           cmd += "aaa group server radius rad_mac[configure]\n"               
           cmd += "aaa authentication login mac_methods local[configure]\n"    
       
           cmd += "aaa group server radius rad_acct[configure]\n"                                
           cmd += "aaa accounting network acct_methods start-stop group rad_acct[configure]\n"   
       
           cmd += "aaa group server radius rad_admin[configure]\n"                
       
           cmd += "aaa group server tacacs+ tac_admin[configure]\n"                
       
           cmd += "aaa group server radius rad_pmip[configure]\n"                       
           cmd += "aaa authorization ipmobile default group rad_pmip[configure]\n"      
           cmd += "aaa group server radius dummy[configure]\n"
           
           //need this to perform authorization on users once aaa is enabled
          cmd += "radius-server attribute 32 include-in-access-req format %h[configure]\n" 
          
    return cmd
}
