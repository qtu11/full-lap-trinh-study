/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

function cmpNetAdd(netAdd1, netMask1, netAdd2, netMask2)
{
    var netOctetList1 = getOctet(netAdd1);
    var maskOctetList1 = getOctet(netMask1);
    var netOctetList2 = getOctet(netAdd2);
    var maskOctetList2 = getOctet(netMask2);

    if (netOctetList1[0] == netOctetList2[0])
    {
        if (maskOctetList1[0] == 255 && maskOctetList1[1] == 255 && maskOctetList1[2] == 255)
	{
	    if (netMask1 == netMask2)
	    {
	         if (getNetAdd(netAdd1, netMask1) == getNetAdd(netAdd2, netMask2))
		     return true;
		 else
		     return false;
	    }
	    else
	    {
	        if (getNetAdd(netAdd1, "255.255.0.0") == getNetAdd(netAdd2, "255.255.0.0"))
	        { 
		    return true;
	        }
	        else 
	        {
		    return false;
	        }
	    }
	}
	else
	{
	    if (getNetAdd(netAdd1, netMask1) == getNetAdd(netAdd2, netMask2))
	        return true;
	    else 
	        return false;
	}
    }
    else
    {
	return false;
    }
}

function getOctet(netAdd)
{
    var fieldArray = netAdd.split(".");
    var octetlist = new Array;

    octetlist[0] = parseInt(fieldArray[0], 10);
    octetlist[1] = parseInt(fieldArray[1], 10);
    octetlist[2] = parseInt(fieldArray[2], 10);
    octetlist[3] = parseInt(fieldArray[3], 10);

    return octetlist;
}

function getNetAdd(netAdd, netMask)
{
    var netOctetList = getOctet(netAdd);
    var maskOctetList = getOctet(netMask);
    var netAdd = "";

    for (var i = 0; i < 4; i++)
    {
	var netVal = netOctetList[i] & maskOctetList[i];
	netAdd += String(netVal) + ".";
    }
    return netAdd;
}

function addNetMap(modelNo, path, self) {
    if (modelNo != 1 || product.match("1812W") || product.match("1812W-J") || product.match("1802W") || product.match("1803W") || product.match("1811W") || product.match("1801W"))
    {
    var menuCode = ''; 

    menuCode += '<tr>';
    if (path == "../../")
    {
        menuCode += '<td bgcolor="#669999" background="'+path+'images/apps_leftnav_green.gif"><img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>';
        menuCode += '<td colspan="4" bgcolor="#669999"><a href="#"></a><a href="'+path+'atg_network-map.shtml" class="apphinavpeer">'+wirelessNetworkMap+'</a></td>';
    }
    else if (self)
    {
        menuCode += '<td bgcolor="#669999" background="images/apps_leftnav_yellow.gif"><img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>';
        menuCode += '<td colspan="4" bgcolor="#ffffff"><a href="#"></a><a href="atg_network-map.shtml" class="apphinavchild">'+wirelessNetworkMap+'</a></td>';
    }
    else
    {
        menuCode += '<td bgcolor="#669999" background="images/apps_leftnav_green.gif"><img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>';
        menuCode += '<td colspan="4" bgcolor="#669999"><a href="#"></a><a href="atg_network-map.shtml" class="apphinavpeer">'+wirelessNetworkMap+'</a></td>';
    }
    menuCode += '</tr>';
    menuCode += '<tr>';
    if (path == "../../")
    {
        menuCode += '<td colspan="4" bgcolor="003333"><img src="'+path+'images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    else
    {
        menuCode += '<td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>';
    }
    menuCode += '</tr>';
    document.write(menuCode);
    }
}

function getRadioBtnNumber(intNum)
{
    var btnNum;

    if (atg_ret_value == 1)  {
        btnNum = intNum.number
    }
    else if (atg_ret_value == 2)
    {
        var number_split = intNum.number
        var temp_number= number_split.split("/")
        var first_split= temp_number[0];
        var second_split= temp_number[1];
        var third_split= temp_number[2];
        var btnNum =eval(first_split + second_split + third_split);
    }
    else
    {
        var btnNum = intNum.number
    }
    return btnNum;
}

function privPath() {
    return "level/15/";
}

function fillSendVal(path)
{
    var pathprefix;
    if (path)
    {
	pathprefix = location.pathname.replace(/\/([^\/]*)\.shtml/, "/back.shtml"); 
    }
    else
    {
        pathprefix = location.pathname.replace(/\/([^\/]*)\/([^\/]*)\/([^\/]*)\.shtml/, "/back.shtml");
    }
    if (pathprefix)
    {
	document.write('<input type="hidden" name="send" value="'+pathprefix+'">');
    }
}

function isATG(product) {
   if (product.match("878W") || product.match("851W") || product.match("857W") || product.match("871W") || product.match("876W") || product.match("877W") || product.match("1812W") || product.match("1812W-J") || product.match("1801W") || product.match("1802W") || product.match("1803W") || product.match("1811W")) 
      {
      return 1;
      }
      else if (product.match("2811") || product.match("2821") || product.match("2851") || product.match("3845") || product.match("2801") || product.match("1841") || product.match("3825"))
      {
      return 2;
      }
      else
      {
      return 3;
   }
}
function childMenu(exist, current, target, nameMenu, nameCLI)
{
  if (target.match("level/15/"))
  {
      document.write('<tr><td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td></tr>');
      document.write('<tr><td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>');
  }
  else
  {
      document.write('<tr><td colspan="4" bgcolor="003333"><img src="../../images/pixel.gif" alt="" border="0" width="1" height="1"></td></tr>');
      document.write('<tr><td bgcolor="#cccccc" background="../../images/apps_leftnav_yellow.gif">&nbsp;</td>');
  }
  document.write('<td bgcolor="#cccccc">&nbsp;</td>');
  document.write('<td bgcolor="#cccccc">');
  if (exist) {
    if (current) {
      document.write('<a href='+target+' class="apphinavchild">');
      document.write(nameMenu);
    } else {
      document.write('<a href='+target+' class="apphinavchildlink">');
      document.write(nameMenu);
    }
    document.write('</a>');
  } else {
    document.write('<font color="#666666" face="Arial, Helvetica, sans-serif" size="2">');
    document.write(nameMenu);
    document.write('</font>');
  }
  document.write('</td><td bgcolor="#cccccc">&nbsp;</td></tr>');
}

function mainMenu(target,nameMenu, plus){

  document.write('<tr>')
  document.write('<td bgcolor="#669999" background="images/apps_leftnav_green.gif"><img src="images/pixel.gif" alt="" width="8" height="17" border="0"></td>')
  document.write('<!-- note the double href tag to make the whole table cell a link in IE -->')
  document.write('<td colspan="2" bgcolor="#669999"><a href="#"></a><a href="' + target + '" class="apphinavpeer">' + nameMenu +'</a></td>')
  if(plus){
    document.write('<td bgcolor="#669999" width="33" >')
    document.write('<div align="center"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"><img src="images/hinav_plus.gif" width="13" height="7"></div>')
    document.write('</td>')
  }else{
    document.write('<td bgcolor="#669999" >')
    document.write('<div align="center"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></div>')
    document.write('</td>')
  }
  document.write('</tr>')
  document.write('<tr>')
  document.write(' <td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td>')
  document.write('</tr>')

}

//input - AES support to be tested, show controller | include AES

function aesFind(showAes)
{
var pattern = "AES"
if(showAes.indexOf(pattern) != -1)
    return true;
  else
    return false;
}

//input - radio number, show html-support radio-role, role-to-be-tested

function radioRole(radio, roleStr, role) {

  var rad = "Dot11Radio" + radio;
  var line = grep_string(rad, roleStr);

  if (line == null)
      return false;

  if (token_string(DLIM_WhSp_slash, 3, line) == role)
      return true;
  else
     return false;
}


// ture - if 1300 radio 0 station role is one of the following:
// station-role root ap-only [fallback <repeater|shutdown>]

