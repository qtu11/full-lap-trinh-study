/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */
 
/* atg_assoc.shtml */ 
var expressSetup = "Radio Express Setup";
var wireLessMgmtTitle = " Wireless Management Cisco ";
var wireLessMgmtTitle1 = " Router - Express Setup";
var routerMgmtTitle = " Router - ";

var wireLessExpressSecurity = "Wireless Express Security";
var wireLessExpressSetup = "Wireless Radio Express Setup";
var wireLessAssociation = "Wireless Association";
var wireLessInterfaces = "Wireless Interfaces";
var wireLessSecurity = "Wireless Security";
var wireLessServices = "Wireless Services";

var hostNameValue = "Hostname";
var wirelessMgmtCisco = "Wireless Management - Cisco ";
var routerValue = " Router";


var optimizeRadioNetwork = "Optimize Radio Network for:";
var roleInRadioNetwork = "Role in Radio Network:";
var accessPointRoot = "Access Point Root";
var rootBridge = "Root Bridge";
var nonRootBridge = "Non - Root Bridge";
var universalClient = "Universal Client";
var throughPut = "Throughput";
var rangeValue = "Range";
var defaultValue = "Default";
var customValue = "Custom";
var airoNetExtnEx = "Aironet Extensions:";
var enableValue = "Enable";
var disableValue = "Disable";

/* atg_express-security.shtml */
var BridgingVal = "Bridging";
var RoutingVal = "Routing";
var connectionSelection = "Connection Selection ";
var wirelessMgmtExpressSecurity = "Router - Express Security";

/* atg_express-security-brg.shtml */
var wirelessMgmtExpTitle = "Express Security Bridging";
var ssidConfig = "SSID Configuration";
var ssidVal = "1. SSID";
var broadCastSSIDBeacon = "Broadcast SSID in Beacon";
var vlanVal = "2. VLAN";
var noVLAN = "No VLAN";
var enableVLAN = "Enable VLAN ID: ";
var vlanNumber = "(1-4094)";
var nativeVLAN = "Native VLAN";
var bridgeVal = "3. Bridge";
var bridgeGroupNumber = "Bridge Group Number:";
var bridgeGroupRange = "(1-255)";
var bridgeSecurity = "4. Security";
var bridgeNoSecurity = "No Security";
var bridgeStaticWEPKey = "Static WEP Key";
var bridgeStaticWEPKey1 = "Key 1";
var bridgeStaticWEPKey2 = "Key 2";
var bridgeStaticWEPKey3 = "Key 3";
var bridgeStaticWEPKey4 = "Key 4";
var bridgeKeySize1 = "128 bit";
var bridgeKeySize2 = "40 bit";
var bridgeEAPAuthentication = "EAP Authentication";
var bridgeRadiusServer = "RADIUS Server:";
var bridgeHostIPAddress = "(Hostname or IP Address)";
var bridgeRadiusServerSecret = "RADIUS Server Secret:";
var bridgeWPA = "WPA";
var bridgeSSIDTable = "SSID Table";
var bridgeSSID = "  SSID ";
var bridgeVLAN = "  VLAN ";
var bridgeGrpNumber = "  Bridge Grp. Number";
var bridgeEncryption = "  Encryption ";
var bridgeAuthentication = " Authentication";
var bridgeKeyMgmt = " Key Management";
var bridgeNativeVLan = "  Native VLAN";
var broadCastSSID = " Broadcast SSID";

/* atg_express-security-rte.shtml */

var expressSecurityRouting = "Express Security Routing";
var routingIPProtocol = "3. IP Protocol";
var routingIPAddress = "IP Address:";
var routingIPSubnetMask = "IP Subnet Mask:";
var routingIPAddressNetmask = "IP Address/Netmask ";

/* atg_assoc.shtml */

var Association = "Association";
var activityTimeOut = "Activity Timeout";
var assocClients = "Clients: ";
var assocRepeaters = "Repeaters: ";
var assocRepeater = "Repeater ";
var assocClient = "Client ";
var assocView = "View:";

/* atg_assoc_adv.shtml */
var assocAdvActivityTimeout = "- Activity Timeout";
var AssociationCol = "Association:";
var deviceClass = "Device Class";
var deviceDefaultValueOptional = " Default (optional) (1-100000 sec)";
var deviceDefaultValueMaximum = " Maximum (optional) (1-100000 sec)";
var assocAdvBridge = "Bridge";
var assocClientStation = "Client Station ";
var assocWorkGroupBridge = "Workgroup Bridge ";
var assocUnknowCisco = "Unknown (non-Cisco) ";
var assocNotApplicable = "N/A";

/* atg_network-if.shtml */
var networkInterface = "Network Interfaces";
var networkInterfaceSummary = ": Summary";
var networkInterfaceStatus = "Interface Status";
var networkSoftwareStatus = "Software Status";
var networkEnabled = "Enabled";
var networkDisabled = "Disabled";
var networkHardwareStatus = "Hardware Status";
var networkUP = "Up";
var networkDown = "Down";
var networkInterfaceStatus = "Interface Resets";
var networkReceive = "Receive";
var networkInputTimeSpan = " Input Rate Timespan";
var networkInputRate = " Input Rate (bits/sec)";
var networkInputPacketsRate = " Input Rate (packets/sec)";
var networkTimeSince = "Time Since Last Input";
var networkTotalPacketsInput = "Total Packets Input";
var networkTotalBytesInput = "Total Bytes Input";
var networkBroadcastPackets = "Broadcast Packets";
var networkTotalInputErrors = "Total Input Errors";
var networkOverrunErrors = "Overrun Errors";
var networkIgnoredPackets = "Ignored Packets";
var networkThrottles = "Throttles";
var networkTransmit = "Transmit";
var networkOutputRateTimeSpan = " Output Rate Timespan";
var networkOutputRateBits = " Output Rate (bits/sec)";
var networkOutputPackets = " Output Rate (packets/sec)";
var networkTimeSinceLastOutput = "Time Since Last Output";
var networkTotalPacketsOutput = "Total Packets Output";
var networkTotalBytesOutput = "Total Bytes Output";
var networkTotalOutputErrors = "Total Output Errors";
var networkLastOutputHang = "Last Output Hang";

/* atg_network-if_802-11.shtml */

var networkInterfaces802 = "Network Interfaces - 802.11";
var status = "Status";
var statusTitle = "STATUS";
var detailedStatus = "DETAILED STATUS";
var networkInterfaces = "Network Interfaces:";
var configuration = "Configuration";
var operationalRates = "Operational Rates ";
var MbPerSec = "Mb/sec";
var basicRate = "Basic Rate";
var airoNetExtn = "Aironet Extensions ";
var carrierSet = "Carrier Set ";
var currentRadioChannel = "Current Radio Channel";
var transmitterPowerCCK = "Transmitter Power CCK/OFDM";
var transmitterPower = "Transmitter Power ";
var roleInRadioNetwork = "Role in Network";
var roleAccessPointorRoot = "Access Point / Root";
var roleRepeaterNonRoot = "Repeater / Non-Root";
var currentParent = 'Current Parent';
var interfaceStatistics = "Interface Statistics";
var interfaceResets = "Interface Resets";
var receiveTransmitStatistics = "Receive / Transmit Statistics";
var receive = "Receive";
var transmit = "Transmit";
var InputRateBitsPerSec = "5 Min Input Rate (bits/sec)";
var OutputRateBitsPerSec = "5 Min Output Rate (bits/sec)";
var InputRatePackPerSec = "5 Min Input Rate (packets/sec)";
var OutputRatePackPerSec = "5 Min Output Rate (packets/sec)";
var timeSinceLastInput = "Time Since Last Input";
var timeSinceLastOutput = "Time Since Last Output";
var ErrorStat = "Error Statistics";
var Settings = "SETTINGS";

/* atg_network-if_802-11_b.shtml */

var detailedStatusNotBold = "Detailed Status";
var radio = "Radio";
var radioType = "Radio Type ";
var radioSerialNo = "Radio Serial Number";
var radioFirmwareVersion = "Radio Firmware Version ";
var receiveStatistics = "Receive Statistics";
var total = "Total";
var lastFiveSec = "Last 5 Sec ";
var transmitStatistics = "Transmit Statistics";
var hostBytesReceived = "Host Bytes Received";
var hostBytesSent = "Host Bytes Sent";
var unicastPacketReceived = "Unicast Packets Received";
var unicastPacketsSent = "Unicast Packets Sent";
var unicastPacketsHost = "Unicast Packets To Host";
var unicastPacketsSentByHost = "Unicast Packets Sent By Host";
var broadcastPacketsReceived = "Broadcast Packets Received";
var broadcastPacketsSent = "Broadcast Packets Sent";
var beaconPacketsReceived = "Beacon Packets Received";
var beaconPacketsSent = "Beacon Packets Sent";
var broadcastPacketsToHost = "Broadcast Packets To Host";
var broadcastPacketsByHost = "Broadcast Packets By Host";
var multicastPacketsReceived = "Multicast Packets Received";
var multicastPacketsSent = "Multicast Packets Sent";
var multicastReceivedByHost = "Multicasts Received By Host";
var multicastSentByHost = "Multicasts Sent By Host";
var managementPacketsReceived = "Mgmt Packets Received";
var managementPacketsSent = "Mgmt Packets Sent";
var rtsReceived = "RTS Received";
var rtsTransmitted = "RTS Transmitted";
var duplicateFrames = "Duplicate Frames";
var CTSNotReceived = "CTS Not Received";
var CRCErrors = "CRC Errors";
var unicastFragmentsSent = "Unicast Fragments Sent";
var WEPErrors = "WEP Errors";
var retriesValue = "Retries";
var bufferFull = "Buffer full";
var packetsWithOneEntry = "Packets With One Retry";
var hostBufferFull = "Host Buffer Full";
var packetsWithMorethanOneEntry = "Packets With More Than One Retry";
var headerCRCErrors = "Header CRC Errors";
var protocolDefers = "Protocol Defers";
var invalidHeader = "Invalid Header";
var energyDetectDefers = "Energy Detect Defers";
var lengthInvalid = "Length Invalid";
var jammerDetected = "Jammer Detected";
var incompleteFragments = "Incomplete Fragments";
var packetsAged = "Packets Aged";
var RxConcats = "Rx Concats";
var TTxConcats = "Tx Concats";

/*atg_network-if_802-11_c.shtml*/
var settingsShort = "Settings";
var enableRadio = "Enable Radio:";
var currentStatusSoftwareHardware = "Current Status (Software/Hardware):";
var roleInRadioNetwork = "Role in Radio Network:";
var dataRates = "Data Rates:";
var bestRange = "Best Range";
var bestThroughPut = "Best Throughput";
var bestDefault = "Default";
var cckTransmitterPower = "CCK Transmitter Power";
var ofdmTransmitterPower = "OFDM Transmitter Power ";
var transmitterPower = "Transmitter Power ";
var limitClientPower = "Limit Client Power ";
var defaultRadioChannel = "Default Radio Channel:";
var leastCongestedFrequency = "Least-Congested-Frequency";
var channelFreq1 = "Channel 1 - 2412 MHz";
var channelFreq2 = "Channel 2 - 2417 MHz";
var channelFreq3 = "Channel 3 - 2422 MHz";
var channelFreq4 = "Channel 4 - 2427 MHz";
var channelFreq5 = "Channel 5 - 2432 MHz";
var channelFreq6 = "Channel 6 - 2437 MHz";
var channelFreq7 = "Channel 7 - 2442 MHz";
var channelFreq8 = "Channel 8 - 2447 MHz";
var channelFreq9 = "Channel 9 - 2452 MHz";
var channelFreq10 = "Channel 10 - 2457 MHz";
var channelFreq11 = "Channel 11 - 2462 MHz";
var maxValue = "Max";
var channel = "Channel";
var mhzValue = " MHz";
var leastCongestedChannelSearch = "Least Congested Channel Search:";
var useOnlySelectedChannel = "(Use Only Selected Channels)";
var radioPreamble = "Radio Preamble";
var ethernetEncapsulationTransform = "Ethernet Encapsulation Transform:";
var rfc1042 = "RFC1042";
var h802 = "802.1H";
var shortSlotTime = "Short Slot-Time:";
var enableSpace = " Enable";
var disableSpace = " Disable";
var beaconPeriod = "Beacon Period:";
var kuSec = "(20-4000 Kusec)";
var shortValue = "Short";
var longValue = "Long";
var worldMode = "World Mode";
var multiDomain = "Multi-Domain Operation:";
var legacy = " Legacy";
var dot11d = " Dot11d";
var indoor = "Indoor";
var outdoor = "Outdoor";
var countryCode ="Country Code:";
var require = "Require";
var receiveAntenna = "Receive Antenna:";
var diversity = "Diversity";
var left = "Left";
var right = "Right";
var transmitAntenna = "Transmit Antenna:";
var reliableMultiWGB = "Reliable Multicast to WGB:";
var publicSecurePacketForwarding = "Public Secure Packet Forwarding:";
var PSFAlert = "PSPF must be set per VLAN. See VLAN page";
var dataBeaconRate = "Data Beacon Rate (DTIM):";
var oneToHundred = "(1-100)";
var maxDataEntrie = "Max. Data Retries:";
var RTSMaxEntries = "RTS Max. Retries:";
var fragmentationThreshold = "Fragmentation Threshold:";
var rtsThreshold = "RTS Threshold:";
var leastCongestedFrequency = "Least Congested Frequency";

/* atg_sec.shtml */

var securityTitle = "Security";
var localRadiusServer = "Local RADIUS Server";
var serverManager = "Server Manager";
var securitySummary = "Security Summary ";
var serverBasedSecurity = "Server-Based Security";
var serverNameIPAddress = "Server Name/IP Address";
var type = "Type";
var eap = "EAP";
var mac = "MAC";
var accounting = "Accounting";
var admin =  "Admin";
var encryptionSettings = " Encryption Settings";
var encryptionMode = "Encryption Mode ";
var wepValue = "  WEP";
var cipherVal = " Cipher";
var keyRotation = "Key Rotation";
var tkip = " TKIP ";
var wep40Bit = " WEP 40 bit";
var wep128Bit = " WEP 128 bit";
var none = "  None";
var wepMandatory = "WEP-Mandatory";
var wepOptional = "WEP-Optional";
var ssids = " SSIDs";
var ssidBold = " SSID";
var vlanValue = "VLAN";
var openValue = " Open ";
var sharedValue = " Shared";
var networkEAP = " Network EAP";
var encryptionManager = "Encryption Manager";
var managerVal = " Manager";
var radioValue = "Radio";
var bssidGuestModeValue = "BSSID/Guest Mode";
var aesccm = "AES CCMP ";
var guestModeInfrastructure = "Guest Mode/Infrastructure";
var setBeaconMode = "Set Beacon Mode:";
var singleBssid = "Single BSSID";
var setSingleGuestModeSsid = "Set Single Guest Mode SSID: ";
var ssidSettings = "SSID settings ";
var multipleBssid = "Multiple BSSID";
var multipleBssidBeaconSettings = "Multiple BSSID Beacon Settings";
var multipleBssidBeacon = "Multiple BSSID Beacon";
var setSsidAsGuestMode = "Set SSID as Guest Mode";

/* atg_sec_ap-key-security.shtml */
var securityEncManager = "Security: Encryption Manager ";
var encryptionModes = "Encryption Modes ";
var wepEncryption = "WEP Encryption ";
var optional = "Optional";
var mandatory = "Mandatory";
var globalProperties = "Global Properties";
var broadcastKeyRotationInterval = "Broadcast Key Rotation Interval:";
var disableRotation = "Disable Rotation";
var enableRotationWith = "Enable Rotation with ";
var interval = "Interval:";
var tenToTenThouSec = "(10-10000000 sec)";
var wpaGroupUpdateKey = "WPA Group Key Update:";
var enableGroupKey = "Enable Group Key Update On Membership";
var terminationVal = " Termination";
var enableGroupKeyOnCapability = "Enable Group Key Update On Member's Capability Change";
var encryptionkey = "Encryption Keys ";
var transmitkey = "Transmit Key";
var encryptionkeyPass = "Encryption&nbsp;Key (Hexadecimal)";
var encrypKeySize = "Key Size";
var encrypKeyNo1 = "Encryption&nbsp;Key 1:";
var encrypKeyNo2 = "Encryption&nbsp;Key 2:";
var encrypKeyNo3 = "Encryption&nbsp;Key 3:";
var encrypKeyNo4 = "Encryption&nbsp;Key 4:";
var setEncryptionModeAndKeysForVLAN = "Set Encryption Mode and Keys for VLAN: ";
var setEncryptionModeAndKeysForVLANName = "Set Encryption Mode and Keys for VLAN Name: ";

/* atg_sec_ap-client-security.shtml */
var ssidManager = "SSID Manager";
var securityCol = "Security: ";
var ssIDManager = "SSID Manager ";
var ssidProperties = "SSID Properties";
var currentSSIDList = "Current SSID List";
var ssidCol = "SSID: ";
var vlanCol = "VLAN: ";
var newOption = "< NEW >";
var noneOption = "< NONE >";
var defineVlans = "Define VLANs";
var authenticationSetting = "Authentication Settings";
var methodsAccepted = " Methods Accepted:";
var openAuthentication = "Open Authentication: ";
var noAddition = " NO ADDITION";
var withMACAuthentication = "with MAC Authentication";
var withEAP = "with EAP";
var withMacAuthentAndEAP = "with MAC Authentication and EAP";
var withMacAuthentOrEAP = "with MAC Authentication or EAP";
var sharedAuthentication = "Shared Authentication: ";
var networkEAP = "Network EAP:";
var serverPriorites = "Server Priorities:";
var eapAuthenticationServers = "EAP Authentication Servers";
var macAuthenticationServers = "MAC Authentication Servers";
var useDefaults = "Use Defaults";
var defineDefaults = "Define Defaults";
var customize = "Customize";
var priority1 = "Priority 1:";
var priority2 = "Priority 2:";
var priority3 = "Priority 3:";
var authenticatedKeyManagement = "Authenticated Key Management";
var wpaPresharedKey = "WPA Pre-shared Key:";
var ascii = "ASCII";
var hexaDecimal = "Hexadecimal";
var accountingSettings = "Accounting Settings";
var enableAccounting = "Enable Accounting";
var accountingServerPriorities = "Accounting Server Priorities:";
var keyManageMent = "Key Management:";
var keyMgmtNone = "None";
var wpaCol = "WPA: ";
var wpaWithOutCol = "WPA";
var generalSettings = "General Settings";
var associationLimitOptions = "Association Limit (optional):";
var eapClientOption = "EAP Client (optional):";
var userName = "Username:";
var password = "Password:";
var global = "Global ";
var setGuestModeSSID = "Set Guest Mode SSID:";
var SSID2 = "SSID 2";
var SSID3 = "SSID 3";
var SSID4 = "SSID 4";
var SSIDN = "SSID N";
var setInfrastructureID = "Set Infrastructure SSID:";
var forceInfraStructureDevice = "Force Infrastructure Devices to associate only to this SSID";
var warningMsg51 = "Change the 'Station-Role' to 'AccessPoint' for 'MBSSID' configuration";
var warning231 = " is 'Shutdown'.\n'MBSSID' requires this Interface to be enabled to get displayed and function properly.";
var warning232 = "\nDo you want to enable this Interface.";
/* atg_sec_network-security_a.shtml */

var cisco = "Cisco ";
var backupRadiusServer = "Backup RADIUS Server";
var backupRadiusServerCol = "Backup RADIUS Server: ";
var sharedSecret = "Shared Secret:";
var corporateServers = "Corporate Servers";
var currentServerList = "Current Server List";
var RADIUS = "RADIUS";
var TACACS = "TACACS+";
var serverCol = "Server:";
var authenticationPortOptional = "Authentication Port (optional):";
var accountingPortOptional = "Accounting Port (optional):";
var defaultServerProperties = "Default Server Priorities";
var macAuthentication = "MAC Authentication";
var accountVal = "Accounting";
var adminAuthenticationRadius = "Admin Authentication (RADIUS)";
var adminAuthenticationTACACS = "Admin Authentication (TACACS+)";
var serverManagerBold = "SERVER MANAGER";
var globalPropertiesBold = "GLOBAL PROPERTIES";


/* atg_sec_network-security_b.shtml */

var securityMangerGlobalProp = "Security: Server Manager - Global Server Properties";
var accountingUpdateInterval = "Accounting Update Interval (optional):";
var accountingUpdateIntervalRange = "(1-2147483647 min)";
var accountingTACACSServerTimeOut = "TACACS+ Server Timeout (optional):";
var accountingTACACSRange = "(1-1000 sec)";
var accounRadiusServerTimeout = "RADIUS Server Timeout (optional):";
var radiusServerRetransmit = "RADIUS Server Retransmit Retries (optional):";
var deadRadiusList = "Dead RADIUS Server List:";
var enableServerList = "Enable - Server remains on list for: ";
var enableServerListRange = "(1-1440 min)";
var radiusCalledOrCallingFormat = "RADIUS Calling/Called Station ID Format:";
var defaulID1 = "Default (e.g. 0000.4096.3e4a)";
var IETFID = "IETF (e.g. 00-00-40-96-3e-4a)";
var unFormatedID = "Unformatted (e.g. 000040963e4a)";
var radiusWISPrAttributes = "RADIUS WISPr Attributes (optional)";
var ISOCountryCode = " ISO Country Code:";
var twoLetters = "(two letters)";
var E16CountryCode = "E.164 Country Code:";
var e16AreaCode = "E.164 Area Code:";
var threeDigits = "(three digits)";

/* atg_sec_lrs.shtml */
var localRadiusServerValue = " Local RADIUS Server";
var localRadiusTitle = "Security: Local RADIUS Server - Statistics";
var localRadiusServerInformation = "Local RADIUS Server Information";
var networkAccessServerInformation = "Network Access Server Information";
var viewInformationFor = "View Information for:";
var allServers = " ALL Servers ";
var userInformation = "User Information";
var userNameValue = "User Name";
var successess = "Successes ";
var failures = "Failures ";
var blocks = "Blocks ";
var lrsSuccessfulAuthentication = "Successful Authentication";
var unknowUsername = "Unknown Usernames";
var clientBlocks = "Client Blocks";
var invalidPasswordVal = "Invalid Passwords";
var unknowNAS = "Unknown NAS";
var invalidPacketsFromNAS = "Invalid Packets From NAS";
var networkAccessServer = "Network Access Server";
var unknownUsernameValue = "Unknown Username";
var corruptedPackets = "Corrupted Packets";
var unknowRadiusMsgValue = "Unknown RADIUS Messages";
var noUserNameAttribute = "No Username Attribute";
var sharedKeyMismatch = "Shared Key Mismatch";
var missingAuthenticationAttribute = "Missing Authentication Attribute";
var invalidStateAttribute = "Invalid State Attribute ";
var unknownEAPMessage = "Unknown EAP Messages";
var unknownEAPType = "Unknown EAP Type";
var statisticsBold = "STATISTICS";
var generalSetupBold = "GENERAL SETUP";
var eapFastSetupBold = "EAP-FAST SETUP";
var autoProvisionSuccesses = "Auto Provision Successes";
var autoProvisionFailures = "Auto Provision Failures";
var pacRefreshes = "PAC Refreshes";
var invalidPacReceived = "Invalid PAC Received";

/* atg_sec_lrs_b.shtml */
var securityGeneralSetup = "Security: Local RADIUS Server - General Setup";
var networkAccessServers = "Network Access Servers (AAA Clients)";
var currentNetworkAccessServers = "Current Network Access Servers";
var networkAccessServerVal = "Network Access Server: ";
var ipAddressVal = "(IP Address)";
var individualUsers = "Individual Users";
var currentUsers = "Current Users";
var ntHash = "NT Hash";
var confirmPwd = "Confirm Password: ";
var groupName = "Group Name:";
var macAuthenticationOnly = "MAC Authentication Only";
var userGroupsValue = "User Groups";
var currentUsrGroupsValue = "Current User Groups";
var sessionTimeOutOptional = "Session Timeout (optional):";
var sessionTimeoutRange = "(1-4294967295 sec)";
var failedAuthenticationBeforeLockout = "Failed Authentications before Lockout (optional):";
var lockoutOptional = "Lockout (optional):";
var Infinite = "Infinite";
var Interval = "Interval";
var VLANIDOptional = "VLAN ID (optional):";
var SSIDOptionalVal = "SSID (optional):";
var textVal = "Text";
var localRadiusServerAuthenticationSettings = "Local Radius Server Authentication Settings";
var enableAuthenticationProtocols = "Enable Authentication Protocols:";
var eapFast = "EAP FAST";
var leap = "LEAP";

/* atg_sec_lrs_c.shtml */
var securityEAPFASTSetup = "Security: Local RADIUS Server - EAP-FAST Setup";
var pacEncryptionKeys = "PAC Encryption Keys";
var primaryKey = "Primary Key (optional):";
var secondaryKey = "Secondary Key (optional):";
var keyVal = "(32 Hex characters)";
var generateRandom = "Generate Random";
var copyPrimary = "Copy_from_Primary";
var pacContent = "PAC Content";
var authorityInfo = "Authority Info (optional):";
var authorityId = "Authority ID (optional):";
var automaticPacProvisioning = "Automatic PAC Provisioning (optional)";
var currentUserGroups = "Current User Groups";
var pacExpiration = "PAC Expiration:";
var validity = "(2-4095 days)";
var pacGracePeriod = "PAC Grace Period";
var outOfBandPacGeneration = "Out-of-band PAC Generation";
var tftpFileServer = "TFTP File Server:";
var serverNameOrIPAddress = "(server name or IP address)";
var pacFileName = "PAC File Name:";
var pathFileName = "(path/filename)";
var recipientUsername = "Recipient Username:";
var pacEncryptionPassword = "PAC Encryption Password (optional):";
var pacExpiration = "PAC Expiration (optional):";
var pacExpirationValue = "(1-4095 days)";
var generatePac = "Generate_PAC";

/* atg_services.shtml */

var servicesVal = " Services";
var filtersVal = "Filters";
var VlanValue = "VLAN";
var qosValue = "QoS";
var servicesSummary = "Services Summary";

/* atg_services_filters.shtml */

var securityFilterTitle = "Services: Filters - Apply Filters";
var servicesFilter = "Services - Filters";
var applyFiltersBold = "APPLY FILTERS";
var macAddrFiltersBold = "MAC ADDRESS FILTERS";
var ipAddrFilters = "IP FILTERS";
var incomingTitle = "Incoming";
var outgoingTitle = "Outgoing";
var macStr = "MAC";
var etherType = "EtherType";
var IPStr = "IP";

/* atg_services_filters-mac.shtml */

var serviceFilterMAC = "Services: Filters - MAC Address Filters";
var createEditIndex = "Create/Edit Filter Index:";
var filterIndexVal = "Filter Index:";
var addMACAddress = "Add MAC Address:";
var addMaskCol = "Mask:";
var actionCol = "Action:";
var Forward = "Forward";
var Block = "Block";
var HHH = "(HHHH.HHHH.HHHH)";
var defaultActionVal = "Default Action:";
var forwardAll = "Forward All";
var blockAll = "Block All";
var filtersClasses = "Filters Classes:";

/* atg_services_filters-ip.shtml */

var servicesIPFilters = "Services: Filters - IP Filters";
var createEditFilterName = "Create/Edit Filter Name:";
var filterName = "Filter Name:"
var IPAddrValue = "IP Address";
var destAddre = "Destination Address:";
var sourceAddrValue = "Source Address:";
var ipProtocolVal = "IP Protocol";
var ipProtocolValCol = "IP Protocol:";
var tcpPort = "TCP Port:";
var udpPort = "UDP Port:";
var filterClassesValue = "Filters Classes";
var tcpUDPPort = "UDP/TCP Port";

/* atg_services_vlan.shtml */
var serviceVLANTitle = "Services - VLAN";
var servicesVLAN = "Services: VLAN";

/*atg_services_vlan-brg.shtml*/

var serviceVLANBridgingTitle = "Services - VLAN Bridging";
var servicesVLANBridging = "Services: VLAN Bridging";
var globalVLANProperties = "Global VLAN Properties";
var currentNativeVLAN = "Current Native VLAN:";
var assignedVLAN = "Assigned VLANs";
var currVLANList = "Current VLAN List";
var createVLAN = "Create VLAN";
var vlanIDCol = "VLAN ID:";
var bridgeGroupNuVal = "Bridge Group No:";
var nativeVal = "Native";
var vlanValue = "VLAN";
var vlanInformationVal = "VLAN Information";
var viewInformationFor = "View Information for:";
var manageMentVLAN1 = " Management VLAN 1 ";
var VLANStr = " VLAN ";
var enablePublicSecure = "Enable Public Secure Packet Forwarding";
var SSIDSpace = "SSID: ";
var defineSSID = " Define SSID";
var workGroupEthernetClient = "Workgroup Bridge Ethernet Client VLAN";

/* atg_services_vlan-rte.shtml */

var serviceVLAnRouting = "Services - VLAN Routing";
var serviceVLANTitle = "Services: VLAN Routing";

/* atg_network-map.shtml */

var networkMap = "Network Map";
var networkMapTable = "Network Map Table";
var macAddress = "MAC Address";
var ipAddressWithoutCol = "IP Address";
var deviceName = "Device";
var deviceNameVal = "Name";
var softwareVersion = "Software Version";
var closeWindow = "Close Window";
var copyRight = "Copyright (c) 2002-2007 by Cisco Systems, Inc.";
var apply = "Apply";
var cancel = "Cancel";
var refresh = "Refresh";

/* def_broadcast-ssid.shtml */
var broadCastSSIDMsg = "If an SSID is not specified, a device sends a broadcast message in search of an access point to associate with. This setting will allow devices without a specified SSID to associate with this access point.";
var broadCastSSIDVal = "Broadcast SSID Definition";

/* def_eap-security.shtml */
var eapSecurityMsg = "In future, do not show security definitions when settings are selected.";
var eapOptionVal = "EAP Option";
var eapMessage1 = "Extensible Authentication Protocols (EAP) permits wireless access to users authenticated against a database through the services of an authentication server then encrypts the authenticated and authorized traffic. Use this setting for LEAP, PEAP, EAP-TLS, EAP-TTLS, EAP-GTC, EAP-SIM, and other 802.1x/EAP based protocols.";
var eapMessage2 = "This setting uses mandatory encryption WEP, open authentication + EAP, network EAP authentication, no key management, RADIUS server authentication port 1645."
var eapSecurityDef = "EAP Security Definition";

/* def_ip-address.shtml */
var ipAddrDefVal = "IP Address Definition";
var ipAddressDetails = "An IP address identifies a location to which IP datagrams can be sent.";

/* def_ip-netmask.shtml */
var subnetMaskDefVal = "IP Subnet Mask Definition";
var subetMaskDefValDetails = "An IP Subnet Mask identifies the bits that denote the network number in an IP address.";

/* def_no-security.shtml */
var noSecurityOption = "No Security Option";
var securityWithOutKey = "This setting uses no encryption key, no key management and open authentication.";
var securityWithOutManage = "This setting uses no key management and open authentication.";
var noSecurityDef = "No Security Definition";

/* def_wep-security.shtml */
var staticWEPKeyOption = "Static WEP Key Option";
var wepKeyEncryption = "This setting uses mandatory WEP encryption, no key management and open authentication.";
var wepSecuDefinition = "WEP Security Definition";

/* def_wpa-security.shtml */
var wpaOption = "WPA Option";
var wpaOptionVal = "Wi-Fi Protected Access (WPA) permits wireless access to users authenticated against a database through the services of an authentication server, then encrypts their authenticated and authorized IP traffic with stronger algorithms than those used in WEP. Make sure clients are WPA certified before selecting this option.";
var wpaOptionVal2 = " This setting uses encryption ciphers tkip, open authentication + EAP, network EAP authentication, key management WPA mandatory, and RADIUS server authentication port 1645.";
var wpaTitle = "WPA Security Definition";

/* warning messages */

/* atg_network-map.shtml */
var warning1 = "WARNING:\nIt can take up to 30 seconds to fully discover the network.\nClick on 'Refresh' to update the map.\n\nThe Network Map increases the system load and can be disabled when not in use to decrease the system load.";

/* atg_assoc_adv.shtml */
var warning2 = "ERROR:\n\"";
var warning3 = "\" is an invalid input. It must be a positive number."; 
var warning4 = "ERROR:\n'Default Timeout' must be between 1 and 100000.";
var warning5 = "ERROR:\n'Max Timeout' must be between 1 and 100000.";
var warning6 = "ERROR:\n'Maximum Timeout' cannot be specified without also specifying 'Default Timeout'.";
var warning7 = "ERROR:\n'Default Timeout' cannot exceed 'Maximum Timeout'.";

/* atg_express-security-brg.shtml */
var encryptionWarning = "ERROR:\nEncryption settings on the current SSIDs are incompatible with this setting.\nAll current SSIDs must be deleted to use this setting.";
var vlanWarning = "ERROR:\nVLAN settings on the current SSIDs are incompatible with this setting.\nAll current SSIDs must be deleted to change this setting.";
var vlanWarning1 = "ERROR:\nVLANs are enabled. All current VLANs must be deleted to change this setting\n(See Services > VLAN.)";
var warningMsg1 = "ERROR:\nSelect 'Enable VLAN' to edit this field.";
var warningMsg2 = "ERROR:\nSelect 'Static WEP Key' to edit this field.";
var warningMsg3 = "ERROR:\nSelect 'EAP Authentication' to edit this field.";
var warningMsg4 = "ERROR:\nSelect 'WPA' to edit this field.";
var warningMsg5 = "ERROR:\nEncryption setting has been modified from the 'Encryption Manager' or from the CLI.\n It needs to set back to the default value 'None' to use this 'Express Security Setup'\n(See Security > Encryption Manager.)";
var warningMsg6 = "ERROR:\n Only one Vlan can be configured for static wep keys";
var warningVlan1SetToNative = "WARNING:\nVLAN 1 will now be the native VLAN.";
var pegasusWarning = "ERROR:\nThe current SSID must be deleted before adding the new one.";
var warning9 = "ERROR:\nEnter a valid 'SSID'. Characters + ] / \" TAB and trailing space are invalid.";
var warning10 = "ERROR:\nThis 'SSID' is already in use. Choose an unique SSID.";
var warning11 = "WARNING:\nSSID ";
var warning12 = " replaces SSID ";
var warning13 = " as the Broadcast SSID.";
var warning14 = "ERROR:\n Please enter a bridge group number between 1 and 255.";
var warning15 = "ERROR:\nbridge group number must be between 1 and 255.";
var warning16 = "' is an invalid input.\nVLAN ID must be between 1 and 4094.";
var warning17 = "ERROR:\nVLAN ID must be between 1 and 4094.";
var warning18 = "ERROR:\nThis 'VLAN ID' is already in use. Choose an unique VLAN ID.";
var warning19 = "ERROR:\nA maximum of 16 SSIDs are permitted." ;
var warning20 = "WARNING:\nThis vlan 1 will be used as the native VLAN.";
var warning21 = "WARNING:\nVLAN ";
var warning22 = " replaces VLAN ";
var warning23 = " as the native VLAN.";
var warning24 = "ERROR:\nEnter a hexadecimal number for Encryption Key";
var warning25 = "ERROR:\nEncryption Key must be 26 hexadecimal characters.";
var warning26 = "ERROR:\nEncryption Key must be 10 hexadecimal characters.";
var warning27 = "ERROR:\nEnter a valid Eap Server.";
var warning28 = "ERROR:\nEnter a valid Shared Secret for Eap Server.";
var warning29 = "WARNING:\nDNS server is not defined. Device may not recognize the Server until the DNS server is defined.\n(Configure through SDM)";
var warning30 = "ERROR:\nEnter a valid Eap Server for WPA.";
var warning31 = "ERROR:\nEnter a valid Server Shared Secret for WPA.";
var warning32 = "WARNING:\nDNS server is not defined. Device may not recognize the Server until the DNS server is defined.\n(Configure through SDM)";
var checkRadiusServer = "ERROR:\nThe RADIUS server {0} is configured for other authentication purposes.\nPlease enter a different RADIUS server."
var warning212 = "ERROR:\nA maximum of 10 SSIDs are permitted." ;


/* atg_express-security-rte.shtml */
var StaticWarn = "ERROR:\nSelect 'Static IP' to modify this field."; 

var warning33 = "ERROR:\nPlease enter a valid ip address and netmask for interface ";  
var warning34 = " or uncheck it"; 
var warning35 = "ERROR:\nPlease enter a valid ip address for interface "; 
var warning36 = "ERROR:\nPlease enter a valid netmask for interface "; 
var warning37 = "ERROR:\nPlease enter a different ip address and netmask for interface " ;
var warning38 = " or its subinterface" ;
var warning39 = "ERROR:\nThe number of netmask bits is less or equal to IP address network address. \n Please enter a different ip address and netmask for interface " ;
var warning40 = "ERROR:\nPlease enter a different ip address and netmask for interface "; 
var warning41 = "Please select at least one Radio interface" ;

/* atg_express-setup.shtml */
var warnAirlink = "ERROR:\nRepeater Non Root cannot be selected for Airlink";
var warning42 = 'inside if';
var warning43 = "error";
var warning228 = "ERROR:\n MBSSID is Enabled.\n Disable it to change the mode";
var warning229 = "WARNING:\nThe Interface ";
var warning230 = " is shutdown.\n'Station Role' and 'MBSSID' requires this interface to be 'Enabled' to function properly.";
var warning233 = "\nClick 'OK' to enable this interface or Click 'CANCEL' to change the 'Role in Radio Network' without enabling this Interface.";
/* atg_network-if_802-11_c.shtml */

var warning44 = "Warning:\n'Aironet Extensions' should be enabled in bridge role." ;
var warning45 = "WARNING:\nCan not find Country code of World Mode.";
var warning46 = "ERROR:\nAt least one 'Data Rate' must be enabled.";
var warning47 = "ERROR:\n'Fragmentation Threshold' must be between 256 and ";
var warning48 = "ERROR:\n'RTS Threshold' must be between 0 and ";
var warning49 = "ERROR:\n'Max. Data Retries' must be between 1 and 128.";
var warning50 = "ERROR:\n'RTS Max. Retries' must be between 1 and 128.";
var warning51 = "ERROR:\n'Beacon Period' must be between 20 and 4000.";
var warning52 = "ERROR:\n'Data Beacon Rate' must be between 1 and 100.";
var warning53 = "ERROR:\n'Country Code' must be set.";
var warning54 = "ERROR:\nEnable 'Aironet Extensions' to set Non-standard Encapsulation.";
var warning55 = 'ERROR:\n"Indoor" or "Outdoor" or both should be checked.';
var warning56 = "ERROR:\n'Antenna Gain' must be between -128 and 128.";

var LockOutMsg =  "WARNING:\nTurning off the Radio Interface will terminate the connection to web management, if it is being viewed through that Radio Interface.";
var warningMsg7=  "ERROR:\nSet 'Role in Radio Network' to 'Repeater Non-Root' to modify this field";
var warningMsg8 = "ERROR:\nEnable 'Concatenation' to modify this field.";
var warnrepeater= "WARNING:\nSelecting 'Repeater Non-Root' will disable the Ethernet Interface. The connection to web management will be terminated, if it is being viewed through that Ethernet Interface.";
var warningProxy = "ERROR:\n'Proxy Mobile IP' must be disabled in order to set the 'Role in Radio Network' \nto 'Repeater Non-Root' or 'Access Point Root (Fallback to Repeater)' or 'Workgroup Bridge'.\n(See Services > Proxy Mobile IP > General Setup.)";
var warningProxy2 = "ERROR:\n'Proxy Mobile IP' must be disabled in order to set the 'Role in Radio Network' \nto 'Non-Root' or 'Workgroup Bridge' or 'Root AP (Fallback to Repeater)'.\n(See Services > Proxy Mobile IP > General Setup.)";
var warningSSID = "ERROR:\n'Set Infrastructure SSID' must be configured in order to set the 'Role in Radio Network' \nto 'Repeater Non-Root' or 'Access Point Root (Fallback to Repeater)' or 'Workgroup Bridge'.\n(See Security > SSID Manager page).";
var warningSSID2 = "ERROR:\n'Set Infrastructure SSID' must be configured in order to set the 'Role in Radio Network' \nto 'Non-Root' or 'Workgroup Bridge'.\n(See Security > SSID Manager page).";
var warningRestrict = "ERROR:\n'Default Radio Channel' must be set to 'Least Congested Frequency' to modify this field.";
var warningRepeater = "ERROR:\nCannot set the 'Role in Radio Network' to 'Repeater Non-Root' or\n'Access Point Root (Fallback to Repeater)' or 'Workgroup Bridge' when another radio is set to\n'Repeater Non-Root' or 'Access Point Root (Fallback to Repeater)' or 'Workgroup Bridge'.";
var warningAironet = "ERROR:\n'Aironet Extension' should be enabled, if the Role in Radio Network is bridge.";
var warningMsgGain  = "ERROR:\nSet 'External Antenna Configuration' to 'Enable' to modify this field.";
var warningWorldMode = "ERROR:\n'World Mode' should be 'Dot11d' to modify this field.";
var warningCh14 = "ERROR:\n'Default Rates' must be changed from Channel 14 in order to allow OFDM frequencies.";


/* atg_sec_ap-client-security.shtml */

var warning57 = "ERROR:\nOn VLAN " ;
var warning58 = "ERROR:\nOn Radio" ;
var warning59 = "WARNING:\nNetwork EAP requires encryption to be set on VLAN " ;
var warning60 = " to function properly (See Security > Encryption Manager)." ;
var warning61 = "WARNING:\nNetwork EAP requires encryption to be set on Radio " ;
var warning62 = " to function properly (See Security > Encryption Manager)." ;
var warning63 = "WARNING:\nAuthentication on at least one SSID was configured with the CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface." ;
var warning64 = "ERROR:\nOnly an SSID mapped to the native VLAN may be the Infrastructure SSID." ;
var warning65 = "ERROR:\nInfrastructure SSID must be set while the device is in Repeater role (See Radio Express Setup)." ;
var warning66 = "ERROR:\nNo Accounting Servers are selected." ;
var warning67 = "ERROR:\nNo EAP Servers are selected." ;
var warning68 = "ERROR:\nNo MAC Servers are selected." ;
var warning69 = "ERROR:\nKey management is turned on but no scheme is selected." ;
var warning70 = "ERROR:\n'WPA Pre-shared Key' must contain characters with ASCII code ranging from 32 to 126.\nDouble quote is not a valid character." ;
var warning71 = "ERROR:\n'WPA Pre-shared Key' in 'ASCII' must be 8-63 characters long." ;
var warning72 = "ERROR:\n'WPA Pre-shared Key' in 'Hexadecimal' must be 64 characters long." ;
var warning73 = "ERROR:\n'WPA Pre-shared Key' in 'Hexadecimal' only accept hexadecimal character" ;
var warning74 = "ERROR:\nEnter a valid 'EAP Client Username'." ;
var warning75 = "ERROR:\nEnter a valid 'EAP Client Password'." ;
var warning76 = "ERROR:\n'Association Limit' must be between 1 and 25." ;
var warning77 = "ERROR:\n'Association Limit' must be between 1 and 25." ;
var warning78 = "ERROR:\n'SSID' is already defined." ;
var warning79 = "ERROR:\nA maximum of 16 SSIDs are allowed." ;
var warning80 = "ERROR:\nEach SSID must be mapped to a unique VLAN." ;
var warning81 = "ERROR:\nEach SSID must be mapped to a unique VLAN." ;
var warning82 = "ERROR:\n'Shared Authentication' is not allowed on multiple SSIDs." ;
var warning83 = "ERROR:\n'Infrastructure SSID' cannot be changed when the device is in Repeater role (See Radio Express Setup." ;
var warning84 = "ERROR:\nWPA requires 'Network EAP' or 'Open Authentication' with EAP or 'Open Authentication' with 'WPA Pre-shared Key'." ;
var warning85 = "ERROR:\nWPA is incompatible with 'Shared Authentication'." ;
var warning86 = "ERROR:\nWPA requires 'Network EAP' or 'Open Authentication' with EAP or 'Open Authentication' with 'WPA Pre-shared Key'." ;
var warning87 = "ERROR:\n'Open Authentication' with EAP and 'WPA Pre-shared Key' cannot be set simultaneously with WPA." ;
var warning88 = "ERROR:\n'Network EAP' and 'WPA Pre-shared Key' cannot be set simultaneously with WPA." ;
var warning89 = "'Encryption Key 1' must be removed before setting WPA . (See Security > Encryption Manager)" ;
var warning90 = "ERROR:\nCannot delete 'Infrastructure SSID' while device is in Repeater role (See Radio Express Setup)." ;
var warning91 = "ERROR:\nInfrastructure SSID cannot be deleted while AP is in Repeater role (See Radio Express Setup)" ;
var warning92 = "WARNING:\nThis SSID is present on other radio interfaces.\nThis action will delete them." ;
var warning93 = "WARNING:\nAuthentication on at least one SSID was configured with the CLI.\nExecuting this action will overwrite those settings." ;
var warning94 = "ERROR:\nVLAN " ;
var warning95 = " does not include interface " ;
var warning96 = " (see Services > VLAN)." ;
var warning97 = "ERROR:\n'Apply-All' cannot be used because the VLAN does not have the same SSID name for each radio interface.\nModification to the SSIDs of this VLAN need to be done per radio interface, using the 'Apply-Radio' button." ;
var warning98 = "WARNING:\nAuthentication on at least one SSID was configured with the CLI.\nExecuting this action will overwrite those settings." ;
var warning99 = "WARNING:\nThis SSID is present on other radio interfaces.\nThis action will overwrite them." ;
var warning99a = "WARNING:\nThis SSID is already present on other radio interfaces.";
var warning100 = " not found! " ;
var warnNetworkEAP = "WARNING:\nNetwork EAP requires encryption to be set to function properly (See Security > Encryption Manager).";
var errorWithSpace = "ERROR: ";
var warningMsg9 = " 'encryption mode ciphers tkip' must be configured before setting WPA SSID. (See Wireless Security > Encryption Manager)"; 
var warningMsg10 = "ERROR:\nSelect 'Open Authentication' to modify this field.";
var warningMsg11 = "ERROR:\nSelect 'Shared Authentication' to modify this field.";
var warningMsg12 = "ERROR:\nSelect 'Network EAP' to modify this field.";
var warningMsg13 = "ERROR:\nEnable Proxy Mobile IP to modify this field.\n(See Services > Proxy Mobile IP General > General Setup)";
var warningMsg14 = "ERROR:\nChoose an 'Infrastructure SSID' to modify this field.";
var warningMsg15 = "ERROR:\nSelect 'CCKM' to modify this field.";
var warningMsg16 = "ERROR:\nSelect 'WPA' to modify this field.";
var warningMsg17 = "ERROR:\nSelect 'Customize' to modify this field.";
var warningMsg18 = "ERROR:\nSelect 'Enable Accounting' to modify this field.";
var warningMsg19 = "ERROR:\nSelect an EAP authentication method to modify this field.";
var warningMsg20 = "ERROR:\nSelect a MAC authentication method to modify this field.";
var warningMsg21 = "ERROR:\nSet 'Key Management' Optional or Mandatory to modify this field.";
var warningMsg22 = " cannot support CCKM.\nSet 'Encryption Mode' to 'Cipher' on all radio interfaces before selecting CCKM (See Security > Encryption Manager).";
var warningMsg23 = "ERROR:\nCCKM is supported only when 'Cipher' is ON.\nSet 'Encryption Mode' to 'Cipher' before selecting CCKM.\n(See Security > Encryption Manager)";
var warningMsg24 = " cannot support WPA optional.\nSet 'Encryption Mode' to 'Cipher', 'TKIP + WEP 40 bit' or 'TKIP + WEP 128 bit' on all radio interfaces before before selecting WPA (See Security > Encryption Manager)";
var warningMsg25 = "ERROR:\nWPA optional is supported only with 'Cipher', 'TKIP + WEP 40 bit' or 'TKIP + WEP 128 bit'.\n(See Security > Encryption Manager page)";
var warningMsg26 = " cannot support WPA mandatory.\nSet 'Encryption Mode' to 'Cipher', 'TKIP' on all radio interfaces before selecting WPA (See Security > Encryption Manager)";
var warningMsg27 = "ERROR:\nWPA mandatory is supported only with 'Cipher' 'TKIP'.\n(See Security > Encryption Manager page)";
var warningMsg28 = " cannot support CCKM.\nOnly one cipher may be configured when using CCKM.\n(See Security > Encryption Manager)";
var warningMsg29 = "ERROR:\nOnly one cipher may be configured when using CCKM.\n(See Security > Encryption Manager)";
var warningMsg30 = "ERROR:\n VLAN Should not be associated with a SSID to configure this setting";
var warningMsg47 = " 'Encryption Key 4' must be removed before setting Network EAP or EAP. (See Security > Encryption Manager)";
var warningStep1="\n\nTo set the correct 'Key Management', follow the steps below:\nSTEP 1:Set the 'Key Management' to 'None'.";
var warningStep2m="\nSTEP 2:Set the 'Cipher' to 'TKIP'.(see Security > Encryption Manager)";
var warningStep2o="\nSTEP 2:Set the 'Cipher' to 'TKIP + WEP40 bit' or 'TKIP + WEP128 bit'.(see Security > Encryption Manager)";
var warningStep3m="\nSTEP 3:Set the 'Authenticated Key Management' to 'WPA' and 'Mandatory'.";
var warningStep3o="\nSTEP 3:Set the 'Authenticated Key Management' to 'WPA' and 'Optional'.";
var warning234 = "\nClick 'OK' to enable this interface or Click 'CANCEL' to change the 'MBSSID' settings without enabling this Interface.";

/* atg_sec_ap-key-security.shtml */
var warning101 = "WARNING:\nAt least one encryption setting was improperly configured with the CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface." ;
var warning102 = "ERROR:\n'Authenticated Key Management' is set to WPA optional. Cipher may only be set to 'TKIP + WEP 40 bit' or 'TKIP + WEP 128 bit'.\nSet the 'Authenticated Key Management' to 'None' before changing Cipher options.\n(See Security > SSID Manager.)" ;
var warning103 = "ERROR:\n'Authenticated Key Management' is set to WPA mandatory. Cipher may only be set to 'TKIP'.\nSet the 'Authenticated Key Management' to 'None' before changing Cipher options.\n(See Security > SSID Manager.)" ;
var warning104 = "ERROR:\n'Broadcast Key Rotation Inverval' must be between 10 and 10000000." ;
var warning105 = "ERROR:\n'Broadcast Key Rotation Interval' must be between 10 and 10000000." ;
var warning106 = "WARNING:\nAt least one encryption setting was configured with the CLI.\nExecuting this action will overwrite these settings." ;
var warning107 = "WARNING:\nEncryption is configured on other radio interfaces.\nThis action will overwrite the settings on all the radio interfaces." ;
var warning108 = "WARNING:\nAt least one encryption setting was improperly configured with the CLI.\nExecuting this action without first clearing the settings via CLI may\nproduce inconsistent behavior." ;
var warning109 = "WARNING:\nAt least one encryption setting was improperly configured with the CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface." ;
var warningMsg31 = "ERROR:\nSelect 'WEP Encryption' to modify this field.";
var warningMsg32 = "ERROR:\nSet 'WEP Encryption' to 'Mandatory' to enable MIC.";
var warningMsg33 = "ERROR:\nSelect 'Enable Rotation' to modify this field.";
var warningMsg34 = "ERROR:\nSelect 'Cipher' to modify this field.";
var warningMsg35 = "ERROR:\nSet the 'Authenticated Key Management' to 'None' before changing Cipher.\n(See Security > SSID Manager.)";
var warningMsg36 = "ERROR:\nSet the 'Authenticated Key Management' to 'None' for all the interfaces before changing Cipher.\n(See Security > SSID Manager.)";
var warningMsg37 = "ERROR:\nSet the 'Authenticated Key Management' to 'None' before setting Key1 or Key4 as a Transmit Key.\n(See Security > SSID Manager.)";
var warningMsg38 = "ERROR:\nEAP is configured, Key4 is not allowed to be configured as a Transmit Key.\n(See Security > SSID Manager.)";
var warningMsg39 = "ERROR:\nEAP is configured. Key4 is not allowed to be configured as a Transmit Key.\n(See Security > SSID Manager.)";
var warningMsg40 = "ERROR:\nCipher is configured as a 40 bit WEP key. Transmit key must match Cipher key size.";
var warningMsg41 = "ERROR:\nCipher is configured as a 128 bit WEP key. Transmit key must match Cipher key size.";
var warning210 = "ERROR:\n'Authenticated Key Management' is set to WPA optional. Cipher may only be set to 'TKIP + WEP 40 bit', 'TKIP + WEP 128 bit', 'AES CCMP + TKIP + WEP 40 bit', or 'AES CCMP + TKIP + WEP 128 bit'.\nSet the 'Authenticated Key Management' to 'None' before changing Cipher options.\n(See Security > SSID Manager.)" ;
var warning211 = "ERROR:\n'Authenticated Key Management' is set to WPA mandatory. Cipher may only be set to 'TKIP', 'AES CCMP', or 'AES CCMP + TKIP'.\nSet the 'Authenticated Key Management' to 'None' before changing Cipher options.\n(See Security > SSID Manager.)" ;
var warning223 = "Maximum number of 4 VLANs were configured for encryption";
var warning224 = "Maximum number of 8 VLANs were configured for encryption";
var warning225 = "Maximum number of 16 VLANs were configured for encryption";
var warning226 = "Encryption on ";
var warning227 = "can be changed.\n Disable encryption on any of these VLANs to configure on another VLAN.";

/* atg_sec_lrs_b.shtml */
var warning110 = "ERROR\nEnter a valid IP Address for the Server." ;
var warning111 = "ERROR\nEnter a valid 'Shared Secret'." ;
var warning112 = "ERROR:\nEnter a valid 'Group Name'. Spaces are not permitted." ;
var warning113 = "ERROR:\n'Session Timeout' must be between 1 and 4294967295." ;
var warning114 = "ERROR:\nNumber of 'Failed Authentications' must be between 1 and 4294967295." ;
var warning115 = "ERROR:\nLockout 'Interval' must be between 1 and 4294967295." ;
var warning116 = "ERROR:\n'VLAN ID' must be between 1 and 4094." ;
var warning117 = "ERROR:\n'VLAN ID' must be between 1 and 4094." ;
var warning118 = "ERROR:\nEnter a valid 'SSID'." ;
var warning119 = "ERROR:\nNo more than 20 SSIDs may be configured in a group." ;
var warning120 = "Select an SSID to delete" ;
var warning121 = "ERROR\nEnter a valid 'Username'. Spaces are not permitted." ;
var warning122 = "ERROR\nEnter a valid 'Password'." ;
var warning123 = "ERROR\nValues for 'Password' do not match." ;
var warning124 = "ERROR\nNT Hashed 'Password' must be 32 characters long." ;
var warning125 = "ERROR\n'Password' can be at most 30 characters long." ;
var warningMsg42 = "ERROR:\nSelect Lockout with 'Interval' to modify this field.";

/* atg_sec_lrs_c.shtml */
var warningMsg48 = "ERROR:\nUnselect 'Generate Random' to modify this field.";
var warningMsg49 = "ERROR:\nNo 'User Groups' are defined (see Local RADIUS Server > General Setup).";
var warningMsg50 = "ERROR:\nNo 'Users' are defined (see Local RADIUS Server > General Setup).";
var warning201 = "ERROR:\nEnter 32 hexadecimal characters for Primary Key.";
var warning202 = "ERROR:\nEnter 32 hexadecimal characters for Secondary Key.";
var warning203 = "ERROR:\nEnter 32 hexadecimal characters for ID.";
var warning204 = "ERROR:\nExpiration must be a number between 2 and 4095.";
var warning205 = "ERROR:\nGrace Period must be a number between 2 and 4095.";
var warning206 = "ERROR:\nEnter a valid IP address for TFTP Server.";
var warning207 = "ERROR:\nEnter a valid PAC Filename.  White space is not permitted.";
var warning208 = "ERROR:\nEnter a valid password.  White space is not permitted.";
var warning209 = "ERROR:\nValidity Period must be a number between 1 and 4095.";

/* atg_sec_network-security_a.shtml */
var warning126 = "ERROR:\nEnter a valid Server." ;
var warning127 = "ERROR:\nServer is already defined." ;
var warning128 = "ERROR:\n'Authentication Port' must be between 1 and 65535." ;
var warning129 = "ERROR:\n'Accounting Port' must be between 1 and 65535." ;
var warning130 = "ERROR:\nEnter a valid 'Shared Secret'." ;
var warning131 = "WARNING:\nServer is currently designated for use in some remote authentication capacity.\nDeleting it will remove it from these uses." ;
var warning132 = "WARNING:\nDNS server is not defined. Device may not recognize the Server until the DNS server is defined.\n(Configure through SDM)" ;
var warning133 = "WARNING:\nMultiple RADIUS Servers are enabled. To prevent an unresponsive (dead) server from delaying the \nauthentication process, enabling the 'Dead RADIUS Server List' (See Security > Global Server Properties.)" ;
var warning134 = "WARNING:\nServer is currently designated for use in some remote authentication capacity.\nChanging it will remove it from these uses." ;
var warning135 = "ERROR:\nEnter a valid 'Server'." ;
var warning136 = "ERROR:\nEnter a valid 'Shared Secret'." ;
var warning137 = "WARNING:\nDNS server is not defined. Device may not recognize the Server until the DNS server is defined.\n(Configure through SDM)" ;
var warning138 = "WARNING:\nMultiple RADIUS Servers are enabled. To prevent an unresponsive (dead) server from delaying the \nauthentication process, enabling the 'Dead RADIUS Server List' (See Security > Global Server Properties.)" ;
var warningMsg43 = "ERROR:\nField is not applicable to TACACS+ servers.";

/* atg_sec_network-security_b.shtml */
var warning139 = "ERROR:\n'Accounting Update Interval' must be between 1 and 2147483647." ;
var warning140 = "ERROR:\n'TACACS+ Server Timeout' must be between 1 and 1000." ;
var warning141 = "ERROR:\n'RADIUS Server Timeout' must be between 1 and 1000." ;
var warning142 = "ERROR:\n'RADIUS Server Retransmit Retries' must be between 0 and 100." ;
var warning143 = "ERROR:\n'RADIUS Server Deadtime' must be between 1 and 1440." ;
var warning144 = "ERROR:\nEnter a valid ISO Country Code." ;
var warning145 = "ERROR:\nEnter a positive integer number for E.164 Country Code." ;
var warning146 = "ERROR:\nEnter a three-digit integer number, not starting with 0, for E.164 Area Code." ;
var warningMsg44 = "ERROR:\nDefine at least one TACACS+ Server to modify this field.\n(See Server Manager > General Setup.)";
var warningMsg45 = "ERROR:\nDefine at least one RADIUS Server to modify this field.\n(See Server Manager > General Setup.)";
var warningMsg46 = "ERROR:\nEnable 'Dead RADIUS Server List' to modify this field.";

/* atg_services_filters.shtml */
var unknownElementAlertMsg = "WARNING:\nAt least one filter was applied using the CLI interface.\nThis will overwrite the previous setting.";
var warning147 = "ERROR:\There are too many changes to send the request in a single submission.\nApply changes incrementally through the GUI." ;
var warning148 = "WARING:\nFilter " ;
var warning149 = " was configured on interface " ;
var warning150 = " using CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface." ;

/* atg_services_filters-ip.shtml */
var warning151 = " is an invalid entry.\nEntry must be between 0 and " ;
var warning152 = "ERROR:\n" ;
var warning153 = " is an invalid IP address." ; 
var warning154 = " is an invalid mask." ;
var warning155 = "ERROR:\nFilter name must start with a letter." ;
var warning156 = "ERROR:\nFilter name can only use alphanumeric characters." ;
var warning157 = "ERROR:\nFilter name cannot start with a number." ;
var warning158 = "ERROR:\nMask 255.255.255.255 is an invalid Mask when used for both Destination and Source Addresses.\ To apply this action to all packets, use the 'Default Action' field." ;
var warning159 = "ERROR:\nFilter name is required." ;
var warning160 = "ERROR:\nAt least one filter is required." ;
var warning161 = "ERROR:\nA filter with this name already exists." ;
var warning162 = "ERROR:\nFilter " ;
var warning163 = "  cannot be renamed while it is applied to an interface. (See Service > Filters > Apply Filters)." ;
var warning164 = "ERROR:\nSelect a filter to delete." ;
var warning165 = "  cannot be deleted while it is applied to an interface. (See Service > Filters > Apply Filters)." ;
var fieldNotSelectedwarning = "ERROR:\nThis field cannot be changed until the corresponding radio button is selected.";

/* atg_services_filters-mac.shtml */
var warning166 = " is an invalid mask.\nAction cannot be applied to all MAC addresses.\nTo apply action to all packets, use Default Action field." ;
var warning167 = " is an invalid mask. Enter a valid mask." ;
var warning168 = " is an invalid MAC address. Enter a valid MAC address." ;
var infoMACFilter = "This is the wild-card mask which will be used to filter MAC addresses.\nUse the default value 0000.0000.0000 for an exact match with the MAC address."

/* atg_services_vlan-brg.shtml */
var warning169 = "WARNING:\nVLAN " ;
var warning170 = "could be invalid.\nCheck encapsulation and/or bridge-group under each subinterface." ;
var warning171 = "ERROR:\nVLAN 1 must be the native VLAN." ;
var warning172 = "ERROR:\nPlease select a Dot11Radio interface." ;
var warning173 = "ERROR:\n'" ;
var warning174 = "' is an invalid input.\nBridge Group Number must be between 1 and 255." ;
var warning175 = "ERROR:\nFor " ;
var warning176 = ", SSID is an infrastructure-SSID and must be configured as the native VLAN." ;
var warning177 = "ERROR:\nEach VLAN must be mapped to a unique SSID." ;
var warning178 = "ERROR:\nAt least one radio interface must be selected." ;
var warning179 = "' is an invalid input.\n Bridge Group Number must be between 1 and 255." ;
var warning180 = "ERROR:\nA VLAN cannot be created when no radio is installed." ;
var warning181 = "ERROR:\n'VLAN ID' is required to set the 'Public Secure Packet Forwarding'." ;
var warning182 = "ERROR:\n'VLAN ID' is required to be set to the native VLAN." ;
var warning183 = "ERROR:\n'Public Secure Packet Forwarding' was modified on the VLAN sub-interface using CLI.\nIt must be fixed via CLI to ensure proper operation of the web interface." ;
var warningQoS = "WARNING:\nA Policy has been incorrectly configured using CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface.";
var warningFilter = "ERROR:\nA filter has been configured using CLI interface.\nIt must be cleared via CLI to ensure proper operation of the web interface.";
var warningRemoveQoS = "WARNING:\nService policies configured in the main interfaces will be removed.";
var warningRemoveFilter = "WARNING:\nAll existing filters will be removed.";
var warningVlan1SetToNative = "WARNING:\nVLAN 1 will now be the native VLAN.";
var warning = "ERROR:\nThis Field cannot be changed until the corresponding radio button is selected.";

/* filter.js */
var warning184 = "ERROR:\nSelect a " ;
var warning185 = " to delete." ;
var warning186 = "ERROR:\nThe default behavior cannot be changed." ; 
var warning187 = "ERROR:\nRenaming this Filter created too many changes to send the request as a single submission.\nIt may be deleted and recreated under a new name" ;
var warning188 = "ERROR:\nThe 'Filter Classes' has too many elements to be send the request as a single submission.\nUse the CLI to create this Filter." ;

/* filter_mac_ether.js */
var warning189 = "ERROR:\n'Filter Index' must be a number." ;
var warning190 = "ERROR:\n'Filter Index' must be between " ;
var warning191 = " and "  ;
var warning192 = "ERROR:\n'Filter Index' is required." ;
var warning193 = "ERROR:\nAt least one filter is required." ;
var warning194 = " already exists." ;
var warning195 = "cannot be renamed while it is applied to an interface (See Service > Filters > Apply Filters)." ;
var warning196 = "ERROR:\nFilter cannot be deleted while it is applied to an interface (See Service > Filters > Apply Filters)." ;

/* forms.js */
var warning197 = "def() does not know object type\n" ;
var warning198 = "modified() does not know object type=" ;
var warning199 = "ERROR:\n'Transmit Key' must have an Encryption Key value."; 
var warning200 = "ERROR:\nBecause 'Cipher' is set to TKIP or AES-CCMP or AES-CCMP+TKIP, none of the Encryption Key may be configured."; 

var ConfigMsg = "WARNING:\nThe settings shown on this page will be updated.\nClick 'OK' to continue.";
var ConfigAAAMsg = "WARNING:\nThe 'aaa new-model' command is disabled. Do you want it to be enabled.\nClick 'OK' to continue.";
var ConfigIpDelMsg = "WARNING:\nThe SSID and IP address configured for this interface will be removed.\nClick 'OK' to continue.";
var ClearLogMsg = "WARNING:\nThe Event Log will be cleared.\nClick 'OK' to continue.";
var RestoreMsg = "WARNING:\nYou have requested that ALL settings on this page be reverted to their Factory Defaults!\nClick 'OK' to continue.";
var TextDisableMsg = "DISABLED";
var help = "Help";
var closeVal = "Close";
var okVal = "OK";
var deleteBtn = "Delete";
var deleteClass = "Delete Class";
var clearVal = "Clear";
var closeWnd = "Close Window";
var printThisPage = "Print this page";
var addVal = "Add";
var L10N_TAGS = "<META http-equiv='content-type' content=text/html;charset=Windows-1252 >";
var blankDefValue = "ERROR:\n\" {0} \" is an invalid input. It must be a positive number.";
var checkBroadcastSSSID = "WARNING:\nSSID {0}  replaces SSID {1}  as the Broadcast SSID.";
var checkVLANSelected = "ERROR:\n\" {0} ' is an invalid input.\nVLAN ID must be between 1 and 4094.";
var checkNativeVLAN = "WARNING:\nVLAN {0}  replaces VLAN {1}  as the native VLAN.";
var retCheckVLANSelected = "ERROR:\n'{0}' is an invalid input.\nVLAN ID must be between 1 and 4094.";
var blankIPAndMask = "ERROR:\nPlease enter a valid ip address and netmask for interface {0}  or uncheck it"; 
var blankIP = "ERROR:\nPlease enter a valid ip address for interface {0}.";
var blankMask = "ERROR:\nPlease enter a valid netmask for interface {0} ";
var rteNetOverlap = "ERROR:\nPlease enter a different ip address and netmask for interface {0}  or its subinterface" ;
var checkNetAdd = "ERROR:\nThe number of netmask bits is less or equal to IP address network address. \n Please enter a different ip address and netmask for interface {0} or its subinterface" ;
var radioNetList = "ERROR:\nPlease enter a different ip address and netmask for interface {0} or its subinterface" ;
var chkClockTime = "inside if {0}";
var fragMentVal = "ERROR:\n'Fragmentation Threshold' must be between 256 and  {0}.";
var txtRTSValStrRes = "ERROR:\n'RTS Threshold' must be between 0 and  {0}.";
var VLANEnabled = "ERROR:\nOn VLAN {0}  'encryption mode ciphers tkip' must be configured before setting WPA SSID. (See Wireless Security > Encryption Manager)"; 
var VLANEnabledFal = "ERROR:\nOn Radio{0}  VLAN {1} 'encryption mode ciphers tkip' must be configured before setting WPA SSID. (See Wireless Security > Encryption Manager)"; 
var encryptionModeCipher = "ERROR:\n 'encryption mode ciphers tkip' must be configured before setting WPA SSID. (See Wireless Security > Encryption Manager)"; 
var encryptionModeCipherElse = "ERROR:\nOn Radio{0} 'encryption mode ciphers tkip' must be configured before setting WPA SSID. (See Wireless Security > Encryption Manager)"; 
var clientSecVLANEnabled = "WARNING:\nNetwork EAP requires encryption to be set on VLAN {0} to function properly (See Security > Encryption Manager)." ;
var checkLeapEncryption = "WARNING:\nNetwork EAP requires encryption to be set on Radio {0} to function properly (See Security > Encryption Manager)." ;
var checkKey1Encryption = "ERROR:\nOn VLAN {0}'Encryption Key 1' must be removed before setting WPA . (See Security > Encryption Manager)" ;
var checkKeyEncruptionRadio = "ERROR:\n'Encryption Key 1' must be removed before setting WPA . (See Security > Encryption Manager)" ;
var checkKeyEncruptionRadioTransmitKey = "ERROR:\nOn Radio{0}'Encryption Key 1' must be removed before setting WPA . (See Security > Encryption Manager)" ;
var checkKey4Encryption = "ERROR:\nOn VLAN {0} 'Encryption Key 4' must be removed before setting Network EAP or EAP. (See Security > Encryption Manager)";
var checkKey4EncryptionElse = "ERROR:\nOn Radio{0} VLAN {1} 'Encryption Key 4' must be removed before setting Network EAP or EAP. (See Security > Encryption Manager)";
var checkKey4ShowRunRadio = "ERROR:\n 'Encryption Key 4' must be removed before setting Network EAP or EAP. (See Security > Encryption Manager)";
var checkKey4ShowRunRadioElse = "ERROR:\nOn Radio{0} 'Encryption Key 4' must be removed before setting Network EAP or EAP. (See Security > Encryption Manager)";
var OnGlobalAddSSID = "ERROR:\nVLAN {0} does not include interface {1} (see Services > VLAN)." ;
var createRadiusArray = "ERROR: {0} not found! " ;
var displayVLANFilterMsg = "WARING:\nFilter {0} was configured on interface {1} using CLI.\nIt must be cleared via CLI to ensure proper operation of the web interface." ;
var checkFilterProtocolPortNumber = "ERROR:\n{0} is an invalid entry.\nEntry must be between 0 and {1}." ;
var checkIPAddress = "ERROR:\n{0} is an invalid IP address." ;  
var checkAddressElse = "ERROR:\n{0} is an invalid mask." ;
var createFilterCmd =  "ERROR:\nFilter {0}  cannot be renamed while it is applied to an interface. (See Service > Filters > Apply Filters)." ;
var deleteFilterCmd =  "ERROR:\nFilter {0}  cannot be deleted while it is applied to an interface. (See Service > Filters > Apply Filters)." ;
var chkMACAddress = "ERROR:\n{0} is an invalid mask.\nAction cannot be applied to all MAC addresses.\nTo apply action to all packets, use Default Action field." ;
var chkMACAddressPattern  = "ERROR:\n{0} is an invalid mask. Enter a valid mask." ;
var chkMACAddressPatternElse  = "ERROR:\n{0} is an invalid MAC address. Enter a valid MAC address." ;
var chkVLANCfg = "WARNING:\nVLAN \"{0}\" could be invalid.\nCheck encapsulation and/or bridge-group under each subinterface." ;
var warningDefaultVlanChanges = "WARNING:\nVLAN {0} replaces VLAN {1} as the native VLAN.";
var validateVlan = "ERROR:\n'{0}' is an invalid input.\nBridge Group Number must be between 1 and 255." ;
var validateVLANBlank = "ERROR:\n'{0}' is an invalid input.\nVLAN ID must be between 1 and 4094.";
var ssIDIndex = "ERROR:\nFor {0}, SSID is an infrastructure-SSID and must be configured as the native VLAN." ;
var deleteFilterElement =  "ERROR:\nSelect a {0} to delete." ;
var chkFilterIndex = "ERROR:\n'Filter Index' must be between {0} and {1}.";
var chkACLListe =  "ERROR:\nFilter {0} already exists." ;
var createFilterListe =  "ERROR:\nFilter {0}cannot be renamed while it is applied to an interface (See Service > Filters > Apply Filters)." ;
var timeInMinutes = "minutes";
var unknowMsg = "unknown";
var channel = "Channel";
var legacyVal = "Legacy";
var indoorVal ="Indoor";
var outdoorVal = "Outdoor";
var neverVal = "never";
var notApplicable = "n/v";
var charSetVal = "Windows-1252";
var wirelessNetworkMap = "Wireless Network Map";
var blankEncrypKeyMsg = "ERROR:\nEnter a hexadecimal number for Encryption Key '{0}'";
var blankEncrypKeyLength10Msg = "ERROR:\nEncryption Key '{0}' must be 10 hexadecimal characters.";
var blankEncrypKeyLength26Msg = "ERROR:\nEncryption Key '{0}' must be 26 hexadecimal characters.";

/* atg_stationview-client.shtml */

var atg_class = "Class";
var repeater = "Repeater";
var ccxVersion = "CCX Version";
var state = "State";
var eapAssociated = "EAP-Associated";
var macAssociated = "MAC-Associated";
var asociated = "Associated";
var associationProcess = "Association processing";
var parent_str = "Parent";
var ssidWithoutGaps = "SSID";
var noneOption1 = "none";
var hopsInfrastructure = "Hops To Infrastructure";
var interfaceCommn = "Communication Over Interface";
var clientsAssociated = "Clients Associated";
var repeatersAssociated = "Repeaters Associated";
var keyMgmtType = "Key Mgmt type";
var encryptionWithoutGap = "Encryption";
var currentRate = "Current Rate (Mb/sec)";
var capability = "Capability";
var supportedRates = "Supported Rates(Mb/sec)";
var assiciationID = "Association Id";
var signalStrength = "Signal Strength (dBm)";
var connTime = "Connected For (sec)";
var signalQuality = "Signal Quality (%)";
var activityTimeout = "Activity TimeOut (sec)";
var powerSave = "Power-save";
var lastActivityTime = "Last Activity (sec)";
var recTransStats = "Receive/Transmit Statistics";
var duplicateReceived = "Duplicates Received";
var maxEntries = "Maximum Data Retries";
var decryptErrors = "Decrypt Errors";
var maxRTSRetries = "Maximum RTS Retries";
var micFailedStatus = "MIC Failed";
var micMissing = "MIC Missing";
var stationViewClientAssociation = "Association: Station View- Client";
var statusInfo = "Station Information and Status";

/* atg_services_qos-traffic.shtml */
var warning213 = "ERROR:\n'Contention Window' must be between 0 and 10.";
var warning214 = "ERROR:\n'Min Contention Window' cannot exceed 'Max Contention Window'.";
var warning215 = "ERROR:\n'Slot Time' must be between 0 and 20.";
var warning216 = "ERROR:\n'Transmit Opportunity' must be between 0 and 65535.";
var warning217 = "ERROR:\n'Max Channel Capacity'and 'Roam Channel Capacity' must be a number between 0 and 100.";
var warning218 = "ERROR:\n'Roam Channel Capacity' must be between 0 and 100.";
var warning219 = "ERROR:\n'Max Channel Capacity' must be between 0 and 100.";
var warning220 = "ERROR:\n'Roam Channel Capacity' must be less than 'Max Channel Capacity'.";
var warning221 = "ERROR:\nCheck 'Admission Control' to modify this field.";
var warning222 = "\" is an invalid input. It must be a number.";
var wifiMultimedia = "WiFi Multimedia(WMM)";
var accessCategoryDefinition = "Access Category Definition";
var accessCategory = "Access Category";
var background = "Background";
var bestEffort = "Best Effort";
var video = "Video";
var voice = "Voice";
var minContentionWindow = "Min Contention Window";
var local = "Local";
var maxContentionWindow = "Max Contention Window";
var cell = "Cell";
var fixedSlotTime = "Fixed Slot Time";
var admissionControl = "Admission Control";
var servicesQoS = "Services - QoS";
var msg0 = "WFA Default Setting will make the following changes:\n";
var msg1 = "The values of 'Access Category Definition' will be changed for WFA defaults.\n   (See 'Access Category Definition' section)\n";
var msg2 = "The Gratuitous Probe Response(GPR) will be disabled on this Radio.\n   (See Network Interfaces > Radio1-802.11A > Setting)\n";
var msg3 = "\n To apply those changes, click 'Apply' button.";
  