/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

var atg_ret_value= isATG(product); 

function getRteSubVlanList(showRun,showVlan) {

var etherResults, radioResults;
 var vlan = new Array();
 vlan = getShowVlanList(showVlan);

  var i = 0;
  var index;
  var vlanArray = new Array();
 
  for(index=0; index<vlan.length; index++)
  {
  
  var count=0;
   
  
  if (atg_ret_value == 1)  {
                
         var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index] + ")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)"; 
        var radioPattern1 = new RegExp(radioPattern, "g");  
        
          
         }
         else if (atg_ret_value == 2)
         {
         
          var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d\/\\d\/\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index]+")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)"; 
	         
        var radioPattern1 = new RegExp(radioPattern, "g");  
         }
         else
         {
     
         var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index] + ")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)"; 
             
        var radioPattern1 = new RegExp(radioPattern, "g");  
      }
  
  
  radioResults = showRun.match(radioPattern1);
  
   var subIf = new Array();
 
  	while ((radioResults) && (count < radioResults.length)) { 
  	if (atg_ret_value == 1)  { 	
        var dot11Pattern = "interface Dot11Radio(\\d).(\\d+)[\\r\\n]+";
  	}
  	else if (atg_ret_value == 2)
         {
        var dot11Pattern = "interface Dot11Radio(\\d\/\\d\/\\d).(\\d+)[\\r\\n]+";
         }
         else
         {
        var dot11Pattern = "interface Dot11Radio(\\d).(\\d+)[\\r\\n]+";
         }
  	var dot11Res = radioResults[count].match(dot11Pattern);
  	
  	
  	 subIf[count] = "Dot11Radio" + dot11Res[1] + "." + dot11Res[2];
  	 
  	  count++;
	}
   
  vlanArray[index] = new vlanObject("VLAN " + vlan[index], vlan[index], vlan[index], subIf);
  
       
   delete subIf; 
  
  }
  
       return vlanArray;
}

function getSubVlanList(showRun,showVlan) {

var etherResults, radioResults;
 var vlan = new Array();
 vlan = getShowVlanList(showVlan);
  
  var i = 0;
  var index;
  var vlanArray = new Array();
  var brgGrpNum;
 
  for(index=0; index<vlan.length; index++)
  {
  
  var count=0;
   
  
  if (atg_ret_value == 1)  {
                
         var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index] + ")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* bridge-group (\\d+)[\\r\\n]+"; 
        var radioPattern1 = new RegExp(radioPattern, "g");  
        
          
         }
         else if (atg_ret_value == 2)
         {
         
          var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d\/\\d\/\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index] + ")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* bridge-group (\\d+)[\\r\\n]+"; 
	         
        var radioPattern1 = new RegExp(radioPattern, "g");  
         }
         else
         {
     
       var radioPattern = "![\\r\\n]+interface Dot11Radio(\\d).(\\d+)[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* encapsulation dot1Q (" + vlan[index] + " native|" + vlan[index] + ")[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)* bridge-group (\\d+)[\\r\\n]+"; 
             
        var radioPattern1 = new RegExp(radioPattern, "g");  
      }
  
  
  radioResults = showRun.match(radioPattern1);
  
   var subIf = new Array();
 
  	while ((radioResults) && (count < radioResults.length)) { 
  	if (atg_ret_value == 1)  { 	
        var dot11Pattern = "interface Dot11Radio(\\d).(\\d+)[\\r\\n]+";
  	}
  	else if (atg_ret_value == 2)
         {
        var dot11Pattern = "interface Dot11Radio(\\d\/\\d\/\\d).(\\d+)[\\r\\n]+";
         }
         else
         {
        var dot11Pattern = "interface Dot11Radio(\\d).(\\d+)[\\r\\n]+";
         }
  	var dot11Res = radioResults[count].match(dot11Pattern);
  	var brgGrpNumStr = radioResults[count].split(/\s+bridge-group\s+/);

	if (brgGrpNumStr)
	{
	    brgGrpNum = brgGrpNumStr[1].match(/\d+/);
	}
  	
  	
  	 subIf[count] = "Dot11Radio" + dot11Res[1] + "." + dot11Res[2];
  	 
  	  count++;
	}
  
  if(brgGrpNum && subIf.length > 0)
  {
      vlanArray[index] = new vlanObject("VLAN " + vlan[index], vlan[index], brgGrpNum[0], subIf);
  }
  else
  {
      vlanArray[index] = new vlanObject("VLAN " + vlan[index], vlan[index], "", subIf);
  }
  
       
   delete subIf; 
  
  }
  
       return vlanArray;
}



function getShowVlanList(showVlan) {
  var i = 0;
   if (atg_ret_value == 1)  {
  var vlanIdPattern = "Virtual LAN ID:\\s+(\\d+) \\(IEEE 802.1Q Encapsulation\\)[\\r\\n]+[\\r\\n]+\\s+vLAN Trunk (Interface|Interfaces):\\s+(Dot11Radio)\\d\\.\\d+" 
  }
  else if (atg_ret_value == 2)
   {
   var vlanIdPattern = "Virtual LAN ID:\\s+(\\d+) \\(IEEE 802.1Q Encapsulation\\)[\\r\\n]+[\\r\\n]+\\s+vLAN Trunk (Interface|Interfaces):\\s+(Dot11Radio)\\d\/\\d\/\\d\\.\\d+" 
   }
   else
   {
  var vlanIdPattern = "Virtual LAN ID:\\s+(\\d+) \\(IEEE 802.1Q Encapsulation\\)[\\r\\n]+[\\r\\n]+\\s+vLAN Trunk (Interface|Interfaces):\\s+(Dot11Radio)\\d\\.\\d+" 
     }
  var showVlanArray = new Array();
  vlanResults = showVlan.match(vlanIdPattern);
  while (vlanResults) {
	showVlanArray[i++] = vlanResults[1];
	vlanResults = vlanResults.input.substring(vlanResults[0].length + vlanResults.index).match(vlanIdPattern);
  }

  return showVlanArray;
}
