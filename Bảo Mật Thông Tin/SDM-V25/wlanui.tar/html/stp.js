/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

function getStpList(showSpan) {
  var bgResults, radioResults, fEthernetResults;
  var bridgeGroup, bridgeGroupPriority, bridgeGroupHelloTime, bridgeGroupMaxAge, bridgeGroupForwardTime;
  var radioPathCost,  radioPortPriority;
  var fEthernetPathCost, fEthernetPortPriority;
  var subInt, radioEnabled, fEthernetEnabled;

  var stpArray = new Array();
  var i=0;

   //get the Bridge Properties for STP
  var bgPattern = "Bridge group (\\d+) is executing the .+ compatible Spanning Tree protocol\\r\\n  Bridge Identifier has priority (\\d+), address .+\\r\\n  Configured hello time (\\d+), max age (\\d+), forward delay (\\d+)\\r\\n";
  bgResults = showSpan.match(bgPattern);
  while (bgResults) {
	bridgeGroup = bgResults[1];
	bridgeGroupPriority = bgResults[2];
	bridgeGroupHelloTime = bgResults[3];
	bridgeGroupMaxAge = bgResults[4];
	bridgeGroupForwardTime = bgResults[5];
    //get all the FastEthernet Port Properties of the Brdge Group
    var fEthernetPattern;
    if(isGigabit()){
       fEthernetPattern = "\\(GigabitEthernet\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)\\r\\n   Port path cost (\\d+), Port priority (\\d+),";
    }else{
       fEthernetPattern = "\\(FastEthernet\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)\\r\\n   Port path cost (\\d+), Port priority (\\d+),";
    }
    fEthernetResults = showSpan.match(fEthernetPattern);
    while(fEthernetResults){
    	fEthernetEnabled=fEthernetResults[2];
    	fEthernetPathCost = fEthernetResults[3];
    	fEthernetPortPriority = fEthernetResults[4];
    	fEthernetResults = fEthernetResults.input.substring(fEthernetResults[0].length + fEthernetResults.index).match(fEthernetPattern);
     }
    //get all the Radio Port Properties of the Brdge Group
    var radioPattern = "\\(Dot11Radio\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)\\r\\n   Port path cost (\\d+), Port priority (\\d+),";
    radioResults = showSpan.match(radioPattern);
    while(radioResults){
	subInt=radioResults[1];
    	radioEnabled=radioResults[2];
    	radioPathCost = radioResults[3];
    	radioPortPriority = radioResults[4];
    	radioResults = radioResults.input.substring(radioResults[0].length + radioResults.index).match(radioPattern);
     }
    if (fEthernetEnabled != null && radioEnabled != null) {
           stpArray[i++] = new stpObject(bridgeGroup, subInt, bridgeGroupPriority, bridgeGroupHelloTime, 
                                         bridgeGroupMaxAge, bridgeGroupForwardTime, fEthernetPathCost,
                                         fEthernetPortPriority, radioPathCost, radioPortPriority);
    }
    fEthernetEnabled = null ;
    radioEnabled = null ;
    bgResults = bgResults.input.substring(bgResults[0].length + bgResults.index).match(bgPattern);
  }
  return stpArray;
}

function getStpListBrief(showSpan) {
  var bgResults, radioResults, fEthernetResults;
  var bridgeGroup, bridgeGroupPriority, bridgeGroupHelloTime, bridgeGroupMaxAge, bridgeGroupForwardTime;
  var radioPathCost,  radioPortPriority;
  var fEthernetPathCost, fEthernetPortPriority;
  var subInt, radioEnabled, fEthernetEnabled;

  var stpArray = new Array();
  var i=0;

   //get the Bridge Properties for STP
  var bgPattern = "Bridge group (\\d+) is executing the .+ compatible Spanning Tree protocol";
  bgResults = showSpan.match(bgPattern);
  while (bgResults) {
	bridgeGroup = bgResults[1];
	bridgeGroupPriority = 0;
	bridgeGroupHelloTime = 0;
	bridgeGroupMaxAge = 0;
	bridgeGroupForwardTime = 0;
    //get all the FastEthernet Port Properties of the Brdge Group
    var fEthernetPattern;
    if(isGigabit()){
      fEthernetPattern = "\\(GigabitEthernet\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)";
    }else{
      fEthernetPattern = "\\(FastEthernet\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)";
    }
    fEthernetResults = showSpan.match(fEthernetPattern);
    while(fEthernetResults){
    	fEthernetEnabled=fEthernetResults[2];
    	fEthernetPathCost = 0;
    	fEthernetPortPriority = 0;
    	fEthernetResults = fEthernetResults.input.substring(fEthernetResults[0].length + fEthernetResults.index).match(fEthernetPattern);
     }
    //get all the Radio Port Properties of the Brdge Group
    var radioPattern = "\\(Dot11Radio\\d\\.?(\\d*)\\) of Bridge group " + bridgeGroup + " is (\\w+)";
    radioResults = showSpan.match(radioPattern);
    while(radioResults){
	subInt=radioResults[1];
    	radioEnabled=radioResults[2];
    	radioPathCost = 0;
    	radioPortPriority = 0;
    	radioResults = radioResults.input.substring(radioResults[0].length + radioResults.index).match(radioPattern);
     }
    if (fEthernetEnabled != null && radioEnabled != null) {
           stpArray[i++] = new stpObject(bridgeGroup, subInt, bridgeGroupPriority, bridgeGroupHelloTime, 
                                         bridgeGroupMaxAge, bridgeGroupForwardTime, fEthernetPathCost,
                                         fEthernetPortPriority, radioPathCost, radioPortPriority);
    }
    fEthernetEnabled = null ;
    radioEnabled = null ;
    bgResults = bgResults.input.substring(bgResults[0].length + bgResults.index).match(bgPattern);
  }
  return stpArray;
}
