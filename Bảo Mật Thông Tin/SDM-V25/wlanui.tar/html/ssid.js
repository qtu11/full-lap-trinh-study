/*
 * Copyright (c) 2004-2007 by cisco Systems, Inc.
 * All rights reserved.
 */
 
var ssidSettingsArray = new Array()
var guestModeIndex = new Array()
var repeaterModeIndex = new Array()
var repeaterModeOpt = new Array()
var filterArray = new Array();
var radiusArray = new Array();
var localServerEnable = false;

//Determine if a string is a number
function isNum(testStr)
{
  if(testStr == "" || typeof(testStr) == "undefined"){
    return false; 
  }
  if (testStr.search(/^\s*\d+\s*$/) != -1) {
    //non-zero numbers starting with 0 may be interpreted by IOS as octal.
    //Disallow them to avoid surprises one way or the other.
    if (testStr.search(/^\s*0+[1-9]/) != -1)
      return false
    else
      return true
  }
  return false
}
// Converts patterns like \134xHH or \134ooo to \xHH or \ooo
function ssid_decode_directive(src)
{
 var     dst = "";
 var     c;
 var     i;
 var     escape = 0;
 for(i = 0;i < src.length;i += 1)
 {
     c = src.charAt(i);
     if (escape == 0 &&
         c == '\\' &&
         src.charAt(i + 1) == '1' &&
         src.charAt(i + 2) == '3' &&
             src.charAt(i + 3) =='4') {
         dst += c;
         i = i + 3;
     } else {
         if (c == '\\') {
             escape = 1;
         } else {
             escape = 0;
         }
         dst +=c;
     }
 }
 return dst;
}

function preSharedKeyObject()
{
  this.key = ""
  this.type = ""
  this.encrypted = 0
}

function groupObject(name, methodList)
{
  this.name = name;
  this.methodList = methodList;
  this.server1Index = 0;
  this.server2Index = 0;
  this.server3Index = 0;
}


function ssidSettingsObject()
{
  this.ssid = ""
  this.vlan = 0;
  this.vlanName = 0;
  this.vlanIndex = 0
  this.vlan1 = "";
  this.vlan2 = "";
  this.vlan3 = "";
  this.vlanName1 = 0;
  this.vlanName2 = 0;
  this.vlanName3 = 0;
  this.enableSsidl = false
  this.enableSsidlWps = false
  this.enableSsidlAdvertise= false
  this.enablePMIP = false
  this.enableAcct = false
  this.username = ""
  this.password = ""
  this.pwEncryption = ""
  this.limit = ""
  this.open = false
  this.openPlus = -1
  this.shared = false
  this.sharedPlus = -1
  this.eap = false
  this.eapPlus = false
  this.cckm = false
  this.wpa = false
  this.wpaV1 = false
  this.wpaV2 = false
  this.mfp = "optional"
  this.cac = false
  this.keyMgmtOptional = false;
  this.preSharedKey = new preSharedKeyObject()
  this.eapServerGroup = null;
  this.macServerGroup = null;
  this.acctServerGroup = null;
  this.networkID = ""
  this.redirection = "";
  this.redirectionFilterIndex = 0;
  this.numInt = 0;
  this.infra = false;
  this.mguest = false;
  this.dtim = 0;
  this.attachedInt = new Array();
  this.vlanExists = new Array();
  this.bssid = new Array();
  this.isGuest = new Array();
  this.mbssid = new Array();
  if (typeof(apDot1xObject) != "undefined") {
    this.dot1x = new apDot1xObject();
  }
  for (var i=0; i<radioArray.length; i++) {
    this.attachedInt[i]=false;
    this.vlanExists[i]=false;
    this.bssid[i]="";
    this.isGuest[i] = false;
    this.mbssid[i] = false;
  }
}

function findVlanName(htmlShowRun,name){
  var pattern, results;
  if(name == ""){
     return "";
  }
  if(!isNum(name)){
    return name;
  }
  pattern = "dot11 vlan-name (\\w+) vlan " + name;
  vname = htmlShowRun.match(pattern);
  if(vname){
    return vname[1];
  } 
  return "";
}
function findVlanId(htmlShowRun,name){
  var pattern, results;
  if(name == ""){
    return "";
  }
  if(isNum(name)){
    return name;
  }
  pattern = "dot11 vlan-name " + name + " vlan (\\d+)";
  vid = htmlShowRun.match(pattern);
  if(vid){
    return vid[1];
  } 
  return "";
}

function createFilterArray(htmlShowRun){
  var count = 0;
  var pattern, results;

  pattern = /ip access-list extended (\S+)[\r\n]+(( (permit|deny) [^\r\n]+[\r\n]+)+)/
  results = htmlShowRun.match(pattern);
  while (results != null) {
    if (isValidName(results[1])) {
      if (isGoodIpFilter(results[2])) {
        filterArray[count++] = results[1];  
      }
    }
    results = results.input.substring(results[0].length  + results.index).match(pattern);
  }		
}

function findFilterIndex(name)
{
  for (i=0; i < filterArray.length; i++) {
    if (filterArray[i] == name)
      return i+1;
  }
  return 0;
}

//find index of 'server' inside radiusArray
function findServerIndex(server)
{
  for (var i=0; i<radiusArray.length; i++) {
    if (radiusArray[i].name == server)
      return i+1;
  }
  alert("ERROR: "+server+" not found!");
}

//return group object corresponding to groupName
function createGroupObject(groupName, methodList, htmlServers)
{
  var form = document.forms[0];
  var curLine = "";        //line from lineArray under observation
  var curGroup = null;     //group under observation
  var results;             //match results
  var serverResults;       //match results
  var sgArray;             //array of servers in this group
  var lineArray = htmlServers.split("aaa group ");
  
  for (var index = 0; index<lineArray.length; index++) {
    curLine = lineArray[index];
    results = curLine.match(/server radius (\w+)/);
    if (!results || (results[1] != groupName)) continue;
    curGroup = new groupObject(groupName, methodList);

    sgArray = curLine.split(DLIM_newline);
    for (var count=1; count<sgArray.length && count < 4; count++) {
      serverResults = sgArray[count].match(/server (\S+)/);
      if (serverResults) {
        curServer = serverResults[1];
        //account for LRS
        if ((groupName.match(/rad_eap/)) && localServerEnable && 
            (curServer == radiusArray[radiusArray.length-1].name))
          break;
        if (count == 1)
          curGroup.server1Index = findServerIndex(curServer);
        else if (count == 2)
          curGroup.server2Index = findServerIndex(curServer);
        else if (count == 3)
          curGroup.server3Index = findServerIndex(curServer);
      }
    }
    return curGroup;
  }
  //no servers in this group/methodlist
  return new groupObject(groupName, methodList);
}

function createSSIDArrays(htmlShowRun,htmlShowBssid,htmlAcctMethod,htmlEapMacMethod,htmlServers)
{
  var index = 0
  var vlanToken = ""
  var results;
  var pattern;
  var matchResults;
  var matchResults1;
  var matchResults2;
  var matchResults3;
  var curShowRun;
  var temp_ssid;

  createFilterArray(htmlShowRun);
    var infoArray = htmlShowRun.split(/[\r\n]dot11 ssid /)
    var index = -1;
    for (arrayIndex = 1; arrayIndex<infoArray.length; arrayIndex++) {
      tempArray = infoArray[arrayIndex].split(/[\r\n]!/)
      if (tempArray == null) {
        continue
      }
      curInfo = tempArray[0] + "\n"
      results = curInfo.match(/[^\r\n]+/)
      if (results == null) {
        continue
      }
      index++;
      ssidSettingsArray[index] = new ssidSettingsObject()
      temp_ssid = results[0];
      ssidSettingsArray[index].ssid = ssid_decode_directive(results[0]);

      vlanToken = curInfo.match(/vlan (\w+) backup (\w+)\s*(\w*)\s*(\w*)\r\n/);
      if (vlanToken) {
      	ssidSettingsArray[index].vlan = findVlanId(htmlShowRun,vlanToken[1]);
      	ssidSettingsArray[index].vlan1 =findVlanId(htmlShowRun,vlanToken[2]);
      	ssidSettingsArray[index].vlan2 =findVlanId(htmlShowRun,vlanToken[3]);
      	ssidSettingsArray[index].vlan3 =findVlanId(htmlShowRun,vlanToken[4]);

      	ssidSettingsArray[index].vlanName = findVlanName(htmlShowRun,vlanToken[1]);
      	ssidSettingsArray[index].vlanName1 =findVlanName(htmlShowRun,vlanToken[2]);
      	ssidSettingsArray[index].vlanName2 =findVlanName(htmlShowRun,vlanToken[3]);
      	ssidSettingsArray[index].vlanName3 =findVlanName(htmlShowRun,vlanToken[4]);
      }else{
         vlanToken = curInfo.match(/vlan (\w+)/);
         if(vlanToken){
      	   ssidSettingsArray[index].vlan = findVlanId(htmlShowRun,vlanToken[1]);
         	ssidSettingsArray[index].vlan1 ="";
      	   ssidSettingsArray[index].vlan2 ="";
         	ssidSettingsArray[index].vlan3 ="";

      	   ssidSettingsArray[index].vlanName = findVlanName(htmlShowRun,vlanToken[1]);
      	   ssidSettingsArray[index].vlanName1 ="";
      	   ssidSettingsArray[index].vlanName2 ="";
      	   ssidSettingsArray[index].vlanName3 ="";
         }
      }

      if (typeof(apDot1xObject) != "undefined") {
        apDot1xCreateObj(curInfo, ssidSettingsArray[index].dot1x)
      }

      for (var i=0; i<radioArray.length; i++) {
        var radioNum = radioArray[i].number
        curShowRun = htmlShowRun.match("![\\r\\n]+interface Dot11Radio"+radioNum+"[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)+![\\r\\n]+")[0];
        if (curShowRun.match(" ssid "+ esc_js_regexp(temp_ssid) + "[\\r\\n]+")) {
          ssidSettingsArray[index].attachedInt[i]= true;
          ssidSettingsArray[index].numInt++;
	    }
        if (htmlShowRun.match("![\\r\\n]+interface Dot11Radio"+radioNum+"."+ssidSettingsArray[index].vlan+"[\\r\\n]+")) {
          ssidSettingsArray[index].vlanExists[i]= true;
	    }
        if (results=htmlShowBssid.match("[\\r\\n]+Dot11Radio"+radioNum+"\\s+([\\w\\.]+)\\s+(No|Yes)\\s+"+ esc_js_regexp(ssidSettingsArray[index].ssid))) {
          ssidSettingsArray[index].bssid[i]= results[1];
          ssidSettingsArray[index].isGuest[i] = results[2]=="Yes"?true:false;
        }		
        if (mbssidIsEnabled(radioNum, htmlShowRun)) {
          ssidSettingsArray[index].mbssid[i] = true;
        } else {
          ssidSettingsArray[index].mbssid[i] = false;
        }
      }
      if (curInfo.indexOf("information-element ssidl") != -1) {
        ssidSettingsArray[index].enableSsidl = true
      }

      if (curInfo.indexOf("admit-traffic") != -1) {
        ssidSettingsArray[index].cac = true
      }
      if (curInfo.indexOf("information-element ssidl advertisement wps") != -1) {
        ssidSettingsArray[index].enableSsidlWps = true
      }

      if (curInfo.indexOf("information-element ssidl advertisement") != -1) {
        ssidSettingsArray[index].enableSsidlAdvertise = true
      }

      if (curInfo.indexOf("information-element ssidl wps") != -1) {
        ssidSettingsArray[index].enableSsidlWps = true
      }

      if (curInfo.indexOf("proxy-mobile") != -1) {
        ssidSettingsArray[index].enablePMIP = true
      } 
      if (curInfo.indexOf("   mbssid guest-mode") != -1) {
        ssidSettingsArray[index].mguest = true
      }
      if (curInfo.indexOf("   guest-mode") != -1) {
        guestModeIndex[index] = true;
      }
      vlanToken = curInfo.match(/dtim-period (\d+)\r\n/);
      if (vlanToken) {
        ssidSettingsArray[index].dtim = vlanToken[1]
      }

      matchResults = curInfo.match(/accounting (\w+)/);
      if (matchResults) {
        ssidSettingsArray[index].enableAcct = true
        var acctMethod = matchResults[1];
        if (acctMethod != "acct_methods") {
          //find group corresponding to this methodlist
          pattern = "aaa accounting network "+acctMethod+" start-stop group (\\w+)"; 
          matchResults = htmlAcctMethod.match(pattern);
          if (matchResults)
            ssidSettingsArray[index].acctServerGroup = createGroupObject(matchResults[1], acctMethod, htmlServers);
          else
            ssidSettingsArray[index].acctServerGroup = createGroupObject("", acctMethod, htmlServers);
        }
      } 
    
      if (curInfo.indexOf("authentication client") != -1) {
        var curToken = ""
        ssidSettingsArray[index].username = token_offset_str(/authentication client username/, DLIM_WhSp, 1, "", curInfo)
        curToken = token_string_label_to_eol("password 0 ", curInfo)
        if (curToken) {
          ssidSettingsArray[index].password = curToken
          ssidSettingsArray[index].pwEncryption = "0 "
        } else {
          curToken = token_string_label_to_eol("password 7 ", curInfo)
          if (curToken) {
            ssidSettingsArray[index].password = curToken
            ssidSettingsArray[index].pwEncryption = "7 "
          } 
        }
      } 

      if (curInfo.indexOf("max-associations") != -1) {
        ssidSettingsArray[index].limit = token_offset_str(/max-associations/, DLIM_WhSp, 1, "", curInfo)
      } 
      if (curInfo.indexOf("mobility network-id") != -1) {
        ssidSettingsArray[index].networkID = token_offset_str(/mobility network-id/, DLIM_WhSp, 1, "", curInfo)
      } 
      matchResults = curInfo.match(/ip redirection host (\S+)/);
      if (matchResults)
        ssidSettingsArray[index].redirection = matchResults[1];
      matchResults = curInfo.match(/ip redirection host \S+ access-group (\S+) in/);
      if (matchResults) {
        ssidSettingsArray[index].redirectionFilterIndex = findFilterIndex(matchResults[1]);
      }
      //determine EAP group
      matchResults = curInfo.match(/(authentication) (network-eap) (\w+)/);
      if (!matchResults)
        matchResults = curInfo.match(/authentication (open|shared) ([^\r\n]+ )*eap (\w+)/);
      if (matchResults) {
        var eapMethod = matchResults[3];
        //test for bad CLI
        matchResults1 = curInfo.match(/authentication network-eap (\w+)/);
        matchResults2 = curInfo.match(/authentication open ([^\r\n]+ )*eap (\w+)/);
        matchResults3 = curInfo.match(/authentication shared ([^\r\n]+ )*eap (\w+)/);
        if ((matchResults1 && matchResults1[1] != eapMethod) ||
            (matchResults2 && matchResults2[2] != eapMethod) ||
            (matchResults3 && matchResults3[2] != eapMethod))
          badCLI = true;
        if (eapMethod != "eap_methods") {
          //find group corresponding to this methodlist
          pattern = "aaa authentication login "+eapMethod+" group (\\w+)"; 
          matchResults = htmlEapMacMethod.match(pattern);
          if (matchResults)
            ssidSettingsArray[index].eapServerGroup = createGroupObject(matchResults[1], eapMethod, htmlServers);
          else
            ssidSettingsArray[index].eapServerGroup = createGroupObject("", eapMethod, htmlServers);
        }
      } 

      //determine MAC group
      matchResults = curInfo.match(/authentication (network-eap|open|shared) ([^\r\n]+ )*mac-address (\w+)/);
      if (matchResults) {
        var macMethod = matchResults[3];
        //test for bad CLI
        matchResults1 = curInfo.match(/authentication network-eap ([^\r\n]+ )*mac-address (\w+)/);
        matchResults2 = curInfo.match(/authentication open ([^\r\n]+ )*mac-address (\w+)/);
        matchResults3 = curInfo.match(/authentication shared ([^\r\n]+ )*mac-address (\w+)/);
        if ((matchResults1 && matchResults1[2] != macMethod) ||
            (matchResults2 && matchResults2[2] != macMethod) ||
            (matchResults3 && matchResults3[2] != macMethod))
          badCLI = true;
        if (macMethod != "mac_methods") {
          //find group corresponding to this methodlist
          pattern = "aaa authentication login "+macMethod+" group (\\w+)"; 
          matchResults = htmlEapMacMethod.match(pattern);
          if (matchResults)
            ssidSettingsArray[index].macServerGroup = createGroupObject(matchResults[1], macMethod, htmlServers);
          else
            ssidSettingsArray[index].macServerGroup = createGroupObject("", macMethod, htmlServers);
        }
      } 

      if (curInfo.match(/authentication open optional eap/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 5
      } else if (curInfo.match(/authentication open mac-address \w+ alternate/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 4
      } else if (curInfo.match(/authentication open mac-address \S+ eap/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 3
      } else if (curInfo.match(/authentication open eap/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 2
      } else if (curInfo.match(/authentication open mac-address/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 1
      } else if (curInfo.match(/authentication open/)) {
        ssidSettingsArray[index].open = true
        ssidSettingsArray[index].openPlus = 0
      }
      if (curInfo.match(/authentication shared mac-address \w+ eap/)) {
        ssidSettingsArray[index].shared = true
        ssidSettingsArray[index].sharedPlus = 3
      } else if (curInfo.match(/authentication shared eap/)) {
        ssidSettingsArray[index].shared = true
        ssidSettingsArray[index].sharedPlus = 2
      } else if (curInfo.match(/authentication shared mac-address/)) {
        ssidSettingsArray[index].shared = true
        ssidSettingsArray[index].sharedPlus = 1
      } else if (curInfo.match(/authentication shared/)) {
        ssidSettingsArray[index].shared = true
        ssidSettingsArray[index].sharedPlus = 0
      } 

      if (curInfo.match(/authentication network-eap \w+ mac-address/)) {
        ssidSettingsArray[index].eap = true
        ssidSettingsArray[index].eapPlus = true
      } else if (curInfo.match(/authentication network-eap/)) {
        ssidSettingsArray[index].eap = true
        ssidSettingsArray[index].eapPlus = false
      } 

      matchResults = (curInfo.match(/authentication key-management( wpa)?( version 1)?( version 2)?( cckm)?( optional)?/));
      if (matchResults && matchResults[1]) {
        if (matchResults[3]) {
          ssidSettingsArray[index].wpaV2 = true;
        } else if (matchResults[2]) {
          ssidSettingsArray[index].wpaV1 = true;
        } else {
          ssidSettingsArray[index].wpa = true;
        }
      }
      if (matchResults && matchResults[4])
        ssidSettingsArray[index].cckm = true;
      if (matchResults && matchResults[5])
        ssidSettingsArray[index].keyMgmtOptional = true;

      var preSharedKeyObj = new preSharedKeyObject()
      var results = curInfo.match(/wpa-psk (\w+) (\d) ([^\r\n]+)/);
      if (results) {
        preSharedKeyObj.key = results[3]
        preSharedKeyObj.type = results[1];
        preSharedKeyObj.encrypted = results[2]        
      }
      ssidSettingsArray[index].preSharedKey = preSharedKeyObj
      if (curInfo.indexOf("infrastructure-ssid") != -1) {
      	ssidSettingsArray[index].infra = true;
        repeaterModeIndex[index] = true
      }
      if (curInfo.indexOf("infrastructure-ssid optional") != -1){
        repeaterModeOpt[index] = true
      }
      if (curInfo.indexOf("no ids mfp client") != -1) {
        ssidSettingsArray[index].mfp = "";
      } else if (curInfo.indexOf("ids mfp client required") != -1) {
        ssidSettingsArray[index].mfp = "required";
      }
    } //end ssid loop
}

function getSsidIndex(ssid)
{
    for (var i=0; i<ssidSettingsArray.length; i++) {
       if(ssidSettingsArray[i].ssid == ssid)
        return i;
    }
    return -1;
}

function enabledInfrastructureSSID(radioNum)
{
  var indx = 0;
  var pattern = "Dot11Radio(\\d+)";
  if(radioNum >= 0 || radioNum < 10){
     indx = radioNum;
  }else{
    var rn = radioNum.match(pattern);
    if(rn)
      indx = rn[1]
  }
  for (var i=0; i<ssidSettingsArray.length; i++)
     if(ssidSettingsArray[i].attachedInt[indx] == true)
       if(ssidSettingsArray[i].infra == true)
         return true;

  return false;
}

