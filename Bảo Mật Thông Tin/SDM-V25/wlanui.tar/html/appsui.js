/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

function openChildWindow( appuri, windowname ) {
 
	var appwindow = window.open( appuri , windowname, "toolbar=yes,status=yes,top=10,left=10,outerWidth=790,outerHeight=500,width=790,height=500,resizable=yes");
	appwindow.focus();
}

function closeWindow() {

	top.window.close();
}

function openPopup( popupuri, windowname ) {

	var popup = window.open( popupuri , windowname, "toolbar=no,status=no,top=100,left=200,width=300,height=190,resizable=no");
	popup.focus();
}

function replacedStringArr(strToReplace, replacableStrArray) {
	
	var paramSearch ;
	for(var i = 0; i < replacableStrArray.length; i++) {
	paramSearch = "{"+i+"}";
        strToReplace = strToReplace.replace(paramSearch, replacableStrArray[i]);
	}
	return strToReplace;
}

function replacedString(strToReplace, replacableStr) {
	//alert('inside string method');
	var replacedStr;
	replacedStr = strToReplace.replace("{0}", replacableStr);
	return replacedStr;
}


