/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

if (document.images) {
    var sitewide_print_off = new Image();
    var sitewide_print_on = new Image();
    var sitewide_help_off = new Image();
    var sitewide_help_on = new Image();

    if (location.pathname.match("level/15"))
    {
        sitewide_print_off.src = "../../images/sitewide_print_off.gif";
        sitewide_print_on.src = "../../images/sitewide_print_on.gif";
        sitewide_help_off.src = "../../images/sitewide_help_off.gif";
        sitewide_help_on.src = "../../images/sitewide_help_on.gif";
    }
    else
    {
        sitewide_print_off.src = "images/sitewide_print_off.gif";
        sitewide_print_on.src = "images/sitewide_print_on.gif";
        sitewide_help_off.src = "images/sitewide_help_off.gif";
        sitewide_help_on.src = "images/sitewide_help_on.gif";
    }
}


function img_over( name ) {
    if (document.images) {
        imgOn = eval( "sitewide_" + name + "_on.src" );
        document.images[ name+"img" ].src = imgOn;
    }
}


function img_out( name ) {
    if (document.images) {
        imgOff = eval( "sitewide_" + name + "_off.src" );
        document.images[ name+"img" ].src = imgOff;
    }
}


function helpPage(helpRoot) {
  var filename = location.pathname.match("([^\/]*)\.shtml");
  var helpFile;
  if (filename)
  {
      if(filename[0] == "atg_assoc.shtml")
      {
	  helpFile = "as_1.htm"
      }
      else if (filename[0] == "atg_home.shtml")
      {
	  helpFile = "home.htm";
      }
      else if (filename[0] == "atg_network-if.shtml")
      {
	  helpFile = "if_1.htm";
      }
      else if (filename[0] == "atg_network-map.shtml")
      {
	  helpFile = "nm_1.htm";
      }
      else if (filename[0] == "atg_sec.shtml")
      {
	  helpFile = "sec_1.htm";
      }
      else if (filename[0] == "atg_services.shtml")
      {
	  helpFile = "svc_1.htm";
      }
      else if (filename[0] == "atg_assoc_adv.shtml")
      {
	  helpFile = "as_2.htm";
      }
      else if (filename[0] == "atg_express-security.shtml")
      {
	  helpFile = "esc_1.htm";
      }
      else if (filename[0] == "atg_express-security-brg.shtml")
      {
	  helpFile = "esc_2.htm";
      }
      else if (filename[0] == "atg_express-security-rte.shtml")
      {
	  helpFile = "esc_3.htm";
      }
      else if (filename[0] == "atg_express-setup.shtml")
      {
	  helpFile = "es_1.htm";
      }
      else if (filename[0] == "atg_network-if_802-11.shtml")
      {
	  helpFile = "if_2.htm";
      }
      else if (filename[0] == "atg_network-if_802-11_b.shtml")
      {
	  helpFile = "if_3.htm";
      }
      else if (filename[0] == "atg_network-if_802-11_c.shtml")
      {
	  helpFile = "if_4.htm";
      }
      else if (filename[0] == "atg_network-map_ap-adjacent-list.shtml")
      {
	  helpFile = "nm_2.htm";
      }
      else if (filename[0] == "atg_sec_ap-client-security.shtml")
      {
	  helpFile = "sec_3.htm";
      }
      else if (filename[0] == "atg_sec_ap-key-security.shtml")
      {
	  helpFile = "sec_2.htm";
      }
      else if (filename[0] == "atg_sec_lrs.shtml")
      {
	  helpFile = "sec_6.htm";
      }
      else if (filename[0] == "atg_sec_lrs_b.shtml")
      {
	  helpFile = "sec_7.htm";
      }
      else if (filename[0] == "atg_sec_lrs_c.shtml")
      {
	  helpFile = "sec_8.htm";
      }
      else if (filename[0] == "atg_sec_network-security_a.shtml")
      {
	  helpFile = "sec_4.htm";
      }
      else if (filename[0] == "atg_sec_network-security_b.shtml")
      {
	  helpFile = "sec_5.htm";
      }
      else if (filename[0] == "atg_services_filters-ip.shtml")
      {
	  helpFile = "svc_4.htm";
      }
      else if (filename[0] == "atg_services_filters-mac.shtml")
      {
	  helpFile = "svc_3.htm";
      }
      else if (filename[0] == "atg_services_filters.shtml")
      {
	  helpFile = "svc_2.htm";
      }
      else if (filename[0] == "atg_services_vlan.shtml")
      {
	  helpFile = "svc_5.htm";
      }
      else if (filename[0] == "atg_services_vlan-brg.shtml")
      {
	  helpFile = "svc_6.htm";
      }
      else if (filename[0] == "atg_services_vlan-rte.shtml")
      {
	  helpFile = "svc_7.htm";
      }
  	  else if (filename[0] == "atg_services_qos-traffic.shtml")
      {
	  helpFile = "svc_8.htm";
      }
      }
  window.open(helpRoot+helpFile)
}

function printPage(){  
	if (window.print) {
	    window.print() ;  
	} else {
	    var WebBrowser = '<OBJECT ID="WebBrowser1" WIDTH=0 HEIGHT=0 CLASSID="CLSID:8856F961-340A-11D0-A96B-00C04FD705A2"></OBJECT>';
		document.body.insertAdjacentHTML('beforeEnd', WebBrowser);
	    WebBrowser1.ExecWB(6, 2);
		
	}
}

function interfaceObject(name, hardware, product)
{
  this.name = name;  //e.g. "Dot11Radio0"
  if (atg_ret_value == 1)   {
   this.number = name.match(/Dot11Radio(\d+)/)[1];  //e.g. "0"
   }
   else if (atg_ret_value == 2)
   {
   this.number = name.match(/Dot11Radio(\d\/\d\/\d+)/)[1]; 
   
   }
   else
   {
   this.number = name.match(/Dot11Radio(\d+)/)[1];  //e.g. "0"
   }
   
  
  this.hardware = "Radio" + this.number + "-" + hardware;  //e.g. "Radio0-802.11B"
  
  this.protocol = hardware.match(/802.11(\w)/)[1];  //e.g. "B"
  
}

function getRadioInterfaces(showInt,product)
{

  var i = 0;
  var count;
  var interfaces = new Array();
  var hwPattern, hwResults;
  var intResults;
  
  if (atg_ret_value == 1)  {
    intResults = showInt.match(/^Dot11Radio\d+ /gm);
    }
    else if (atg_ret_value == 2)
   {
   intResults = showInt.match(/^Dot11Radio\d\/\d\/\d+ /gm);
   }
    else
    {
    intResults = showInt.match(/[\r\n]+Dot11Radio\d+ /g);
    }
  
    
  if (intResults) {
    for (count=0; count<intResults.length; count++) {
      hwPattern = new RegExp(intResults[count]+"[^\\r\\n]+[\\r\\n]+\\s+Hardware is (\\S+) ")
      hwResults = showInt.match(hwPattern)
      if (hwResults) {
      
        if (atg_ret_value == 1)   {
        interfaces[i] = new interfaceObject(intResults[count].match(/Dot11Radio\d+/)[0], hwResults[1],product)
        }
       else if (atg_ret_value == 2)
        {
        interfaces[i] = new interfaceObject(intResults[count].match(/Dot11Radio\d\/\d\/\d+/)[0], hwResults[1],product)
        }
        else
        {
        interfaces[i] = new interfaceObject(intResults[count].match(/Dot11Radio\d+/)[0], hwResults[1],product)
        }
        
       
       
        i++;
      }
    }
  }
  
  return interfaces;
}

function mbssidIsEnabled(radioNum, showRun)
{
  var mbssid_glob = showRun.match("[\\r\\n]+dot11 mbssid[\\r\\n]+");
  var mbssid_local = showRun.match("![\\r\\n]+interface Dot11Radio"+ radioNum +"[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)+ mbssid[\\r\\n]+");
  var no_mbssid_local = showRun.match("![\\r\\n]+interface Dot11Radio"+radioNum+"[\\r\\n]+( [^\\r\\n]+[\\r\\n]+)+ no mbssid[\\r\\n]+");
  if ((!mbssid_glob && mbssid_local) || (mbssid_glob && !no_mbssid_local)) {
    return true;
  } else {
    return false;
  }
}

function land(ref, target)
{
lowtarget=target.toLowerCase();
if (lowtarget=="_self") {window.location=loc;}
else {if (lowtarget=="_top") {top.location=loc;}
else {if (lowtarget=="_blank") {window.open(loc);}
else {if (lowtarget=="_parent") {parent.location=loc;}
else {parent.frames[target].location=loc;};
}}}
}
function jump(menu)
{
ref=menu.choice.options[menu.choice.selectedIndex].value;
splitc=ref.lastIndexOf("*");
target="";
if (splitc!=-1)
{loc=ref.substring(0,splitc);
target=ref.substring(splitc+1,1000);}
else {loc=ref; target="_self";};
if (ref != "") {land(loc,target);}
}


function calcNetMaskField(numberOfBits) {
   if (numberOfBits <= 0) {
      return "0";
   } else if (numberOfBits >= 8) {
      return "255";
   } else if (numberOfBits == 7) {
      return "254";
   } else if (numberOfBits == 6) {
      return "252";
   } else if (numberOfBits == 5) {
      return "248";
   } else if (numberOfBits == 4) {
      return "240";
   } else if (numberOfBits == 3) {
      return "224";
   } else if (numberOfBits == 2) {
      return "192";
   } else if (numberOfBits == 1) {
      return "128";
   }
}



function calcNetMask_string(numberOfBits) {
   var subNetMask = "";
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   subNetMask += ".";
   numberOfBits -= 8;
   subNetMask += calcNetMaskField(numberOfBits);
   if (subNetMask == "0.0.0.0")
       return ""
   else
       return subNetMask;
}


function calcNetMask(numberOfBits) {
   var str;
   if (numberOfBits) {
      if (numberOfBits == "undefined") {
         document.write("unassigned");
      } else {
         str = calcNetMask_string(numberOfBits);
         document.write(str);
      }
   } else {
      document.write("unassigned");
   }
}


function NameServerPresent(serverString)
{
  if ((token_string_blank(DLIM_nonword_period, 1, serverString) == "255.255.255.255") && 
       isBlank(token_string_blank(DLIM_nonword_period, 3, serverString)) && 
       isBlank(token_string_blank(DLIM_nonword_period, 5, serverString))) {
	 return false
  }
  return true
}


var DLIM_WhSp = /[\s]+/; 
var DLIM_WhSp_slash = /[\/\s]+/; 
var DLIM_WhSp_comma = /[\,\s]+/; 
var DLIM_WhSp_parens = /[\(\)\s]+/; 
var DLIM_WhSp_colon = /[\:\s]+/; 
var DLIM_newline = /[\r\n]+/;
var DLIM_nonword          = /[\W]+/;
var DLIM_nonword_period   = /[^a-zA-Z0-9_\.]+/;   
var DLIM_nonword_colon    = /[^a-zA-Z0-9_:]+/;    


function split (delimiter, string) { 
   localstring = string;
   word = localstring.split(delimiter);
   if (word.length>1) {
      
      while ((word.length>1)&&(word[0]=="")) {
         localstring = localstring.substr(1);
         word = localstring.split(delimiter);
      }
      
      while ((word.length>1)&&word[word.length-1]=="") {
         localstring = localstring.substr(0,localstring.length-1);
         word = localstring.split(delimiter);
      }
   }
   return word;
}


function token_string (delimiter, index, string) { 
    tok = null;
    word = split(delimiter, string);
    last_token = word.length - 1;
    if (index >= 0) {
       if (index <= last_token) {
          tok = word[index]; 
       }
    } else {
       backindex = last_token + index + 1;
       if (backindex >= 0) {
          tok = word[backindex]; 
       }
    }
    return tok;
}


function token (delimiter, index, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      tok = token_string(delimiter, index, string);
      if (tok) {
          document.write(tok);
      } else {
          document.write("&nbsp;");
      }
   }
}


function token_undefined (delimiter, index, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      tok = token_string(delimiter, index, string);
      if (tok) {
         document.write(tok);
      } else {
         document.write("undefined");
      }
   }
}


function token_help (delimiter, index, string) { 
   local_index = 0;
   tok = token_string(delimiter, local_index, string);
   if (33 == tok.charCodeAt(1)) {
      document.write("missing");
   } else {
      if (tok) {
         while (tok) {
            document.write('\n');
            if (index == local_index) {
               document.write('<FONT COLOR="red">');
            }
            document.write('('+local_index+')="'+tok+'"');
            if (index == local_index) {
               document.write("</FONT>");
            }
            document.write("<br>");
            local_index += 1;
            tok = token_string(delimiter, local_index, string);
         }
      } else {
         document.write('<FONT COLOR="red">NULL</FONT>');
      }
   }
}


function replace_string (target, found, notfound, string)
{
   if (-1 != string.search(target)) {
      return found;
   } else {
      return notfound;
   }
}


function replace (target, found, notfound, string)
{
   if (-1 != string.search(target)) {
      document.write(found);
   } else {
      document.write(notfound);
   }
}


function grep_string (pattern, string) {
   line = split(DLIM_newline, string);
   for (curline = 0; curline < line.length; curline++) {
      if (-1 != line[curline].search(pattern)) {
          return line[curline];
      }
   }
}


function grep (pattern, string) {
   line = grep_string(pattern, string);
   if (line) {
      document.write(line);
   }
}


function multi_grep_string (pattern, string) {
   var result = new Array();
   var i = 0;
   line = string.split(DLIM_newline);
   for (curline = 0; curline < line.length; curline++) {
      if (-1 != line[curline].search(pattern)) {
         result[i] = line[curline];
         i += 1;
      }
   }
   return result;
}


function find_string (pattern, delimiter, index, string) {
   line = grep_string(pattern, string);
   if (line) {
      tok = token_string(delimiter, index, line);
      if (tok) {
          return tok;
      }
   }
}


function find (pattern, delimiter, index, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      line = grep_string(pattern, string);
      if (line) {
         tok = token_string(delimiter, index, line);
         if (tok) {
            document.write(tok);
         } else {
            document.write("&nbsp;");
         }
      } else {
         document.write("&nbsp;");
      }
   }
}


function find_undefined (pattern, delimiter, index, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      line = grep_string(pattern, string);
      if (line) {
          tok = token_string(delimiter, index, line);
          if (tok) {
              document.write(tok);
          } else {
             document.write("undefined");
          }
      } else {
          document.write("undefined");
      }
   }
}


function find_help (pattern, delimiter, index, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      line = grep_string(pattern, string);
      if (line) {
         tok = token_help(delimiter, index, line);
      } else {
         document.write("undefined");
      }
   }
}



function token_string_label(delimiter, label, string)
{
    word = string.split(delimiter);
    for (var index=0; index<word.length; index++) {
      if (word[index] == label) 
        return word[index+1]; 
    }
}


function token_string_label_index(delimiter, label, string, tokenIndex)
{
    var blank = ""
    word = string.split(delimiter);
    for (var index=0; index<word.length; index++) {
      if (word[index] == label) 
        return word[index+tokenIndex]; 
    }
	return blank
}


function token_string_label_to_label(delimiter, label1, label2, string)
{
    word = string.split(delimiter);
	var str = ""
	var index1 = 0
	var index2 = 0
    for (var index=0; index<word.length; index++) {
      if (word[index] == label1)
	    index1 = index 
      if (word[index] == label2)
	    index2 = index  
    }
	for (var i = index1; i < index2-1; i++) {
	  str += word[i+1] + " "
	}
	return str
}



function token_string_label_blank(delimiter, label, string)
{
   if (string) {
      match = string.search(label);
      if (-1 != match) {
         remainder = string.substring(match+label.length);
         tok = token_string(delimiter, 0, remainder);
         if (tok)
            return tok;
      }
   }
   return ""
}



function token_string_label_to_eol(label, string)
{
   if (string) {
      match = string.search(label);
      if (-1 != match) {
         remainder = string.substring(match+label.length);
         tok = token_string(DLIM_newline, 0, remainder);
         if (tok)
            return tok;
      }
   }
}


function token_string_blank (delimiter, index, string) { 
    var val = ""
    val = token_string(delimiter, index, string)
    if (!val)
      return ""
    else
      return val
}


function makeArray(n)
{
  this.length = n;
  return this;
}



function token_offset_str (pattern, delimiter, index, defalt, string) {
   var tok = defalt;
   var exp_str = "";
   var exp;
   var debug = 0;
   var result;
   if (arguments.length > 5) {
      debug = arguments[5];
   }
   if (string) {
      if (index < 0) {
         exp_str += "([^\\r\\n]+)"+delimiter.source;
         exp_str += "("+pattern.source+")";
         exp_str += delimiter.source;
         exp = new RegExp(exp_str);
         result = string.match(exp);
         result_pattern = 2;
         result_index = 1;
         tokens_offset = 0;
         tokens_multiplier = 1;
      } else {
	     if (string.search(pattern) != 0) {
           exp_str += delimiter.source ;
		 }
         exp_str += "("+pattern.source+")";
         exp_str += delimiter.source+"([^\\r\\n]+)";
         exp = new RegExp(exp_str);
         result = string.match(exp);
         result_pattern = 1;
         result_index = 2;
         tokens_offset = -1;
         tokens_multiplier = 0;
      }
      if (result != null) {
         tokens = split(delimiter, result[result_index]);
         tokens_index = index + tokens_offset + (tokens.length * tokens_multiplier);
         if ((tokens_index >= 0) && (tokens_index < tokens.length)) {
            if (debug == 0) {
               tok = tokens[tokens_index];
            } else {
               tok = "";
               if (tokens_multiplier == 0) {
                  tok += result[result_pattern]+"<BR>";
               }
               br_str = "";
               for (i=0; i<tokens.length; i++) {
                  j = i - tokens_offset - (tokens.length * tokens_multiplier);
                  tok += br_str;
                  if (i == tokens_index) {
                     tok += '<FONT COLOR="red">';
                     tok += '('+j+')='+tokens[i];
                     tok += '</FONT>';
                  } else {
                     tok += '('+j+')='+tokens[i];
                  }
                  br_str = "<BR>";
               }
               if (tokens_multiplier != 0) {
                  tok += "<BR>"+result[result_pattern];
               }
            }
         }
      }
   }
   return tok;
}

function token_offset (pattern, delimiter, index, defalt, string) {
   if (-1 != string.search(/exec cmd/)) {
      document.write("*NO AP*");
   } else {
      if (document.forms[0].DEBUG != null) {
         tok = token_offset_str(pattern, delimiter, index, defalt, string, 1);
      } else {
         tok = token_offset_str(pattern, delimiter, index, defalt, string);
      }
      
      if (tok != null) {
         document.write(tok);
      }
   }
}

//hide special characters in a string from reg exp.
function stringToPattern(inputStr)
{
  var outputStr = inputStr;
  outputStr = outputStr.replace(/\\/,"\\\\");
  outputStr = outputStr.replace(/\//,"\\/");
  outputStr = outputStr.replace(/\./,"\\.");
  outputStr = outputStr.replace(/\*/,"\\*");
  outputStr = outputStr.replace(/\+/,"\\+");
  outputStr = outputStr.replace(/\?/,"\\?");
  outputStr = outputStr.replace(/\|/,"\\|");
  outputStr = outputStr.replace(/\(/,"\\(");
  outputStr = outputStr.replace(/\)/,"\\)");
  outputStr = outputStr.replace(/\[/,"\\[");
  outputStr = outputStr.replace(/\]/,"\\]");
  outputStr = outputStr.replace(/\{/,"\\{");
  outputStr = outputStr.replace(/\}/,"\\}");
  return outputStr;
}

//Translate characters with HTML character entity equivalents into these entities
//e.g. stringToEntities("Fish&chips") returns "Fish&#38;chips" 
//Use this to protect from malicious user input e.g. <a href="a.com">
function stringToEntities (inputStr)
{
  var outputStr = "";    //encoded string

  for (var i=0; i<inputStr.length; ++i) {
    var strChar  = inputStr.charAt(i);
    var intChar  = inputStr.charCodeAt(i);

    if (isNaN(intChar)) {
      //if char failed to decode, leave as char
      outputStr += strChar;
    } else {
      // if char was [a-zA-Z0-9_ \t] leave as char, else replace with entity
      outputStr += strChar.match(/[\w\s]/) ? strChar :  "&#" + intChar + ";";
    }
  }
  return (outputStr);
}
