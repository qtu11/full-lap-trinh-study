/*
 * Copyright (c) 2002, 2003, 2004 by cisco Systems, Inc.
 * All rights reserved.
 */
 /*
 ####################################################################
 ### Author : Ramya
 ### Version :1.0
 ### Modified the js file to get the pattern based on the product types.
 ####################################################################
*/
var radioLinkCookie = new Cookie(document, "radioLink")

var atg_ret_value= isATG(product);

function setRadioLinkCookie(target) {
  radioLinkCookie.targetRadio = target;
  radioLinkCookie.store();
}
function getRadioLinkCookie(defalt) {
  var result = defalt;
  if (radioLinkCookie.load()) {
    result = radioLinkCookie.targetRadio;
  }
  return result;
}
function setRadioLinkCookieThisRadio() {
  setRadioLinkCookie(thisRadio);
}
function maxRadioSlots(ver)
{
  var slots = 1;
  pattern = new RegExp("\\nIOS \\S+ (\\S+) Software");
  result = ver.match(pattern);
  if (result) {
    if (result.length >1) {
      if (result[1] == "C1200") {
        slots = 2;
      }
    }
  }
  return slots;
}
function allObject(ary, cntEther, cntRadio, cntRadioSlot)
{
  this.ary = ary;
  this.cntEther = cntEther;
  this.cntRadio = cntRadio;
  this.cntRadioSlot = cntRadioSlot;
  this.cntExist = cntEther + cntRadio;
  this.colspan = (this.cntExist+1)
  this.headPercent = 100 / this.colspan;
  this.contPercent = 100 / this.colspan;
}
function ifObject(exist, currentPage, name, number, hardware, path)
{

  this.exist = exist;
  this.nameCLI = name+number;                         //e.g. "Dot11Radio0 / FastEthernet0"
  this.current = (currentPage==this.nameCLI);
  this.number = number;                               //e.g. "0"
  if (name=="FastEthernet") {
    this.nameMenu = this.nameCLI;                     //e.g. "FastEthernet0"
    this.protocol = name;                             //e.g. "FastEthernet"
    this.link = "atg_network-if_ethernet.shtml";
  } else if (name=="Dot11Radio") {
    if (this.exist) {
      this.nameMenu = "Radio"+number+"-"+hardware.toUpperCase(); //e.g. "Radio0-802.11B"
      this.protocol = hardware.match(/802.11(\w)/)[1];  //e.g. "b"
      
      this.link     = path + "atg_network-if_802-11.shtml";
      
    } else {
      this.nameMenu = "Radio"+number+"-not installed";
      this.protocol = "";
      this.link     = "";
    }
  }
}

function getAll(showInt, currentPage, path)
{
  var str="";
  var interfaces = new Array();
  var index = 0;
  var globalResult;
  var cntEther = 0;
  var cntRadio = 0;
  var cntRadioSlot = 0;
  var maxRadioSlot = maxRadioSlots(document.forms[0].VERSION.value);
  var pattern;
  var regPat;
  
  if (atg_ret_value == 1)  {
      pattern = "^(Dot11Radio)(\\d+) [^\\r\\n]+[\\r\\n]+\\s+Hardware is (\\S+) "; 
  }
  else if (atg_ret_value == 2)
  {
      pattern = "^(Dot11Radio)(\\d\/\\d\/\\d+) [^\\r\\n]+[\\r\\n]+\\s+Hardware is (\\S+) "; 
  }
  else 
  {
      pattern = "[\\r\\n]+(Dot11Radio)(\\d+) [^\\r\\n]+[\\r\\n]+\\s+Hardware is (\\S+) "; 
  }

  regPat = new RegExp(pattern,"gm");
  globalResult = showInt.match(regPat); //returns one entry for each match
  
  if (globalResult) {
    for (i=0; i<globalResult.length; i++) {
      result = globalResult[i].match(new RegExp(pattern)); //returns parsed data in ()'s
      if (result) {
        while (cntRadioSlot < result[2]) {
          interfaces[index++] = new ifObject(false, false, "Dot11Radio", cntRadioSlot, "none", path);
          cntRadioSlot += 1;
        }
        name = result[1]; //Dot11Radio0
        number = result[2]; //0
        hardware = result[3]; //Radio0-802.11b
        interfaces[index++] = new ifObject(true, currentPage, name, number, hardware, path);
        cntRadio += 1;
        cntRadioSlot += 1;
      }
    }
  }

  while (cntRadioSlot < maxRadioSlot) {
    interfaces[index++] = new ifObject(false, false, "Dot11Radio", cntRadioSlot, "none", path);
    cntRadioSlot += 1;
  }
  allObj =  new allObject(interfaces, cntEther, cntRadio, cntRadioSlot);
  return allObj;
}

function subMenu(exist, current, target, nameMenu, nameCLI)
{
  document.write('<tr><td colspan="4" bgcolor="003333"><img src="images/pixel.gif" alt="" border="0" width="1" height="1"></td></tr>');
  document.write('<tr><td bgcolor="#cccccc" background="images/apps_leftnav_yellow.gif">&nbsp;</td>');
  document.write('<td bgcolor="#cccccc">&nbsp;</td>');
  document.write('<td bgcolor="#cccccc">');
  if (exist) {
    if (current) {
      document.write('<a href='+target+' class="apphinavchild" onclick="setRadioLinkCookie(\''+nameCLI+'\')">');
      document.write(nameMenu);
    } else {
      document.write('<a href='+target+' class="apphinavchildlink" onclick="setRadioLinkCookie(\''+nameCLI+'\')">');
      document.write(nameMenu);
    }
    document.write('</a>');
  } else {
    document.write('<font color="#666666" face="Arial, Helvetica, sans-serif" size="2">');
    document.write(nameMenu);
    document.write('</font>');
  }
  document.write('</td><td bgcolor="#cccccc">&nbsp;</td></tr>');
}
function ifMenu(allObj)
{
  for (i=0; i< allObj.ary.length; i++) {
    subMenu(allObj.ary[i].exist, allObj.ary[i].current, allObj.ary[i].link, allObj.ary[i].nameMenu, allObj.ary[i].nameCLI);
  }
}
function ifTitle(allObj)
{
  for (i=0; i< allObj.ary.length; i++) {
    if (allObj.ary[i].current) {
      return allObj.ary[i].nameMenu;
    }
  }
}
function ifProtocol_string(allObj)
{
  var protocol = "x";
  for (i=0; i< allObj.ary.length; i++) {
    if (allObj.ary[i].current) {
      protocol = allObj.ary[i].protocol;
    }
  }
  return protocol;
}
function titleBar(data, allObj)
{
  document.write('<tr bgcolor="#99CCCC">');
  document.write('<td colspan="'+allObj.colspan+'">');
  document.write('<font face="Arial, Helvetica, sans-serif" size="2"><b>');
  document.write(data);
  document.write('</b></font>');
  document.write('</td>');
  document.write('</tr>');
}
function rowBegin(data)
{
  document.write('<tr bgcolor="#FFFFFF">');
}
function heading(data, allObj)
{
  document.write('<td valign="TOP" height="30" align="LEFT" width="'+allObj.headPercent+'%">');
  document.write('<font face="Arial, Helvetica, sans-serif" size="2">');
  document.write(data);
  document.write('</font>');
  document.write('</td>');
}
function subHeading(data, mod, allObj)
{
  document.write('<td valign="TOP" height="30" align="LEFT" width="'+allObj.headPercent+'%" '+mod+'>');
  document.write('<font face="Arial, Helvetica, sans-serif" size="2" color="#336666"><b>');
  document.write(data);
  document.write('</b></font>');
  document.write('</td>');
}
function headingWithLinks(data, allObj)
{
  document.write('<tr bgcolor="#99CCCC">');
  document.write('<td width="'+allObj.headPercent+'%">');
  document.write('<font face="Arial, Helvetica, sans-serif" size="2"><b>');
  document.write(data);
  document.write('</b></font>');
  document.write('</td>');
  for (j=0; j < allObj.ary.length; j++) {
    if (allObj.ary[j].exist) {
      document.write('<td width="'+allObj.contPercent+'%" valign="TOP" height="30" align="LEFT">');
      document.write('<font face="Arial, Helvetica, sans-serif" size="2">');
      document.write('<a href="');
      document.write(allObj.ary[j].link);
      document.write('" class="contentlink"');
      document.write(' onclick="setRadioLinkCookie(\''+allObj.ary[j].nameCLI+'\')">');
      document.write(allObj.ary[j].nameMenu);
      document.write('</a>');
      document.write('</font>');
      document.write('</td>');
    }
  }
}
function content(data, allObj)
{
  document.write('<td valign="TOP" height="30" align="RIGHT" class="content" width="'+allObj.contPercent+'%">');
  document.write(data);
  document.write('</td>');
}
function match(defalt, input, index, string)
{
  var target = defalt;
  var pattern = new RegExp(input);
  var result = string.match(pattern);

  if (result) {
    if (result.length > index) {
      target = result[index];
    }
  }
  return target;
}
function contentIF(nameIF, index, pat, string, allObj)
{
  content(match("error",nameIF+pat, index, string), allObj);
}
function contentIFMultiple(index, pat, string, allObj)
{
  for (j=0; j < allObj.ary.length; j++) {
    if (allObj.ary[j].exist) {
      contentIF(allObj.ary[j].nameCLI, index, pat, string, allObj);
    }
  }
}
function IFArrows(nameIF ,index, pat, string, up, down)
{
  var result = match("error",nameIF+pat, index, string);
  return replace_string(/up/, up, down, result);
}
function contentIFArrows(nameIF ,index, pat, string, up, down, allObj)
{
  content(IFArrows(nameIF ,index, pat, string, up, down),allObj);
}
function contentIFMultipleArrows(index, pat, string, up, down, allObj)
{
  for (j=0; j < allObj.ary.length; j++) {
    if (allObj.ary[j].exist) {
      contentIFArrows(allObj.ary[j].nameCLI, index, pat, string, up, down, allObj);
    }
  }
}
function rowEnd()
{
  document.write('</tr>');
}

