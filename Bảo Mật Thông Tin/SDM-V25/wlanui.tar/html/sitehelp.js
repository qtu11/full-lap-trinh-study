/*
 * Copyright (c) 2002-2007 by cisco Systems, Inc.
 * All rights reserved.
 */

var helpPath = "http://www.cisco.com/univercd/cc/td/doc/product/software/sdm/wlanui/";

